CREATE OR REPLACE PROCEDURE PROCESS_BACKUP_TABLES IS

   l_mensagem_erro D_ARRAY_MENSAGEM_ERRO_TP;
   l_erro VARCHAR2(1000);
   --
   l_sql VARCHAR2(500);
   l_total_records NUMBER;
   --
   l_start_date   DATE;
   l_end_date     DATE;
   --
   l_conv_begin   VARCHAR2(100);
   l_conv_end     VARCHAR2(100);
   --
   l_current_date DATE;
   --
   l_back_years NUMBER;
   l_ref_data DATE;

   CURSOR C_TABLE_NAME IS
      SELECT TABLE_NAME,
             TABLE_ORIGIN,
             PARTITION
        FROM BCK_TABLE_DATE
       WHERE ACTIVE = 'Y'
         AND table_name LIKE '%BCK%' --garantir que trunca apenas tabelas backup
       ORDER BY TOTAL_RECORDS;


BEGIN


   l_back_years := PCK_CORE_PARAMETER.GETNUMBERATTR('DUMMY_BACK_YEARS');
   IF l_back_years IS NOT NULL THEN
      l_ref_data := ADD_MONTHS(to_date('01012000', 'ddmmyyyy'),-12* TRUNC(l_back_years/2));
   END IF;
   --
   FOR c in C_TABLE_NAME LOOP

      --Truncate backup table
      l_sql := 'TRUNCATE TABLE '|| c.table_name;
      EXECUTE IMMEDIATE l_sql;

      IF UPPER(c.PARTITION) = 'DATA' THEN

         l_sql := 'SELECT TRUNC(MIN(DATA),''IW''), TRUNC(MAX(DATA),''IW'') + 6 FROM '|| c.TABLE_ORIGIN;
         EXECUTE IMMEDIATE l_sql INTO l_start_date,l_end_date;

         IF l_ref_data IS NOT NULL AND l_start_date < l_ref_data THEN
            l_sql := 'SELECT TRUNC(MIN(DATA),''IW'') FROM '|| c.TABLE_ORIGIN || ' WHERE data > '||'TO_DATE('''||TO_CHAR(l_ref_data,'ddmmyyyy')||''',''ddmmyyyy'')';
            EXECUTE IMMEDIATE l_sql INTO l_start_date;
         END IF;

         WHILE l_start_date <= l_end_date LOOP

            l_conv_begin := 'TO_DATE('''||TO_CHAR(l_start_date,'ddmmyyyy')||''',''ddmmyyyy'')';
            l_conv_end   := 'TO_DATE('''||TO_CHAR(l_start_date + 6,'ddmmyyyy')||''',''ddmmyyyy'')';
            --
            l_sql := 'INSERT INTO ' ||c.table_name|| ' SELECT * FROM '|| c.table_origin || ' WHERE DATA BETWEEN ' ||l_conv_begin || ' AND '||l_conv_end ;
            EXECUTE IMMEDIATE l_sql;
            --
            l_start_date := l_start_date + 7;
            COMMIT;
         END LOOP;

      ELSE

          l_sql := 'INSERT INTO ' ||c.table_name|| ' SELECT * FROM '|| c.table_origin;
          EXECUTE IMMEDIATE l_sql;

      END IF;

      --Count processed Records
      l_sql := 'SELECT COUNT(*) FROM '|| c.table_name;
      EXECUTE IMMEDIATE l_sql INTO l_total_records;

      --Update setup table with audit info
      UPDATE BCK_TABLE_DATE
         SET DATA     = SYSDATE,
             USERNAME = USER,
             TOTAL_RECORDS = l_total_records
       WHERE TABLE_NAME = c.TABLE_NAME;

    COMMIT;

  END LOOP;
EXCEPTION
  WHEN OTHERS THEN
    L_ERRO := PCK_ESCALA_DEBUG.FNC_MONTA_MENSAGEM('PACKAGE_ERROR',
                                                  'Erro ao executar PROCESS_BACKUP_TABLES',
                                                  'PROCESS_BACKUP_TABLES',
                                                  TO_CHAR(SQLCODE));

    L_MENSAGEM_ERRO := N_MENSAGEM.GET(L_MENSAGEM_ERRO, L_ERRO, NULL);
    N_BATCH.Log(l_Mensagem_Erro);
END;
/