create table esc_escala_bck as select * from esc_escala where 1=2;
create table esc_colaborador_disponivel_bck as select * from esc_colaborador_disponivel where 1=2;
create table esc_horario_colaborador_bck as select * from esc_horario_colaborador where 1=2;
create table esc_escala_consolidada_bck as select * from esc_escala_consolidada where 1=2;
create table Esc_Colaborador_Escalado_bck as select * from Esc_Colaborador_Escalado where 1=2;
create table esc_carga_horaria_bck as select * from esc_carga_horaria where 1=2;
create table esc_ausencia_bck as select * from esc_ausencia where 1=2;
