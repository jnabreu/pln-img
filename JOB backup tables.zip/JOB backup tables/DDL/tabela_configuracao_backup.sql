create table BCK_TABLE_DATE
(
  table_name    VARCHAR2(50),
  data          DATE,
  username      VARCHAR2(50),
  table_origin  VARCHAR2(50),
  total_records NUMBER(10),
  active        VARCHAR2(1),
  partition     VARCHAR2(50)
);