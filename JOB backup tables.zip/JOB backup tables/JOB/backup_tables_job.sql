BEGIN
DBMS_SCHEDULER.CREATE_JOB (
  job_name     => 'JOB_BACKUP_TABLES',
  JOB_CLASS    => 'DEFAULT_JOB_CLASS',
  job_type     => 'PLSQL_BLOCK',
  auto_drop    => TRUE,
  comments     => 'PROCESS BACKUP TABLES',
  enabled      => TRUE,
  schedule_name  => 'SCHDL_BACKUP_TABLES',
  job_action   => 'BEGIN PROCESS_BACKUP_TABLES; END;');
END;
/