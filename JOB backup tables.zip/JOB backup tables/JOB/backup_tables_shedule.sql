BEGIN  
DBMS_SCHEDULER.CREATE_SCHEDULE (
 schedule_name   => 'SCHDL_BACKUP_TABLES',
 start_date    => SYSTIMESTAMP,
 repeat_interval  => 'FREQ=DAILY; BYHOUR=2',
 comments     => 'Run daily at 02AM');
END;
/