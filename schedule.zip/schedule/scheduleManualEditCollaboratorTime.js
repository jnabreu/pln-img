﻿var scheduleManualEditCollaboratorTime = function () {

    var canSaveOperation = null;

    //#region Helpers

    function myName() {
        return 'manual';
    }

    //#endregion Helpers

    //#region Events

    function changeInputValue(e) {
        var changed = false;

        var rangeSettings = scheduleEditCollaboratorTime.getRangeSettings(),
            index = $(e.target).parents('.js-container-type-edit').data('index'),
            manualContainer = $(e.target).parents('.js-container-type-edit'),
            startTime = parseInt(manualContainer.find('#txtStartTime').val()),
            startMinute = parseInt(manualContainer.find('#ddlStartTime').val()),
            ddlStartTime = manualContainer.find('#ddlStartTime'),
            startTimePlus = parseInt(manualContainer.find('#txtStartTimePlus').val()),
            startMinutePlus = parseInt(manualContainer.find('#ddlStartTimePlus').val()),
            ddlStartTimePlus = manualContainer.find('#ddlStartTimePlus'),
            txtEndTime = manualContainer.find('#txtEndTime'),
            formatField = scheduleModule.getSectionParent().find('#hdnMomentFormatTime');

        ddlStartTime.trigger('update');
        ddlStartTimePlus.trigger('update');

        var beginTime = dateModule.getDefaultDateTime(startTime + ':' + startMinute),
            endTime = dateModule.getDefaultDateTime(startTime + ':' + startMinute);

        if (!isNaN(startTimePlus)) {
            endTime.add('hours', startTimePlus);
        }
        if (!isNaN(startMinutePlus)) {
            endTime.add('minutes', startMinutePlus);
        }
        // Cria o horário final com base no horário inicial e jornada do dia
        txtEndTime.val(endTime.format(formatField.val()));
        // Seta que houve edição no horário
        rangeSettings[index].HasEdit = true;

        beginTime = beginTime.toMSDate();
        endTime = endTime.toMSDate();
        if (beginTime != rangeSettings[index].BeginHourWork || endTime != rangeSettings[index].EndHourWork) {
            changed = true;
        }

        // Atualiza os horários
        rangeSettings[index].BeginHourWork = beginTime;
        rangeSettings[index].EndHourWork = endTime;

        
        if (changed)
        {
            var hasInvalid = false, affectedElement, errorMessage;

            if (rangeSettings[index].BeginHourWork < rangeSettings[index].BeginRange) {
                affectedElement = manualContainer.find('#txtStartTime');
                var momentBeginRange = moment.utc(rangeSettings[index].BeginRange);
                hasInvalid = true;

                showTimeErrorMessage(affectedElement, String.format(_globalResources.getResource().schedule.edit.InvalidStartTimeMessage, momentBeginRange.format(formatField.val())));
            }
            else {
                affectedElement = manualContainer.find('#txtStartTime');
                validateModule.removeStyleError(affectedElement);
                affectedElement.tooltipster('hide');
            }


            if (rangeSettings[index].EndHourWork > rangeSettings[index].EndRange) {
                affectedElement = manualContainer.find('#txtEndTime');
                var momentBeginRange = moment.utc(rangeSettings[index].EndRange);
                hasInvalid = true;

                showTimeErrorMessage(affectedElement, String.format(_globalResources.getResource().schedule.edit.InvalidEndTimeMessage, momentBeginRange.format(formatField.val())));
            }
            else {
                affectedElement = manualContainer.find('#txtEndTime');
                validateModule.removeStyleError(affectedElement);
                affectedElement.tooltipster('hide');
            }

            if (!hasInvalid) {
                $('#divTimeArea').removeData("has-error");
                var sectionParent = scheduleEditCollaboratorTime.getSectionParent();
                $(rangeSettings).each(function (index) {
                    if (!rangeSettings[index].IsMainRange && !rangeSettings[index].IsInterval) {
                        sectionParent.find('#btnEditTimeDelete_' + index).trigger('click');
                    }
                });
            }
        }
    }

    function showTimeErrorMessage(affectedElement, errorMessage) {
        validateModule.appendStyleError(affectedElement);
        affectedElement.tooltipster('content', errorMessage);
        affectedElement.tooltipster('show');
        $(".tooltipster-content").parent().css("z-index", "9999");
        $('#divTimeArea').data("has-error", true);
    }

    //#endregion Events

    //#region Functions   

    function updateValues() {
        var rangeSettings = scheduleEditCollaboratorTime.getRangeSettings(),
            sectionParent = scheduleEditCollaboratorTime.getSectionParent();

        $(rangeSettings).each(function (index) {
            if (rangeSettings[index].IntervalTypeID === 'S' || canSaveOperation == false) {
                // Desabilita os inputs se o tipo de intervalo for 'Sem intervalo'
                disabledInterval(index);
                return;
            }

            var manualContainer = sectionParent.find('.js-container-type-edit[data-index="' + index + '"]'),
                txtStartTime = manualContainer.find('#txtStartTime'),
                ddlStartTime = manualContainer.find('#ddlStartTime'),
                txtStartTimePlus = manualContainer.find('#txtStartTimePlus'),
                ddlStartTimePlus = manualContainer.find('#ddlStartTimePlus'),
                txtEndTime = manualContainer.find('#txtEndTime'),
                beginTime = moment.utc(this.BeginHourWork),
                endTime = moment.utc(this.EndHourWork),
                formatField = scheduleModule.getSectionParent().find('#hdnMomentFormatTime');

            txtStartTime.val(beginTime.format('HH'));
            ddlStartTime.val(beginTime.format('mm'));
            ddlStartTime.trigger('update');

            var numberHours = endTime.diff(beginTime, 'hours'),
                numberMinutes = endTime.diff(beginTime, 'minutes') - (numberHours * 60);

            if (numberMinutes < 10)
                numberMinutes = "0" + numberMinutes;

            txtStartTimePlus.val(numberHours);
            ddlStartTimePlus.val(numberMinutes);
            ddlStartTimePlus.trigger('update');

            txtEndTime.val(endTime.format(formatField.val()));

            if (canSaveOperation == false) {
                txtStartTime.attr('disabled', 'disabled');
                ddlStartTime.attr('disabled', 'disabled');
                txtStartTimePlus.attr('disabled', 'disabled');
                ddlStartTimePlus.attr('disabled', 'disabled');
                txtEndTime.attr('disabled', 'disabled');
            }
        });
    }

    function disabledInterval(index) {
        var sectionParent = scheduleEditCollaboratorTime.getSectionParent();
        // Recupera todos os inputs e selects do container do index selecionado
        sectionParent.find('.container-time[data-index="' + index + '"]').find('.manual-view').find(':input').each(function (index) {
            $(this).attr('disabled', 'disabled');
            // Se for o tipo SELECT, deverá ser acionado o update para atualizar a class para desabilitado
            if (this.tagName == "SELECT") {
                $(this).trigger('update');
            }
        });
    }

    function enabledInterval(intervalIndex) {
        var formatField = scheduleModule.getSectionParent().find('#hdnMomentFormatTime'),
            rangeSettings = scheduleEditCollaboratorTime.getRangeSettings(),
            sectionParent = scheduleEditCollaboratorTime.getSectionParent(),
            minValue,
            maxValue;

        // Recupera todos os inputs e selects do container do index selecionado
        sectionParent.find('.container-time[data-index="' + intervalIndex + '"]').find('.manual-view').find(':input').each(function (index) {
            $(this).removeAttr('disabled');
            // Se for o tipo SELECT, deverá ser acionado o update para atualizar a class para habilitado
            if (this.tagName == "SELECT") {
                $(this).trigger('update');
            }
        });

        $(rangeSettings).each(function (index) {
            if (rangeSettings[index].IsMainRange) {

                var mainContainer = sectionParent.find('.js-container-type-edit[data-index="' + index + '"]'),
                    intervalContainer = sectionParent.find('.js-container-type-edit[data-index="' + intervalIndex + '"]'),
                    txtStartTime = intervalContainer.find('#txtStartTime'),
                    ddlStartTime = intervalContainer.find('#ddlStartTime'),
                    txtStartTimePlus = intervalContainer.find('#txtStartTimePlus'),
                    ddlStartTimePlus = intervalContainer.find('#ddlStartTimePlus'),
                    txtEndTime = intervalContainer.find('#txtEndTime'),
                    beginTime = moment.utc(this.BeginHourWork),
                    endTime = moment.utc(this.EndHourWork),
                    diff = parseInt(mainContainer.find('#txtStartTimePlus').val() / 2);

                minValue = new moment.utc(beginTime).add('hours', diff),
                maxValue = new moment.utc(beginTime).add('hours', diff + 1);

                txtStartTime.val(minValue.format('HH'));
                ddlStartTime.val(minValue.format('mm'));
                ddlStartTime.trigger('update');
                txtStartTimePlus.val(1);
                ddlStartTimePlus.val('00');
                ddlStartTimePlus.trigger('update');
                txtEndTime.val(maxValue.format(formatField.val()));

            } else if (rangeSettings[index].IsInterval) {
                rangeSettings[index].BeginHourWork = minValue.toMSDate();
                rangeSettings[index].EndHourWork = maxValue.toMSDate();

                return;
            }
        });
    }

    function registerEvents() {
        var sectionParent = scheduleEditCollaboratorTime.getSectionParent();
        // Atribui um evento para o todos os inputs quando alterar o valor e perder o foco
        sectionParent.find('.manual-view').find(':input').off('blur').on('blur', changeInputValue);
        sectionParent.find('.manual-view').find('select').off('change').on('change', changeInputValue);
    }

    //#endregion Functions

    function init(canSave) {
        canSaveOperation = canSave;
        registerEvents();
        updateValues();

        tooltipModule.init('divManualTimeContainer');
    }

    return {
        init: init,
        disabledInterval: disabledInterval,
        disabledInterval: disabledInterval,
        enabledInterval: enabledInterval,
        updateValues: updateValues
    }

}();