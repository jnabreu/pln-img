﻿var scheduleVisualEditCollaboratorTime = function () {

    var sectionParent = null;
    var isPolyvalent = false;
    var canSaveOperation = null;

    function myName() {
        return 'visual';
    }

    function changeSliderValue(target) {
        var isMain = target.data('main'),
            rangeSettings = scheduleEditCollaboratorTime.getRangeSettings();

        if (isPolyvalent && isMain.toLowerCase() === 'true') {
            $(rangeSettings).each(function (index) {
                if (!rangeSettings[index].IsMainRange && !rangeSettings[index].IsInterval) {
                    sectionParent.find('#btnEditTimeDelete_' + index).trigger('click');
                }
            });

            sectionParent.find('.alter-reason').show();
        }
    }

    function configSlider(isFirstTime) {
        var rangeSettings = scheduleEditCollaboratorTime.getRangeSettings(),
            sectionParent = scheduleEditCollaboratorTime.getSectionParent();

        $(rangeSettings).each(function (index) {

            var minDateTime = String(rangeSettings[index].BeginRange).toDefaultMomentDate(),
                maxDateTime = String(rangeSettings[index].EndRange).toDefaultMomentDate(),
                minValue = String(rangeSettings[index].BeginHourWork).toDefaultMomentDate(),
                maxValue = String(rangeSettings[index].EndHourWork).toDefaultMomentDate(),
                divRange = sectionParent.find("#divTime_" + index);

            if (isFirstTime === false) {
                divRange.dateRangeSlider("destroy");
            }

            divRange.dateRangeSlider({
                bounds: { min: minDateTime, max: maxDateTime },
                defaultValues: { min: minValue, max: maxValue },
                step: {
                    minutes: 15
                },
                formatter: function (val) {
                    var value = String(val).toDefaultMomentDate(),
                        formatField = scheduleModule.getSectionParent().find('#hdnMomentFormatTime');

                    return value.format(formatField.val());
                }
            }).off("userValuesChanged").on("userValuesChanged", function (e, data) {
                // Atualiza as datas alteradas nos sliders
                rangeSettings[$(e.target).data("index")].HasEdit = true;
                rangeSettings[$(e.target).data("index")].BeginHourWork = moment.utc(data.values.min).toMSDate();
                rangeSettings[$(e.target).data("index")].EndHourWork = moment.utc(data.values.max).toMSDate();

                changeSliderValue($(e.target));
            });

            // Seta as cores dos sliders e configura as variavéis
            if (rangeSettings[index].IsMainRange) {
                divRange.find(".ui-rangeSlider-bar").css({ "background": "#E81010" });
            } else if (rangeSettings[index].IsInterval) {
                divRange.find(".ui-rangeSlider-bar").css({ "background": "#FAC055" });

                if (rangeSettings[index].IntervalTypeID === 'S') {
                    // Desabilita o slider se o tipo de intervalo for 'Sem intervalo'
                    setTimeout(function () {
                        disabledInterval(index);
                    });
                }
            } else {
                divRange.find(".ui-rangeSlider-bar").css({ "background": (rangeSettings[index].WorkstationTypeColor ? rangeSettings[index].WorkstationTypeColor : "#fff") });
            }

            if (!rangeSettings[index].IsInterval) {
                isPolyvalent = (isPolyvalent === true ? isPolyvalent : rangeSettings[index].IsPolyvalent);
            }

            if (canSaveOperation == false) {
                divRange.dateRangeSlider("disable");
            }
        });
    }

    function updateValues() {
        configSlider();
    }

    function disabledInterval(index, showLabel) {
        var sectionParent = scheduleEditCollaboratorTime.getSectionParent(),
            divTime = sectionParent.find('#divTime_' + index);

        divTime.dateRangeSlider("disable");

        if (!showLabel) {
            divTime.dateRangeSlider('values', 0, 0);
            divTime.dateRangeSlider({ valueLabels: "hide" });
        }
    }

    function enabledInterval(index) {
        var rangeSettings = scheduleEditCollaboratorTime.getRangeSettings(),
            sectionParent = scheduleEditCollaboratorTime.getSectionParent(),
            divTime = sectionParent.find('#divTime_' + index),
            minValue,
            maxValue;

        divTime.dateRangeSlider("enable");
        divTime.dateRangeSlider({ valueLabels: "show" });

        $(rangeSettings).each(function (index) {
            if (rangeSettings[index].IsMainRange) {

                minValue = moment.utc(rangeSettings[index].BeginHourWork);
                maxValue = moment.utc(rangeSettings[index].EndHourWork);
                var diff = parseInt(maxValue.diff(minValue, 'hour') / 2);
                maxValue = moment.utc(rangeSettings[index].BeginHourWork);

                minValue.add('hours', diff);
                maxValue.add('hours', diff + 1);

                divTime.dateRangeSlider('values', minValue, maxValue);

                return;
            }
        });
    }

    function show() {
        var sectionParent = scheduleEditCollaboratorTime.getSectionParent();
        sectionParent.find('[data-slider="time"]').dateRangeSlider('resize');
    }

    function init(isFirstTime, canSave) {
        canSaveOperation = canSave;
        sectionParent = scheduleEditCollaboratorTime.getSectionParent();
        configSlider(isFirstTime);

        var rangeSettings = scheduleEditCollaboratorTime.getRangeSettings();
        $(rangeSettings).each(function (index) {
            if (rangeSettings[index].IsPolyvalent) {
                disabledInterval(index, true);
            }
        });
    }

    return {
        init: init,
        disabledInterval: disabledInterval,
        enabledInterval: enabledInterval,
        updateValues: updateValues,
        show: show
    }

}();