var scheduleModalModule = function () {
    //#region Attributes
    var unitList = [];
    var sectionList = [];
    var datePickerConfig = null;
    var storedData = null;
    //#endregion

    //#region Callbacks
    function confirmClick(form, event) {
        var hasError = false;

        $('#modal-section .datepicker').datepicker('hide');

        var startDate = $("#txtStartDateModal").val();
        var endDate = $("#txtEndDateModal").val();

        if (!customControlsModule.isInValidDayOfWeek($("#txtStartDateModal").datepicker('getDate'), 1)) {
            validateModule.appendMessageError(_globalResources.getResource().InvalidDate, $("#txtStartDateModal"), true, true);
            hasError = true;
        }

        if (!customControlsModule.isInValidDayOfWeek($("#txtEndDateModal").datepicker('getDate'), 0)) {
            validateModule.appendMessageError(_globalResources.getResource().InvalidDate, $("#txtEndDateModal"), true, true);
            hasError = true;
        }

        if (hasError) {
            return;
        }

        setTimeout(function () {
            $('#modal-section').fadeOut(100);
        }, 200);

        //Seta valores restantes nas views
        scheduleModule.setSelectedSettings(
            unitList,
            $("#ddlUnitModal").val(),
            sectionList,
            $("#ddlSectionModal").val(),
            $("#txtStartDateModal").val(),
            $("#txtEndDateModal").val());

        storedData = {
            UnitID: $("#ddlUnitModal").val(),
            SectionID: $("#ddlSectionModal").val(),
            StartDate: $("#txtStartDateModal").val().toMSDate(),
            EndDate: $("#txtEndDateModal").val().toMSDate(),
            Type: 1
        };

        sessionInfoModule.setSessionInfo(storedData);
    }

    function dropDownUnitChange() {
        // $('#ddlSectionModal').attr('disabled', 'disabled');
        // $('#ddlSectionModal').next('.customSelect').addClass('customSelectDisabled');

        //Carrega valores no dropdown de seções
        sectionModule.getSections($("#ddlUnitModal").val())
            .done(function (listSections) {
                //Popula DropDown
                // $('#ddlSectionModal').removeAttr('disabled');
                // $('#ddlSectionModal').next('.customSelect').removeClass('customSelectDisabled')
                $("#ddlSectionModal").clearSelect();
                $("#ddlSectionModal").fillSelect(listSections, 'ID', 'Name', true);
                sectionList = listSections;
                selectionSection();
            });
    }
    //#endregion

    function submitModal(e) {
        var form = $('#frmScheduleModal');
        if (form) {
            form.submit();
        }
        if (e) {
            e.stopPropagation();
        }
    }

    function registerEvents() {
        $('#ddlSectionModal, #ddlUnitModal').off('change');
        $('#ddlSectionModal, #ddlUnitModal').on('change', function () {
            if ($(this).find('option[value=""]').length > 0) {
                validateModule.removeMessageError(this, true);
            }
        });
        $('#btnSend').off('click').on('click', submitModal);
    }

    function selectionSection() {
        //Verifica se tem sessão com dados para seção do drop
        if (storedData != null && storedData.SectionID != '')
            $("#ddlSectionModal").setSelectedValue(storedData.SectionID);
    }

    //#region Init
    function init() {
        // $('#ddlSectionModal').attr('disabled', 'disabled');
        tooltipModule.init('frmScheduleModal');
        $('#frmScheduleModal').validate({ // initialize the plugin
            rules: rulesValidation.schedule.modal, // configurate rules
            messages: messagesValidation.getResource().ScheduleModal(), // configura mensagens
            submitHandler: confirmClick
        });

        sessionInfoModule.getSessionInfo(1)
            .done(function (response) {
                storedData = response;
                unitModule.getUnits()
                    .done(function (listUnits) {
                        //Popula DropDown do modal
                        $("#ddlUnitModal").clearSelect();
                        $("#ddlUnitModal").fillSelect(listUnits, 'ID', 'Name', false);
                        unitList = listUnits;
                        // Atribuição das evento change no dropdown de Unidade
                        $("#ddlUnitModal").change(dropDownUnitChange);
                        $("#ddlUnitModal").setSelectedValue(globalAttributes.userInfo.unitID);

                        //Popula os dados que estão na seção
                        if (storedData != null && storedData != '') {
                            $("#ddlUnitModal").setSelectedValue(storedData.UnitID);
                            $("#txtStartDateModal").val(storedData.StartDate.toFormatMomentDate());
                            $("#txtEndDateModal").val(storedData.EndDate.toFormatMomentDate());
                        }
                        dropDownUnitChange();
                    });
            });
        registerEvents();

        customControlsModule.applyDatePickerControl(['txtStartDateModal', 'txtEndDateModal'], true, true, null, null, true);
        customControlsModule.registerKeyUpEnter($("#modal-section"), submitModal);
        maskModule.applyMask("modal-section");
    }
    //endregion

    return {
        init: init
    };

}();