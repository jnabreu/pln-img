var scheduleDayTimelineModule = function () {
    var _lightboxPeriodReturn = null;
    var _lightboxEvReturn = null;

    var VALIDATION_STATUS = {
        VALIDATING: 'validating',
        VALID: 'valid',
        INVALID: 'invalid',
        WARNING: 'warning'
    };

    // keys' names of marked timespans
    var MARK_NAMES = {
        INTERVAL: 'interval',          // when marking a interval
        OTHER_SECTION: 'otherSection', // when marking other section
        OTHER_EVENTS: 'otherEvents',   // when marking events before/after interval
        POLYVALENCE: 'polyvalence',
    };

    var LEFT = -1,
        RIGHT = 1,
        RESIZE_START = 'resizeStart',
        RESIZE_END = 'resizeEnd';

    var DAY_TYPES = {
        WORKING: 'W',
        COMP_REST: 'CREST',
        MAND_REST: 'MREST',
        ABSENCE: 'A',
        NON_WORKING: 'N',
        HOLIDAY: 'H',
    };


    var //_eventNames = {},
        _containerDiv = '#day_layout_container .dhx_cal_container',
        _validationArea = _containerDiv + ' #validationArea',
        _validationStatus = {},
        _originalUnits = [],
        _eventHandlers = [],
        _yUnitsOriginal = null,
        _timelineConfigs = {
            name: null,
            x_unit: "minute",
            x_date: "%i",
            time_step: 15,
            x_step: 15,
            x_size: 96,
            x_start: 0,
            x_length: 96,
            section_autoheight: false,
            y_unit: [],
            y_property: "section_id",
            render: "tree",
            folder_dy: 20,
            round_position: true,
            // collision_limit: 0,
            dy: 19,
            dx: 15,
            event_dy: 19,
            event_min_dy: 19,
            second_scale: {
                x_unit: "hour",
                x_date: "%Hh",
            },
        }

    // structure containing current allocated collaborators
    var _collaboratorsStats = {
        start: null,              // section/workstationType range begin
        end: null,                // section/workstationType range end
        granularity: 15,          // the schedule division step (15 by default)
        allocated: {},            // currently allocated collaborators
    };

    var _currDraggedEvent = null,
        _currEventId = null,
        _currSection = null,
        _currStartDate = null,
        _currEndDate = null,
        _executing = null,
        _currDraggedEvents = null;

    var _currData = {},
        _markedData = {};

    var _durations = {
        day: 24 * 60 * 60 * 1000,
        hour: 60 * 60 * 1000,
        minute: 60 * 1000
    };

    var _minPeriod = 15 * 60000;
    var _marginDuration = 15 * 60000;
    var _expandedDays = [];
    var _validatingCount = 0;

    var _intervalsDefinitions = [
        {
            seqNumber: 2,
            bounderies: {
                left: 1,
                right: 3
            }
        },
        {
            seqNumber: 4,
            bounderies: {
                left: 3,
                right: 5
            }
        },
    ];

    function getDayTypesConsts() {
        return DAY_TYPES;
    }

    function getContainer() {
        return $('#dayDataContent');
    }

    function getValidationArea() {
        return _validationArea;
    }

    function applyStyles() {
        $(_containerDiv + " .dhx_scale_bar").css({ "font-size": "0.8em" });
        $(_containerDiv + " .dhx_scale_bar.dhx_second_scale_bar").css({ "font-size": "1em" });
    }

    function applyLineValidationStyles() {
        $.each(_validationStatus, function (key, value) {
            var events = $.grep(scheduler.getEvents(), function (el) {
                return el.collabID == key &&
                       el.isDayTimelineEvent &&
                       /* (el.seqNumber !== 0 || (el.isSectionPolyvalent || el.isPolyvalent)) && */
                       customControlsModule.compareDatesByDay(el.date, scheduler.getState().date);
            });
            if (events.length === 0) return;
            var id = events[0].id;
            var line = $($(_containerDiv + ' div[event_id="' + id + '"]')[0]);
            var cell = line.parent().parent().prev();
            cell.attr('data-status', value);
        });
    }

    function setSchedulerConfigs(config) {

        scheduler.config.readonly = false;
        scheduler.config.check_limits = false;
        scheduler.config.limit_drag_out = true;
        scheduler.config.time_step = config.granularity;

        // scheduler.config.container_autoresize = true;
        // scheduler.config.delay_render = 100;

        scheduleDayTimelineLightboxModule.initLightbox();
    }

    function attachSchedulerEvents() {
        var _eventNames = scheduleBaseTimelineModule.getLocalEvents();
        for (key in _eventNames) {
            scheduler.detachEvent(_eventNames[key]);
        }

        _eventNames.onBeforeEventChangedEv = scheduler.attachEvent("onBeforeEventChanged", onBeforeEventChangedCallback);
        _eventNames.viewChangeEv = scheduler.attachEvent("onViewChange", onViewChangeCallback);
        _eventNames.beforeViewChangeEv = scheduler.attachEvent("onBeforeViewChange", onBeforeViewChangeCallaback);
        _eventNames.onBeforeDragEv = scheduler.attachEvent("onBeforeDrag", onBeforeDragCallback);
        _eventNames.onDragEndEv = scheduler.attachEvent("onDragEnd", onDragEndCallback);
        _eventNames.onEventDragEv = scheduler.attachEvent("onEventDrag", onEventDragCallback);

        // Lightbox events
        _eventNames.onBeforeLightboxEv = scheduler.attachEvent("onBeforeLightbox", scheduleDayTimelineLightboxModule.onBeforeLightboxCallback);
        _eventNames.onEventSaveEv = scheduler.attachEvent("onEventSave", scheduleDayTimelineLightboxModule.onEventSaveCallback);
        _eventNames.onAfterLightboxEv = scheduler.attachEvent("onAfterLightbox", scheduleDayTimelineLightboxModule.onAfterLightboxCallback);
        _eventNames.onEmptyClickEv = scheduler.attachEvent("onEmptyClick", onEmptyClick);
    }

    function onEmptyClick(date, ev) {
        // scheduler.showLightbox(null);
        return false;
    }

    function registerValidationEvents() {
        $(_validationArea).off('click').on('click', function (e) {
            _validatingCount = 0;
            $(this).empty();
        });

        $(_validationArea)
            .off('schedule.day.validate')
            .on('schedule.day.validate', function (e) {
                setValidationStatus(_globalResources.getResource().schedule.ValidingError,
                                    VALIDATION_STATUS.INVALID);
                _validatingCount = 0;
            });
        $(_containerDiv)
            .off('schedule.day.validateEvent')
            .on('schedule.day.validateEvent', validateEventCallback);
    }

    function registerCloseButton() {
        $(_containerDiv + ' #dayTimelineCloseButton')
            .off('click')
            .on('click', closeTimelineView);
    }

    function registerSaveCollabs() {
        $('#dayDataContent')
            .off('schedule.day.saveCollaborators')
            .on('schedule.day.saveCollaborators', saveCollaborators);
    }

    function registerToggleShowHide() {
        $('#day_layout_container #toggleOptionsMenu')
            .off('click')
            .on('click', toggleOptionsMenu);
    }

    function registerUpdateChartAllocated() {
        $(_containerDiv)
            .off('schedule.day.updateChartAllocated')
            .on('schedule.day.updateChartAllocated', updateChartAllocated);
    }

    function registerUpdateMonthEventsHours() {
        $('#tabMonthData')
            .off('schedule.month.updateHours')
            .on('schedule.month.updateHours', updateMonthEventsHours);
    }

    function registerEvents() {
        registerValidationEvents();
        registerCloseButton();
        registerSaveCollabs();
        registerToggleShowHide();
        registerMenuOptions();
        registerUpdateChartAllocated();
        registerUpdateMonthEventsHours();
    }

    function closeTimelineView(ev) {
        scheduleMonthTimelineModule.closeTimelineView(ev);
    }

    function saveCollaborators() {
        var collaboratorsTimes = [];
        var date = scheduler.getState().date;
        var currentEvents = $.grep(scheduler.getEvents(), function (ev) {
            return customControlsModule.compareDatesByDay(ev.date, date);
        });
        var groupedByCollabID = {};
        $.each(currentEvents, function (index, elem) {
            if (elem.collabID in groupedByCollabID) {
                groupedByCollabID[elem.collabID].push(elem);
            } else {
                groupedByCollabID[elem.collabID] = [elem];
            }
        });
        for (key in groupedByCollabID) {
            var events = groupedByCollabID[key];
            var hasEdit = false;

            $.each(events, function (index, elem) {
                if (elem.hasEdit) {
                    hasEdit = true;
                    return false;
                }
            });

            if (hasEdit) {
                var processedEvents = scheduleDayTimelineEditModule.processEvents(events);
                collaboratorsTimes.push(processedEvents);
            }

        }
        if (collaboratorsTimes.length === 0) {
            dialogModule.showOK(
                _globalResources.getResource().schedule.dayView.SaveCollaboratorsTitle,
                _globalResources.getResource().schedule.dayView.NoCollaboratorsEdited);
            return;
        }
        scheduleDayTimelineEditModule.saveCollaboratorsTimes(collaboratorsTimes, saveCollaboratorsCallback, saveCollaboratorsCallback);
    }

    function saveCollaboratorsCallback(response, params) {
        var date = scheduler.getState().date;
        $(_validationArea).empty();
        dialogModule.showDialog(response);
        if (!params) {
            console.debug("no params save collabs");
            return;
        }
        var savedCollabsIds = params[0];
        var errorCollabsIds = params[1];

        var data = {
            date: date,
            collaborators: savedCollabsIds,
        };
        $('#tabMonthData')
            .trigger('schedule.month.updateHours', data);

        removeLineValidationStatus(savedCollabsIds);
        $.each(errorCollabsIds, function (index, collabID) {
            setLineValidationStatus(VALIDATION_STATUS.INVALID, collabID);
        });
    }

    function setSchedulerTemplates(viewName) {
        scheduler.templates.event_bar_text = defineEventBarText;
        scheduler.templates[viewName + "_scale_label"] = defineScaleLabel;
        scheduler.templates.tooltip_text = defineTooltipText;
        scheduler['filter_' + viewName] = defineFilterDayTimeline;
        // scheduler.xy.nav_height = 15;
        // scheduler.xy.scale_height = 30;
    }

    function setDateRange(start, end) {
        _collaboratorsStats.start = start;
        _collaboratorsStats.end = end;
    }

    function defineScaleLabel(key, label, section) {
        return " ";
    }

    function getTooltipText(start, end, event) {
        var collabsEvents = getCollabEvents(scheduler.getEvents(), event);

        return scheduleTooltipHelper.getTooltipText(start, end, event, collabsEvents);
    }

    function defineTooltipText(start, end, event) {
        var tooltip = '';
        if (event.isFullDayType) {
            tooltip = scheduleTooltipHelper.getFullDayTooltip(start, end, event);
        } else if (event.isSectionPolyvalent || event.isPolyvalent) {
            tooltip = scheduleTooltipHelper.getPolyvalentTooltip(start, end, event);
        } else {
            tooltip = getTooltipText(start, end, event);
        }
        return tooltip;
    }

    // TODO: edit in order to support expanded events 
    function defineEventBarText(start, end, event) {
        /// <summary>
        /// defines the label that will be presented on the event bars.
        /// while dragging it will return the current event hours.
        /// </summary>
        /// <param name="start"></param>
        /// <param name="end"></param>
        /// <param name="event"></param>
        /// <returns type=""></returns>
        var resizeDateFormat = scheduler.date.date_to_str(scheduler.config.hour_date);
        var state = scheduler.getState();
        //if (state.drag_id == event.id) {
        //    if (event.isMainRange && event.seqNumber !== 0) {
        //        var events = getCollabEvents(scheduler.getEvents(), event);
        //        events = $.grep(events, function (el) {
        //            return el.seqNumber !== 0;
        //        });
        //        var minMaxDates = customControlsModule.getMinMaxDate(events, "start_date", "end_date");
        //        start = minMaxDates.minDate;
        //        end = minMaxDates.maxDate;
        //    }
        //    return resizeDateFormat(start) + " - " + resizeDateFormat(end) + " (" + getFormattedDuration(start, end) + ")";
        //}

        if (!(event.seqNumber === 1 || event.isFullDayType)) {
            return "";
        }

        var collabLabel = event.collabLabel ? ("<b>" + (event.enrollmentNumber ? event.enrollmentNumber + " - " : "") + event.collabLabel + "</b>") : "";
        return collabLabel; // + event.text
    };

    function defineFilterDayTimeline(id, event) {
        /// <summary>
        /// filter used to show events on the timline view.
        /// only visible and events belonging to day timeline are accepted
        /// </summary>
        /// <param name="id"></param>
        /// <param name="event"></param>
        /// <returns type=""></returns>
        if (event.isVisible && event.isDayTimelineEvent) {
            return true;
        } else {
            return false;
        }
    }

    function filterByDay(allEvents, date) {
        var filtered = $.grep(allEvents, function (elem) {
            return customControlsModule.compareDatesByDay(elem.date, date);
        });

        return filtered;
    }

    function getViewEvents(date) {
        /// <summary>
        /// get view events. i.e: day timeline events of the selected day
        /// </summary>
        /// <param name="date"></param>
        /// <returns type=""></returns>
        var events = $.grep(scheduler.getEvents(), function (elem) {
            return customControlsModule.compareDatesByDay(elem.date, date) &&
                   elem.isDayTimelineEvent;
        });
        return events;
    }

    function initEvent2(eventType, sourceEvent, defaultProps, overrideProps) {
        var event = $.extend(true, {}, sourceEvent);
        event.isDayTimelineEvent = true; // daily view vs monthly view
        event.eventType = eventType;
        event.hasEdit = false;
        event.hasDelete = false;
        delete event.id;

        for (var key in defaultProps) {
            event[key] = defaultProps[key]
        }

        for (var key in overrideProps) {
            event[key] = overrideProps[key];
        }

        if (!event.start_date || !event.end_date) {
            console.debug(eventType + ": ", "start or end date not defined");
        }

        return event;
    }

    function initEvent(sourceEvent) {
        /// <summary>
        /// expandEvent helper
        /// </summary>
        /// <param name="sourceEvent"></param>
        /// <returns type=""></returns>
        var event = $.extend(true, {}, sourceEvent);
        event.isDayTimelineEvent = true; // daily view vs monthly view
        event.isInterval = false;
        event.isMainRange = true;
        event.hasEdit = false;
        event.hasDelete = false;
        delete event.id;
        return event;
    }

    function createIntervalEvent(sourceEvent, overrideProps) {
        var defaultProps = {
            color: "rgb(2, 124, 122)",  // TODO: change where the color come from
            countAsAllocated: false,
            isInterval: true,
            isMainRange: false,
        };

        return initEvent2("interval", sourceEvent, defaultProps, overrideProps);
    }

    function createMainNoPolyvalent(sourceEvent, overrideProps) {
        var defaultProps = {

        };

        return initEvent2("mainRangeNoPolyvalent", sourceEvent, defaultProps, overrideProps);
    }

    function createMainRangePolyvalent(sourceEvent, overrideProps) {
        var defaultProps = {
            //countAsAllocated: false,
            belongsToPolyvalent: true,
        }

        return initEvent2("mainRangePolyvalent", sourceEvent, defaultProps, overrideProps);
    }

    function createNotPolyvalentToFit(sourceEvent, overrideProps) {
        var defaultProps = {
            isMainRange: false,
            isFill: true,
            isPolyvalent: false,
            isSectionPolyvalent: false,
            color: "rgb(2, 124, 222)",
            belongsToPolyvalent: true,
        };

        return initEvent2("notPolyvalentToFit", sourceEvent, defaultProps, overrideProps);
    }

    function createPolyvalence(sourceEvent, overrideProps) {
        var defaultProps = {
            isMainRange: false,
            type: "polyvalenceEvent",
            countAsAllocated: false,
            color: sourceEvent.workstationTypeColor || "rgb(2, 124, 140)",
            belongsToPolyvalent: true,
        };

        return initEvent2("polyvalence", sourceEvent, defaultProps, overrideProps);
    }

    function expandEvent(eventLines) {
        var res = null;
        if (eventLines === 0) return;

        polyvalentEvents = [];
        notPolyvalentEvents = [];

        $.each(eventLines, function (index, elem) {
            if (elem.isPolyvalent || elem.isSectionPolyvalent) {
                polyvalentEvents.push(elem);
            }
            else {
                notPolyvalentEvents.push(elem);
            }
        });

        if (polyvalentEvents.length > 0) {
            res = expandPolyvalents(notPolyvalentEvents, polyvalentEvents);
        } else if (eventLines.length === 1) {
            var expandedEvents = expandNotPolyvalent(eventLines[0]);
            res = [];
            for (var key in expandedEvents) {
                var event = expandedEvents[key];
                if (event) {
                    res.push(event);
                }
            }
        } else {
            // nothing to do.
        }
        return res;
    }

    function iterateGhostHourArray(start, end, assignmentFn) {
        var retArray = [];
        var diff = _collaboratorsStats.granularity * _durations.minute;
        var i = 0;
        for (var curr = start; +curr <= +end; curr = new Date(curr.getTime() + diff)) {
            retArray[i] = assignmentFn(curr);
            i++;
        }
        return retArray;
    }

    function auxGetFilledArray(range, start, end) {

        var assignmentFn = function (curr) {
            return (+curr >= +range.start_date && +curr < +range.end_date) ? 1 : 0;
        }

        return iterateGhostHourArray(start, end, assignmentFn)
    }

    function auxGetTotalFilledArray(allRanges, start, end) {
        var filledArrays = [];
        var totalFilledArray = [];

        for (rangeKey in allRanges) {
            var range = allRanges[rangeKey];
            filledArrays.push(auxGetFilledArray(range, start, end));
        }

        for (var i = 0; i < filledArrays[0].length; i++) {
            totalFilledArray[i] = 0;
            for (filledArrayKey in filledArrays) {
                var filledArray = filledArrays[filledArrayKey];
                if (filledArray[i] === 1) {
                    totalFilledArray[i] = 1;
                    break;
                }
            }
        }
        return totalFilledArray;
    }

    function getPeriodsFromTotalFilledArray(totalFilledArray, start, end) {
        var newRanges = [];
        var diff = _collaboratorsStats.granularity * _durations.minute;
        var i = 0;
        var searchingNew = true;
        var newRange, isPushed = false;
        for (var curr = start; +curr <= +end; curr = new Date(curr.getTime() + diff)) {
            if (searchingNew) {
                if (totalFilledArray[i] === 0) {
                    newRange = { startDate: curr, endDate: new Date(curr.getTime() + diff) };
                    searchingNew = false;
                    isPushed = false;
                }
            } else {
                if (totalFilledArray[i] === 1) {
                    newRange.endDate = curr;
                    searchingNew = true;
                    newRanges.push(newRange);
                    isPushed = true;
                }
            }
            i++;
        }
        if (!isPushed) {
            newRange.endDate = new Date(curr.getTime() - diff);
            newRanges.push(newRange);
        }
        return newRanges;
    }

    function createNotPolyvalentsToFit(mainRange, polyvalents) {
        var start = mainRange.start_date,
            end = mainRange.end_date;

        // var allRanges = [interval].concat(polyvalents);
        var allRanges = polyvalents;
        var totalFilledArray = auxGetTotalFilledArray(allRanges, start, end);
        var periods = getPeriodsFromTotalFilledArray(totalFilledArray, start, end);

        var notPolyvalentsToFit = $.map(periods, function (el) {
            return createNotPolyvalentToFit(mainRange, {
                start_date: el.startDate,
                end_date: el.endDate,
                countAsAllocated: true,
            });
        });

        return notPolyvalentsToFit;
    }

    // TODO: refactor this
    function expandNotPolyvalent(event) {
        /// <summary>
        /// takes a single event and spans it to 3 events (when applies)
        /// </summary>
        /// <param name="event"></param>
        /// <returns type=""></returns>

        var result = { before: null, interval: null, after: null, extraInterval: null, extra: null };

        if (event.isFullDayType) {
            return getFullDayEvent(event);
        }

        var before = initEvent(event);
        if (!event.intervalStart || !event.intervalEnd) {
            before.start_date = event.dayView.start_date;
            before.end_date = event.dayView.end_date;
            before.seqNumber = 1;
            result.before = before;
            return result;
        }

        if (!event.intervalStart2 || !event.intervalEnd2) {
            var after = initEvent(event);

            before.start_date = event.dayView.start_date;
            before.end_date = event.intervalStart;
            before.seqNumber = 1;

            var interval = createIntervalEvent(event, {
                start_date: event.intervalStart,
                end_date: event.intervalEnd,
                seqNumber: 2,
            });

            after.start_date = event.intervalEnd;
            after.end_date = event.realEndDate;
            after.seqNumber = 3;

            result.before = before;
            result.interval = interval;
            result.after = after;

            return result;
        }

        before.start_date = event.dayView.start_date;
        before.end_date = event.intervalStart;
        before.seqNumber = 1;

        var interval = createIntervalEvent(event, {
            start_date: event.intervalStart,
            end_date: event.intervalEnd,
            seqNumber: 2,
        });

        var after = initEvent(event);

        after.start_date = event.intervalEnd;
        after.end_date = event.intervalStart2;
        after.seqNumber = 3;

        extraInterval = createIntervalEvent(event, {
            start_date: event.intervalStart2,
            end_date: event.intervalEnd2,
            seqNumber: 4,
        });

        var extra = initEvent(event);
        extra.start_date = event.intervalEnd2;
        extra.end_date = event.realEndDate;
        extra.seqNumber = 5;

        result.before = before;
        result.interval = interval;
        result.after = after;
        result.extraInterval = extraInterval;
        result.extra = extra;

        return result;
    }

    function getFullDayEvent(event) {
        var result = { before: null, interval: null, after: null };
        var before = initEvent(event);
        before.type = event.dayView.type ? event.dayView.type : before.type;
        before.start_date = event.rangeBegin;
        before.end_date = event.rangeEnd;
        result.before = before;
        return result;
    }

    function expandPolyvalents(events, polyvalentEvents) {
        var notPolyvalentEvent = events[0];
        var allEvents = events.concat(polyvalentEvents);

        var minMax = customControlsModule.getMinMaxDate(allEvents, "realStartDate", "realEndDate");
        var dayView = {
            start_date: minMax.minDate,
            end_date: minMax.maxDate,
        };
        var mainRangePolyvalent = createMainRangePolyvalent(notPolyvalentEvent, {
            start_date: minMax.minDate,
            end_date: minMax.maxDate,
            realStartDate: minMax.minDate,
            realEndDate: minMax.maxDate,
            dayView: dayView,
        });

        //var interval = createIntervalEvent(notPolyvalentEvent, {
        //    start_date: notPolyvalentEvent.intervalStart,
        //    end_date: notPolyvalentEvent.intervalEnd,
        //    belongsToPolyvalent: true,
        //});

        var mainRangeEvents = [];
        var expanded = expandNotPolyvalent(mainRangePolyvalent);
        for (var key in expanded) {
            var event = expanded[key];
            if (event) {
                event.belongsToPolyvalent = true;
                //event.countAsAllocated = true;
                mainRangeEvents.push(event);
            }
        }

        var polyvalents = $.map(polyvalentEvents, function (ev) {
            return createPolyvalence(ev, {
                start_date: ev.realStartDate,
                end_date: ev.realEndDate
            });
        });

        // var notPolyvalentsToFit = createNotPolyvalentsToFit(mainRangePolyvalent, polyvalents);

        // return mainRangeEvents.concat(polyvalents).concat(notPolyvalentsToFit);
        return mainRangeEvents.concat(polyvalents);
    }

    function setDayTimelineEvents(date) {
        /// <summary>
        /// work days events are expanded. 
        /// i.e: a single event will give place to 3 events (when applies): before interval, interval and after interval
        /// </summary>
        /// <returns type=""></returns>
        var alreadyProcessed = false;
        for (var i = 0; i < _expandedDays.length; i++) {
            if (customControlsModule.compareDatesByDay(_expandedDays[i], date)) {
                alreadyProcessed = true;
            }
        }

        if (!alreadyProcessed) {
            _expandedDays.push(date);
        }

        var expandedEvents = [];
        var eventsHash = scheduleMonthTimelineModule.getEventsHash();
        var auxDate;
        for (var key in eventsHash) {
            if (customControlsModule.compareDatesByDay(date, new Date(parseInt(key)))) {
                auxDate = key;
                break;
            }
        }

        var events = eventsHash[auxDate];
        if (!events || events.length === 0) {
            console.log('no events');
            return;
        }
        var chartData = scheduleMonthTimelineModule.getChartData(date, "day");

        for (var first in events) {
            if (events && events[first] && events[first].length > 0 &&
                    events[first][0].rangeBegin && events[first][0].rangeEnd) {
                setDateRange(events[first][0].rangeBegin, events[first][0].rangeEnd);
                break;
            };
        }

        if (!alreadyProcessed) {
            $.each(events, function (index, elem) {
                expandedEvents = expandedEvents.concat(expandEvent(elem));
            });
            scheduler.parse(expandedEvents, "json");
        }
    }

    function trimMessage(message) {

        if (message) {

            var size = 60;
            var lines = [];
            var currLineLength = 0;
            var currIndex = 0;
            var splitMessage;
            var auxSplitMessage;
            var splitMessages = message.replace(/\n$/g, "").split("\r\n");

            for (var j = 0; j < splitMessages.length; j++) {

                splitMessage = splitMessages[j].split(" ");
                auxSplitMessage = splitMessages[j].split(" ");

                for (var i = 0; i < splitMessage.length; i++) {
                    currLineLength += splitMessage[i].length + 1;
                    currIndex++;
                    if (currLineLength > size) {
                        currLineLength = 0;
                        var line = auxSplitMessage.splice(0, currIndex + 1).join(" ");
                        currIndex = 0;
                        lines.push(line);
                    }
                }
                if (auxSplitMessage.length > 0) {
                    lines.push(auxSplitMessage.join(" "));
                }
            }

            return lines.length > 0 ? lines.join("<br>") : message;
        } else {
            return "";
        }
    }

    function setValidationStatus(message, status, spinning) {
        /// <summary>
        /// sets the validation message.
        /// used when a event is dragged and validated
        /// </summary>
        /// <param name="message"></param>
        /// <param name="status"></param>
        /// <param name="spinning"></param>
        /// <returns type=""></returns>

        if (status === VALIDATION_STATUS.VALIDATING) {
            _validatingCount++;
        } else {
            _validatingCount--;
        }

        if (_validatingCount > 0 && status !== VALIDATION_STATUS.VALIDATING) {
            return;
        }

        message = trimMessage(message);

        spinning = spinning || false;
        var res = $(_containerDiv + " #validationArea")
            .empty()
            .append("<div class='message' data-status='" + status + "'>" + message + "<div>");

        if (spinning) {
            res.append("<div id='loaderContainer'><span class='mini-loader'></span></div>");
        }
    }

    function validationSuccess(message, params) {
        message = _globalResources.getResource().schedule.Valid;
        setValidationStatus(message, VALIDATION_STATUS.VALID);
        setLineValidationStatus(VALIDATION_STATUS.VALID, params[0][0].collabID);
    }

    function validationError(message, params) {
        //if (params && params.length > 0) {
        //    restoreEventsToOriginalPosition(params[0]);
        //}

        setValidationStatus(message, VALIDATION_STATUS.INVALID);
        setLineValidationStatus(VALIDATION_STATUS.INVALID, params[0][0].collabID);
    }

    function validationWarning(message, params) {
        setValidationStatus(message, VALIDATION_STATUS.WARNING);
        setLineValidationStatus(VALIDATION_STATUS.WARNING, params[0][0].collabID);
    }

    function setLineValidationStatus(status, collabID) {
        if (!collabID) return;
        _validationStatus[collabID] = status;
        applyLineValidationStyles();
    }

    function changeEditToFalse(collabsIDs) {
        $.each(collabsIDs, function (index, collabID) {
            var collabsEvents = $.grep(scheduler.getEvents(), function (ev) {
                return ev.collabID == collabID;
            });
            $.each(collabsEvents, function (index, ev) {
                scheduler.getEvent(ev.id).hasEdit = false;
            });
        });
    }

    function removeLineValidationStatus(collabsIds) {
        if (!collabsIds) return;
        $.each(collabsIds, function (index, collabID) {
            _validationStatus[collabID] = '';
        });
        applyLineValidationStyles();
        changeEditToFalse(collabsIds);
    }

    function getCollabEventsAll(events, eventToMatch) {
        if (!events || events.length === 0 || !eventToMatch) return;

        return $.grep(events, function (ev) {
            return ev.collabID == eventToMatch.collabID &&
                   customControlsModule.compareDatesByDay(ev.date, eventToMatch.start_date);
        });
    }

    function getCollabEvents(events, eventToMatch) {
        if (!events || events.length === 0 || !eventToMatch) return;

        return $.grep(events, function (ev) {
            return ev.collabID == eventToMatch.collabID &&
                   customControlsModule.compareDatesByDay(ev.date, eventToMatch.start_date) &&
                   ev.isDayTimelineEvent;
        });
    }

    function restoreEventsToOriginalPosition(originalEvents) {
        if (originalEvents.length === 0) return;

        var date = originalEvents[0].start_date
        $.each(originalEvents, function (index, ev) {
            var event = scheduler.getEvent(ev.id);
            if (!event) return;
            event.start_date = ev.start_date;
            event.end_date = ev.end_date;
            scheduler.updateEvent(event.id);
        });

        updateChartAllocated(date);
    }

    function updateChartAllocated(ev, data) {
        /// <summary>
        /// updates the chart based on dhx events
        /// </summary>
        /// <returns type=""></returns>
        var date = data.date;
        var events = getViewEvents(date);
        var data = getCollaboratorsChartData(events, null, events[0].granularity);

        // scheduleDayChartModule.updateAllocated(data.allocated);
        $('#dayDataContent #day_layout_container').trigger('schedule.chart.updateAllocated', { allocated: data.allocated });
    }

    function toggleOptionsMenu(ev, data) {
        var menuOpt = $('#day_layout_container #optMenuDayView');
        menuOpt.fadeToggle(250);
        $('body').off('click').on('click', function (ev) {
            var button = $('#day_layout_container #toggleOptionsMenu');
            var menu = $('#day_layout_container #optMenuDayViewContainer');
            var target = $(ev.target);
            if ((!button.is(target) && button.has(target).length === 0) &&
                (!menu.is(target) && menu.has(target).length === 0)) {
                menuOpt.fadeOut(250);
            }
        });
    }

    function registerMenuOptions() {
        $('#day_layout_container #optMenuDayView input[type="checkbox"]')
            .off('change')
            .on('change', filterCollaborators);

        $('#day_layout_container #optMenuDayView input[type="radio"]')
            .off('change')
            .on('change', sortCollaboratorsCurrDate);
    }

    function getMenuFilterTypes() {
        var opts = $('#day_layout_container #filter-form div input');
        var filterTypes = [];
        for (var i = 0; i < opts.length; i++) {
            if ($(opts[i]).is(':checked')) {
                filterTypes.push($(opts[i]).val());
            }
        }
        return filterTypes;
    }

    function filterCollaborators(ev) {
        setFilteredEvents(scheduler.getState().date);
        // applyLineValidationStyles(); TODO: when filtering, continue to show invalid lines
    }

    function menuValuesToTypes(types) {
        var dataTypes = {
            isWorkingDay: false,
            isMandRestDay: false,
            isCompRestDay: false,
            isAbsenceDay: false,
            isNonWorkingDay: false,
            isHoliday: false,
        };

        for (var i = 0; i < types.length; i++) {
            if (types[i] === "W") dataTypes.isWorkingDay = true;
            else if (types[i] === "MR") dataTypes.isMandRestDay = true;
            else if (types[i] === "CR") dataTypes.isCompRestDay = true;
            else if (types[i] === "A") dataTypes.isAbsenceDay = true;
            else if (types[i] === "N") dataTypes.isNonWorkingDay = true;
            else if (types[i] === "H") dataTypes.isHoliday = true;
        }
        return dataTypes;
    }

    function getYUnits() {
        return _yUnitsOriginal;
    }

    function getFilteredYUnits(dayTypes, date) {
        var dayEvents, collabIDs, unique, outObj, yUnits;

        dayEvents = getDayEventsByType(dayTypes, date);
        collabIDs = mapEventsToIds(dayEvents);
        unique = collabIDs.unique();
        yUnits = filterYUnits(getYUnits(), unique);

        return yUnits;
    }

    function updateTimeline() {
        // scheduleModule.showPageLoader('day.createTimelineView');
        //setTimeout(function () {
        scheduler.createTimelineView(_timelineConfigs);
        // scheduleModule.hidePageLoader('day.createTimelineView');
        //}, 0);
    }

    function filterYUnits(yUnitsOriginal, eventsToShow) {
        var start = new Date().getTime();
        var res = $.grep(yUnitsOriginal, function (el, index) {
            if ($.inArray(el.id, eventsToShow) > -1) {
                el['show'] = true;
                return true;
            } else {
                el['show'] = false;
                return false;
            }
        });

        var stop = new Date().getTime();
        return res;
    }

    function getDayEventsByType(dayTypes, date) {
        var types = {
            isWorkingDay: dayTypes.isWorkingDay || false,
            isMandRestDay: dayTypes.isMandRestDay || false,
            isCompRestDay: dayTypes.isCompRestDay || false,
            isAbsenceDay: dayTypes.isAbsenceDay || false,
            isNonWorkingDay: dayTypes.isNonWorkingDay || false,
            isHoliday: dayTypes.isHoliday || false,
        };

        var res = $.grep(scheduler.getEvents(), function (ev) {
            return cond = customControlsModule.compareDatesByDay(ev.date, date) &&
                          ev.isDayTimelineEvent && (
                          ((ev.dayType === DAY_TYPES.WORKING) && types.isWorkingDay) ||
                          ((ev.dayType === DAY_TYPES.MAND_REST) && types.isMandRestDay) ||
                          ((ev.dayType === DAY_TYPES.COMP_REST) && types.isCompRestDay) ||
                          ((ev.dayType === DAY_TYPES.ABSENCE) && types.isAbsenceDay) ||
                          ((ev.dayType === DAY_TYPES.NON_WORKING) && types.isNonWorkingDay) ||
                          ((ev.dayType === DAY_TYPES.HOLIDAY) && types.isHoliday));
        });
        return res;
    }

    function getDayEventsCount(date) {
        var dayEvents = [],
            workingDays = [],
            counters = { W: 0, MR: 0, CR: 0, A: 0, N: 0, H: 0 },
            eventsHash = scheduleMonthTimelineModule.getEventsHash();

        dayEvents = $.grep(scheduler.getEvents(), function (ev) {
            return customControlsModule.compareDatesByDay(ev.date, date) &&
                   ev.isDayTimelineEvent;
        });

        for (var i = 0; i < dayEvents.length; i++) {
            var event = dayEvents[i];
            if (event.dayType === DAY_TYPES.WORKING) workingDays.push(event);
            if (event.dayType === DAY_TYPES.MAND_REST)++counters.MR;
            if (event.dayType === DAY_TYPES.COMP_REST)++counters.CR;
            if (event.dayType === DAY_TYPES.ABSENCE)++counters.A;
            if (event.dayType === DAY_TYPES.NON_WORKING)++counters.N;
            if (event.dayType === DAY_TYPES.HOLIDAY)++counters.H;
        }

        counters.W = workingDays.map(function (ev) { return ev.collabID }).unique().length;

        return counters;
    }

    function mapEventsToIds(events) {
        return $.map(events, function (el) {
            return el.collabID;
        });
    }

    function sortCollaboratorsCurrDate() {
        sortCollaborators(scheduler.getState().date);
    }

    function sortCollaborators(date) {
        var sortType = $('#day_layout_container #sort-form div input:checked').val(),
            sortFn = null,
            dayEvents = [],
            filteredYUnits = [];

        if (sortType === 'hour') sortFn = sortBySchedule;
        else if (sortType === 'name') sortFn = sortByName;
        else if (sortType === 'mecnr') sortFn = sortByMecNr;

        var yUnits = getYUnits();
        var sortedYUnitsAll = sortFn(yUnits, date);
        _yUnitsOriginal = sortedYUnitsAll;

        for (var i = 0; i < _yUnitsOriginal.length; i++) {
            if (_yUnitsOriginal[i].show) {
                filteredYUnits.push(_yUnitsOriginal[i]);
            }
        }

        _timelineConfigs.y_unit = filteredYUnits;
        scheduler.createTimelineView(_timelineConfigs);

        applyLineValidationStyles();
    }

    function sortBySchedule(yUnits, date) {
        var dayEvents = [],
            dayEventsIds = [],
            sortedYUnits = [];

        dayEvents = getDayEvents(date);
        dayEvents.sort(sortEventsByHour);
        dayEventsIds = dayEvents.map(function (el) { return el[0].collabID; })
        sortedYUnits = yUnits.sortByArray(dayEventsIds, "id");

        return sortedYUnits;
    }

    function getDayEvents(date) {
        var eventsHash = [],
            dayEvents = [],
            dayEventsObj = {};

        eventsHash = scheduleMonthTimelineModule.getEventsHash();
        for (var key in eventsHash) {
            var cond = customControlsModule.compareDatesByDay(new Date(parseInt(key)), date);
            if (cond) {
                dayEventsObj = eventsHash[key];
                break;
            }
        }
        for (var key in dayEventsObj) {
            dayEvents.push(dayEventsObj[key]);
        }
        return dayEvents;
    }

    function sortEventsByHour(a, b) {
        a = a[0], b = b[0];
        if (!a.isFullDayType && b.isFullDayType) return -1;
        else if (a.isFullDayType && !b.isFullDayType) return 1;
        else if (!a.isFullDayType && !b.isFullDayType) {
            if (+a.realStartDate < +b.realStartDate) return -1;
            else if (+a.realStartDate > +b.realStartDate) return 1;
            else {
                if (+a.realEndDate < +b.realEndDate) return -1;
                else if (+a.realEndDate > +b.realEndDate) return 1
                else return 0;
            }
        } else if (a.isFullDayType && b.isFullDayType) {
            if (a.dayType < b.dayType) return -1;
            else if (a.dayType > b.dayType) return 1;
            else {
                if (a.collabLabel < b.collabLabel) return -1
                else if (a.collabLabel > b.collabLabel) return 1;
                else return 0;
            }
        }
    }

    function splitCollabLabel(label) {
        if (!label) return;
        if (label.indexOf('-') === -1) {
            return {
                mecNr: "",
                name: label.trim(),
            }
        }
        var a = label.split('-');
        return {
            mecNr: a[0].trim(),
            name: a[1].trim(),
        };
    }

    function sortByName(yUnits) {
        yUnits.sort(sortYUnitsByName);
        return yUnits;
    }

    function sortYUnitsByName(a, b) {
        var nameA = splitCollabLabel(a.originalLabel).name;
        var nameB = splitCollabLabel(b.originalLabel).name;

        if (nameA == nameB) return 0;
        return (nameA < nameB) ? -1 : 1;
    }

    function sortByMecNr(yUnits) {
        yUnits.sort(sortYUnitsByMecNr);
        return yUnits;
    }

    function sortYUnitsByMecNr(a, b) {
        var mecNrA = splitCollabLabel(a.originalLabel).mecNr;
        var mecNrB = splitCollabLabel(b.originalLabel).mecNr;

        if (mecNrA == mecNrB) return 0;
        return (mecNrA < mecNrB) ? -1 : 1;
    }

    function filterByIndex(array, indexes) {
        var res = $.grep(array, function (el, index) {
            return $.inArray(index, indexes) > -1;
        });
        return res;
    }

    function updateMonthEventsHours(ev, data) {
        var collabsIDs = data.collaborators;
        if (collabsIDs.length === 0) return;

        $.each(collabsIDs, function (index, collabID) {
            var auxEvent = {
                collabID: collabID,
                start_date: data.date,
            };
            var events = getCollabEventsAll(scheduler.getEvents(), auxEvent);

            var monthEventArray = $.grep(events, function (ev) {
                return !ev.isDayTimelineEvent && ev.seqNumber === 0;
            });

            var dayTimelineEvents = $.grep(events, function (ev) {
                return ev.isDayTimelineEvent;
            });

            if (monthEventArray.length === 0) return;
            if (dayTimelineEvents.length === 0) return;

            var monthEvent = monthEventArray[0];
            var minMax = customControlsModule.getMinMaxDate(dayTimelineEvents, 'start_date', 'end_date');

            monthEvent.text = scheduleMonthTimelineModule.getWorkTypeLabel(minMax.minDate, minMax.maxDate);
            scheduler.updateEvent(monthEvent.id);
        });
    }

    function updateChart(date, granularity) {
        /// <summary>
        /// updates the chart based on dhx events
        /// </summary>
        /// <returns type=""></returns>

        var events = getViewEvents(date);
        var extraChartData = scheduleMonthTimelineModule.getChartData(date, "day");
        var data = getCollaboratorsChartData(events, extraChartData, granularity);
        scheduleDayChartModule.updateChart(null, data, false); // elem, data, isFirstTime
    }

    function getIntervalEvent(event, _currSection, intervalSeqNumber) {
        /// <summary>
        /// given a a collaborator event, the interval event of that collaborator is returned
        /// </summary>
        /// <param name="event"></param>
        /// <param name="_currSection"></param>
        /// <returns type=""></returns>
        var res = $.grep(scheduler.getEvents(), function (ev) {
            return customControlsModule.compareDatesByDay(event.date, ev.date) &&
                ev.section_id === _currSection &&
                ev.seqNumber === intervalSeqNumber &&
                ev.isDayTimelineEvent === true;
        });
        return res.length > 0 ? res[0] : null;
    }

    function getOtherEvents(event, _currSection) {
        /// <summary>
        /// given a collaborator event, the events with a different seqNumber are returned
        /// i.e: given an event with seqNumber 1, events with seqNumber 2 and 3 are returned
        /// </summary>
        /// <param name="event"></param>
        /// <param name="_currSection"></param>
        /// <returns type=""></returns>
        var otherEvents = $.grep(scheduler.getEvents(), function (ev) {
            return customControlsModule.compareDatesByDay(event.date, ev.date) &&
                ev.section_id === _currSection &&
                ev.seqNumber !== event.seqNumber &&
                ev.isPolyvalent === false &&
                ev.isSectionPolyvalent === false &&
                ev.isDayTimelineEvent === true;
        });
        return otherEvents;
    }

    function getMainOtherPolyvalentEvents(event, _currSection) {
        /// <summary>
        /// gets main range events but not polyvalent ones
        /// </summary>
        /// <param name="event"></param>
        /// <param name="_currSection"></param>
        /// <returns type=""></returns>
        var mainRangePolyvalents = $.grep(scheduler.getEvents(), function (ev) {
            return customControlsModule.compareDatesByDay(event.date, ev.date) &&
                ev.section_id === _currSection &&
                ev.belongsToPolyvalent &&
                ev.isPolyvalent === false &&
                ev.isSectionPolyvalent === false &&
                ev.isInterval === false &&
                ev.isDayTimelineEvent === true;
        });
        return mainRangePolyvalents;
    }

    function getPolyvalences(event, _currSection) {
        var polyvalences = $.grep(scheduler.getEvents(), function (ev) {
            return customControlsModule.compareDatesByDay(event.date, ev.date) &&
                ev.section_id === _currSection &&
                ev.belongsToPolyvalent &&
                ev.isAbsenceWorkstation === false &&
                (ev.isPolyvalent || ev.isSectionPolyvalent) &&
                ev.isDayTimelineEvent;
        });
        return polyvalences;
    }

    function getAbsenceWorkstation(event, _currSection, isFixed) {
        var absenceWorkstation = $.grep(scheduler.getEvents(), function (ev) {
            return customControlsModule.compareDatesByDay(event.date, ev.date) &&
                ev.section_id === _currSection &&
                ev.isAbsenceWorkstation === true &&
                ev.isFixedWorkstation === isFixed &&
                ev.isDayTimelineEvent;
        });
        return absenceWorkstation;
    }

    function getOtherPolyvalences(event, currSection) {
        var otherPolyvalences = $.grep(scheduler.getEvents(), function (ev) {
            return customControlsModule.compareDatesByDay(event.date, ev.date) &&
                ev.section_id === _currSection &&
                event.id !== ev.id &&
                ev.belongsToPolyvalent &&
                (ev.isPolyvalent || ev.isSectionPolyvalent) &&
                ev.isDayTimelineEvent === true;
        });
        return otherPolyvalences;
    }

    function validateEventCallback(ev, data) {
        validateEvent(data.event);
    }

    function validateEvent(event) {
        var events = getCollabEvents(scheduler.getEvents(), event);
        var validate = true;
        $.each(events, function (index, elem) {
            //if (elem.isFullDayType) {
            //    fullDayType = true;
            //    return false;
            //}
            if (elem.dayType === DAY_TYPES.ABSENCE || elem.dayType == DAY_TYPES.HOLIDAY) {
                validate = false;
            }

        });
        if (!validate) return;

        // set validation message to validating/on progress
        setValidationStatus(
            _globalResources.getResource().schedule.Validating + "...",
            VALIDATION_STATUS.VALIDATING,
            true
        );

        // validates events against the server
        scheduleDayTimelineEditModule.validateCollaboratorTime(
            events,
            validationSuccess,
            validationError,
            validationWarning,
            [_currDraggedEvents]
        );

    }

    function forceOnBeforeEventChanged(ev, data) {
        // mocks a dhtmlx handler
        var newEv = {},
            jsEv = {},
            isNew = false,
            originalEv = data.originalEv;

        onBeforeEventChangedCallback(newEv, jsEv, isNew, originalEv);
    }

    // #region Scheduler moves
    function onBeforeEventChangedCallback(newEv, ev, isNew, originalEv) {
        /// <summary>
        /// before event changes are saved callback.
        /// validions are made in order to verify if the event can be changed
        /// also, dragging events to sections/groups/lines of other collaborators is not allowed;
        /// </summary>
        /// <param name="newEv"></param>
        /// <param name="ev"></param>
        /// <param name="isNew"></param>
        /// <param name="originalEv"></param>
        /// <returns type=""></returns>

        if (isNew) {
            return false;
        }

        validateEvent(originalEv);
        return true;
    }

    function onBeforeDragCallback(id, mode, e) {
        _currDraggedEventRef = scheduler.getEvent(id);                  // referenced object
        _currDraggedEvent = $.extend(true, {}, scheduler.getEvent(id)); // copied object
        _currData.currStartDateTime = _currDraggedEventRef ? _currDraggedEventRef.start_date.getTime() : null;
        _currDraggedStartOrEnd = null;

        var aux = null;
        if ((aux = $(e.target).attr('class')) != null) {
            if (aux.indexOf('start') > -1) {
                _currDraggedStartOrEnd = RESIZE_START;
            } else if (aux.indexOf('end') > -1) {
                _currDraggedStartOrEnd = RESIZE_END;
            }
        }

        var event = scheduler.getEvent(id);
        if (!event) return;

        var events = getCollabEvents(scheduler.getEvents(), event);
        if (events && events.length > 0) {
            _currDraggedEvents = $.map(events, function (ev) {
                return $.extend(true, {}, ev);
            });
        }

        // if is approved, cannot move
        if (event.situation === 'A') {
            return false;
        }

        if (event.isFullDayType) {
            if (event.dayType === DAY_TYPES.MAND_REST ||
                event.dayType === DAY_TYPES.COMP_REST ||
                event.dayType === DAY_TYPES.NON_WORKING) {
                // As full day type events must not move, false is returned. 
                // But when false is returned 'onBeforeEventChangedCallback' is not called. 
                // Here 'onBeforeEventChangedCallback' is forced to execute
                $(_containerDiv).trigger('schedule.day.validateEvent', { event: event });
            }
            return false;
        }

        if (_currDraggedEvent.isFixedWorkstation) {
            return false;
        } 
        
        return true;
    }

    function onDragEndCallback() {
        // var eventObj = _currDraggedEvent;
        // scheduler._drag_id = null;
        // if (eventObj) {
        //     scheduler.updateEvent(eventObj.id);
        // }
        if (!_currDraggedEvent.id) return;
        scheduler.getEvent(_currDraggedEvent.id).hasEdit = true;
        redrawChart(_currDraggedEvent.id, _currDraggedEvent.start_date);
        applyStyles();
        applyLineValidationStyles();
    }

    function onBeforeViewChangeCallaback(oldMode, oldDate, newMode, newDate) {
        if (+newDate !== +oldDate) {
            if (newMode === _timelineConfigs.name) {
                setDayTimelineEvents(newDate);
                _validationStatus = {};
            }
            if (newMode === oldMode && newMode != 'timeline_month_data') {
                setFilteredEvents(newDate, true, null, true);
                sortCollaborators(newDate);
            }
        }
        return true;
    }

    function onViewChangeCallback(newMode, newDate) {
        if (newMode === _timelineConfigs.name) {
            $(_containerDiv + " #validationArea").empty();
            updateChart(newDate, _timelineConfigs.x_step);
            applyStyles();
        }
    }

    function onEventDragCallback(id, mode, e) {
        // var actionData = scheduler.getActionData(e);
        if (_currEventId !== id) {
            _currEventId = id;
            _currSection = scheduler.getEvent(id).section_id;
            _currData.currStartDate = null;
            _currData.currEndDate = null;
        }

        var event = scheduler.getEvent(id);

        preventInvalidActions(event, mode, _currSection);
        moveMainRange(event, mode, _currData, _currSection)
        moveInterval(event, mode, _currSection);
        movePolyvalence(event, mode, _currSection);
        changeAbsenceWorkstation(event, true);
        
        redrawChart(id, _currData, false);
        return true;
    }

    function preventInvalidActions(event, mode, currSection) {
        // prevents event to be dragged out of its line

        //if (+event.end_date - +event.start_date <= _minPeriod) {
        //    event.end_date = new Date(+event.start_date + _minPeriod);
        //    scheduler.updateEvent(event.id);
        //}

        if (_currDraggedEvent.section_id !== event.section_id) {
            event.section_id = _currDraggedEvent.section_id;
            scheduler.updateEvent(event.id);
        }
    }

    function getLeftAndRight(bounderies, event, currSection, getterFunction) {
        var otherEvents = getterFunction(event, currSection);
        if (!otherEvents || otherEvents.length === 0) {
            return { left: null, right: null };
        }

        var eventsLeft = $.grep(otherEvents, function (ev) {
            return ev.seqNumber === bounderies.left;
        });

        var eventsRight = $.grep(otherEvents, function (ev) {
            return ev.seqNumber === bounderies.right;
        });

        var left = eventsLeft.length > 0 ? eventsLeft[0] : null;
        var right = eventsRight.length > 0 ? eventsRight[0] : null;

        return {
            left: left,
            right: right,
        };
    }

    function moveMainRange(event, mode, currData, currSection) {
        scheduler.unmarkTimespan(_markedData[MARK_NAMES.OTHER_EVENTS]);
        if (event.seqNumber === 1 || event.seqNumber === 3 || event.seqNumber == 5) {
            if (mode === "move") {
                moveMainRangeMoveMode(event, currData, currSection);
            } else if (mode === "resize") {
                moveMainRangeResizeMode(event, currData, currSection);
            } else {
                console.log("Unrecognized mode")
            }
        }
    }

    function keepEventsInsideRangeLimits(eventsData, newStart, newEnd, leftLimit, rightLimit) {
        if (+newStart < leftLimit) {
            keepInsideLimit(LEFT, eventsData, leftLimit);
        } else {
            keepInsideLimit(RIGHT, eventsData, rightLimit);
        }
    }

    function keepInsideLimit(direction, eventsData, limit) {
        /// <summary>
        /// keeps contigous events inside limits
        /// </summary>
        /// <param name="direction"></param>
        /// <param name="eventsData"></param>
        /// <param name="limit"></param>
        /// <returns type=""></returns>

        if (direction === LEFT) {
            eventsData[0].event.start_date = limit;
            eventsData[0].event.end_date = new Date(+limit + eventsData[0].duration);
            scheduler.updateEvent(eventsData[0].event.id);

            for (var i = 1; i < eventsData.length; i++) {
                var event = eventsData[i].event;
                var eventDuration = eventsData[i].duration;

                event.start_date = eventsData[i - 1].event.end_date;
                event.end_date = new Date(+event.start_date + eventDuration);
                scheduler.updateEvent(event.id);
            }
        } else if (direction === RIGHT) {
            var lastEvent = eventsData[eventsData.length - 1].event;
            var lastEventDuration = eventsData[eventsData.length - 1].duration;

            lastEvent.end_date = limit;
            lastEvent.start_date = new Date(+lastEvent.end_date - lastEventDuration);
            scheduler.updateEvent(lastEvent.id);

            for (var i = eventsData.length - 2; i > -1; i--) {
                var event = eventsData[i].event;
                var eventDuration = eventsData[i].duration;

                event.end_date = eventsData[i + 1].event.start_date;
                event.start_date = new Date(+event.end_date - eventDuration);
                scheduler.updateEvent(event.id);
            }
        } else {
            console.debug("can't do this")
        }
    }

    function getEventsData(event, currSection) {
        var otherEvents = getOtherEvents(event, currSection);
        var duration = +event.end_date - +event.start_date;
        var eventsData = [];

        eventsData.push({
            event: event,
            duration: duration,
            seqNumber: event.seqNumber,
        });

        for (var i = 0; i < otherEvents.length; i++) {
            var ev = otherEvents[i];
            var dur = +ev.end_date - +ev.start_date;

            eventsData.push({
                event: ev,
                duration: dur,
                seqNumber: ev.seqNumber,
            });
        }

        eventsData.sort(function (a, b) {
            return a.seqNumber - b.seqNumber;
        });

        return eventsData;
    }

    function getMoveContiguousData(event, currData, currSection) {
        var otherEvents = getOtherEvents(event, currSection),
            diff = +event.start_date - currData.currStartDateTime,  // how much the event moved left or right
            eventsData = getEventsData(event, currSection),
            newStart = null,
            newEnd = null,
            start = null,
            end = null,
            minSeq = null,
            maxSeq = null;

        if (eventsData.length > 0) {
            var firstEv = eventsData[0].event;
            var lastEv = eventsData[eventsData.length - 1].event;
            start = firstEv.start_date;
            end = lastEv.end_date;
            newStart = new Date(+start + diff);
            newEnd = new Date(+end + diff);
            minSeq = firstEv.seqNumber;
            maxSeq = lastEv.seqNumber;
        } else {
            console.debug('no events data');
        }

        var polyvalences = getPolyvalences(event, _currSection);
        var fixedAbsenceWorkstations = getAbsenceWorkstation(event, _currSection, true);
        var polyvalencesData = null;
        if (polyvalences.length > 0) {
            if (fixedAbsenceWorkstations.length > 0){
                for (var i = 0; i < fixedAbsenceWorkstations.length; i++) {
                    polyvalences.push(fixedAbsenceWorkstations[i]);
                }
            }
            polyvalencesData = getPolyvalencesData(polyvalences);
        } else if (fixedAbsenceWorkstations.length > 0) {
            polyvalencesData = getPolyvalencesData(fixedAbsenceWorkstations);
        }
        polyvalences = getAbsenceWorkstation(event, _currSection, false);

        return {
            eventsData: eventsData,
            otherEvents: otherEvents,
            diff: diff,
            newStart: newStart,
            newEnd: newEnd,
            start: start,
            end: end,
            minSeq: minSeq,
            maxSeq: maxSeq,
            polyvalencesData: polyvalencesData,
            polyvalences: polyvalences,
        };
    }

    function moveMainRangeMoveMode(event, currData, currSection) {
        var contData = getMoveContiguousData(event, currData, currSection);
        var duration = contData.duration,
            diff = contData.diff,
            eventsData = contData.eventsData,
            newStart = contData.newStart,
            newEnd = contData.newEnd,
            start = contData.start,
            end = contData.end,
            minSeq = contData.minSeq,
            maxSeq = contData.maxSeq,
            pData = contData.polyvalencesData,
            polyvalencesData = contData.polyvalences;

        var goToElse = false;
        if (+start <= +scheduler._min_date) {
            goToElse = true;
            if (event.seqNumber == minSeq) {
                goToElse = false;
            }
        }

        if (+end >= +scheduler._max_date) {
            goToElse = true;
            if (event.seqNumber == maxSeq) {
                goToElse = false;
            }
        }

        // if there is polyvalence data && 
        // if main range limits try to get outside polyvalences
        // i.e: all polyvalences must be contained inside main range
        if (pData && (+newEnd < +pData.maxPolyDate || +newStart > +pData.minPolyDate) && !goToElse) {
            scheduler.unmarkTimespan(_markedData[MARK_NAMES.POLYVALENCE])
            if (+newEnd < +pData.maxPolyDate) {
                keepInsideLimit(RIGHT, eventsData, pData.maxPolyDate);
            } else if (+newStart > +pData.minPolyDate) {
                keepInsideLimit(LEFT, eventsData, pData.minPolyDate);
            } else {
                console.debug('cant do this');
            }

            showInvalidHighlight(MARK_NAMES.POLYVALENCE, event.section_id, event.rangeBegin, event.rangeEnd);
        } else {
            if (eventsData.length == 0) return;
            if (+newStart < +scheduler._min_date || +newEnd > +scheduler._max_date) {
                keepEventsInsideRangeLimits(eventsData, newStart, newEnd, scheduler._min_date, scheduler._max_date);
            } else {
                $.each(contData.otherEvents, function (index, ev) {
                    ev.start_date = new Date(ev.start_date.getTime() + diff);
                    ev.end_date = new Date(ev.end_date.getTime() + diff);
                    scheduler.updateEvent(ev.id);
                });

                changeAbsenceWorkstation(eventsData[0].event, true);
            }
        }
        currData.currStartDateTime = event.start_date.getTime();
    }

    function moveMainRangeResizeMode(event, currData, currSection) {
        var eventsData = getEventsData(event, currSection),
            newStart = null,
            newEnd = null;

        var intervalEvent = null;
        var returnInterval = null;
        var absenceWorkstations = getAbsenceWorkstation(event, currSection, false);
        var fixedAbsenceWorkstations = getAbsenceWorkstation(event, currSection, true);
        var currStartDate = _currDraggedEvent.start_date; // save original start date. dhtmlx pushs dates
        var currEndDate = _currDraggedEvent.end_date;     // save original end date. dhtmlx pushs dates
        var direction = "";
        var duration = +event.start_date - +currStartDate;
        if (duration == 0) {
            duration = +event.end_date - +currEndDate;
        }

        if (duration < 0) {
            direction = "LEFT";
        } else if (duration > 0) {
            direction = "RIGHT";
        }

        var absenceWKLimits = null;
        if (fixedAbsenceWorkstations.length > 0) {
            absenceWKLimits = getPolyvalencesData(fixedAbsenceWorkstations);

            if (absenceWKLimits.minPolyDate < event.start_date) {
                event.start_date = absenceWKLimits.minPolyDate;
                scheduler.updateEvent(event.id);
                return;
            } else if (absenceWKLimits.maxPolyDate > event.end_date) {
                event.end_date = absenceWKLimits.maxPolyDate;
                scheduler.updateEvent(event.id);
                return;
            }
        }

        if (eventsData.length > 0) {
            newStart = eventsData[0].event.start_date;
            newEnd = eventsData[eventsData.length - 1].event.end_date;
        } else {
            console.debug('no events data');
        }

        var polyvalences = getPolyvalences(event, currSection, true);
        var pData = null;
        if (polyvalences.length > 0) {
            if (fixedAbsenceWorkstations.length > 0){
                for (var i = 0; i < fixedAbsenceWorkstations.length; i++) {
                    polyvalences.push(fixedAbsenceWorkstations[i]);
                }
            }
            pData = getPolyvalencesData(polyvalences);
        } else if (fixedAbsenceWorkstations.length > 0) {
            pData = getPolyvalencesData(fixedAbsenceWorkstations);
        }

        var limits = getLimits(event, currSection, pData),
            limitLeft = limits.limitLeft,
            limitRight = limits.limitRight;

        if (pData && (+newEnd < limitRight || +newStart > limitLeft)) {
            scheduler.unmarkTimespan(_markedData[MARK_NAMES.POLYVALENCE]);
            if (+newEnd < limitRight) {
                event.end_date = new Date(limitRight);
                scheduler.updateEvent(event.id);
            } else if (+newStart > limitLeft) {
                // TODO: verificar se tem evento adjacente 'anterior' ao minimo da poly;
                event.start_date = new Date(limitLeft);
                event.end_date = _currDraggedEvent.end_date;

                scheduler.updateEvent(event.id);
            }
            showInvalidHighlight(MARK_NAMES.POLYVALENCE, event.section_id, event.rangeBegin, event.rangeEnd);
        } else {
            for (var i = 0; i < _intervalsDefinitions.length; i++) {
                var intervalDef = _intervalsDefinitions[i];

                intervalEvent = getIntervalEvent(event, currSection, intervalDef.seqNumber);
                if (!intervalEvent) return;

                var currStartDate = _currDraggedEvent.start_date; // save original start date. dhtmlx pushs dates
                var currEndDate = _currDraggedEvent.end_date;     // save original end date. dhtmlx pushs dates
                if (event.seqNumber === intervalDef.bounderies.left) {
                    if (+event.end_date < +currStartDate + _marginDuration) {
                        event.end_date = new Date(+event.start_date + _marginDuration);
                        scheduler.updateEvent(event.id);
                        showInvalidHighlight(MARK_NAMES.OTHER_EVENTS, event.section_id, event.rangeBegin, event.rangeEnd);
                    } else if (+event.start_date > +currEndDate - _marginDuration) {
                        event.start_date = new Date(+currEndDate - _marginDuration);
                        event.end_date = currEndDate;
                        scheduler.updateEvent(event.id);
                    }
                    intervalEvent.start_date = event.end_date;
                } else if (event.seqNumber === intervalDef.bounderies.right) {
                    if (+event.start_date > +currEndDate - _marginDuration) {
                        event.end_date = currEndDate;
                        event.start_date = new Date(+event.end_date - _marginDuration);
                        scheduler.updateEvent(event.id);
                        showInvalidHighlight(MARK_NAMES.OTHER_EVENTS, event.section_id, event.rangeStart, event.rangeEnd);
                    } else if (+event.end_date < +currStartDate + _marginDuration) {
                        event.end_date = new Date(+event.start_date + _marginDuration);
                        scheduler.updateEvent(event.id);
                    }
                    intervalEvent.end_date = event.start_date;
                } else {
                    // nothing
                }

                if (+intervalEvent.end_date - +intervalEvent.start_date < _marginDuration) {
                    if (event.seqNumber === intervalDef.bounderies.left) {
                        event.end_date = intervalEvent.start_date = new Date(+intervalEvent.end_date - _marginDuration);
                    } else if (event.seqNumber === intervalDef.bounderies.right) {
                        event.start_date = intervalEvent.end_date = new Date(+intervalEvent.start_date + _marginDuration);
                    }
                    scheduler.updateEvent(event.id);
                }
                scheduler.updateEvent(intervalEvent.id);

                //Move absence workstation mobile when resize
                if (direction != "") {
                    if (absenceWorkstations.length > 0) {
                        for (var i = 0; i < absenceWorkstations.length; i++) {
                            absenceWorkstation = absenceWorkstations[i];
                            returnInterval = resizeAbsenceWorkstation(absenceWorkstation, direction, event, intervalEvent, null, null, duration, event.seqNumber, (i == 0) ? null : absenceWorkstations[i - 1], (i == absenceWorkstations.length) ? null : absenceWorkstations[i + 1]);
                        }
                    }
                }
            }
        }
    }

    function getLimits(event, currSection, pData) {

        var intervals = [];
        for (var i = 0; i < _intervalsDefinitions.length; i++) {
            var intervalRef = getIntervalEvent(event, currSection, _intervalsDefinitions[i].seqNumber);
            var interval = $.extend(true, {}, intervalRef);
            intervals.push(interval);
        }

        var minMaxIntervals = customControlsModule.getMinMaxDate(intervals, 'start_date', 'end_date'),
            minIntervalDate = minMaxIntervals.minDate,
            maxIntervalDate = minMaxIntervals.maxDate;

        var minInterval = +minIntervalDate - _marginDuration,
            maxInterval = +maxIntervalDate + _marginDuration;

        var limitLeft = pData && (+pData.minPolyDate < minInterval) ? +pData.minPolyDate : minInterval,
            limitRight = pData && (+pData.maxPolyDate > maxInterval) ? +pData.maxPolyDate : maxInterval;

        return {
            limitLeft: limitLeft,
            limitRight: limitRight,
        };
    }

    function getAbsenceWKLimits(absencesWorkstation) {
        var intervals = {
            start_date: null,
            end_date: null,
        };
        for (var i = 0; i < absencesWorkstation.length; i++) {
            if (i == 0) {
                intervals.start_date = absencesWorkstation[i].start_date;
                intervals.end_date = absencesWorkstation[i].end_date;
            } else {
                if (absencesWorkstation[i].start_date < intervals.start_date) {
                    intervals.start_date = absencesWorkstation[i].start_date;
                }
                if (absencesWorkstation[i].end_date > intervals.end_date) {
                    intervals.end_date = absencesWorkstation[i].end_date;
                }
            }
        }

        return {
            start_date: intervals.start_date,
            end_date: intervals.end_date,
        };
    }

    function getPolyvalencesData(polyvalences) {
        /// <summary>
        /// gets polyvalence data
        /// </summary>
        /// <param name="polyvalences"></param>
        /// <returns type=""></returns>
        var minMax = customControlsModule.getMinMaxDate(polyvalences, "start_date", "end_date");

        var minPolyDate = minMax.minDate,
            minPoly = minMax.minEvent,
            maxPolyDate = minMax.maxDate,
            maxPoly = minMax.maxEvent;

        return {
            minPolyDate: minPolyDate,
            maxPolyDate: maxPolyDate,
            minPoly: minPoly,
            maxPoly: maxPoly,
        };
    }

    function validateLeft(event, mode, leftLimitDate, duration, marginDuration, markName) {
        scheduler.unmarkTimespan(_markedData[markName]);
        duration = (mode === "resize") ? (+event.end_date - (+leftLimitDate + marginDuration)) : duration;
        event.start_date = new Date(+leftLimitDate + marginDuration);
        event.end_date = new Date(+event.start_date + duration);
        showInvalidHighlight(markName, event.section_id, event.rangeBegin, event.rangeEnd);
    }

    function validateRight(event, mode, rightLimitDate, duration, marginDuration, markName) {
        scheduler.unmarkTimespan(_markedData[markName]);
        duration = (mode === "resize") ? ((+rightLimitDate - marginDuration) - +event.start_date) : duration;
        event.end_date = new Date(+rightLimitDate - marginDuration);
        event.start_date = new Date(+event.end_date - duration);
        showInvalidHighlight(markName, event.section_id, event.rangeBegin, event.rangeEnd);
    }

    function validateInsideLimits(event, mode, leftLimitDate, rightLimitDate, duration, marginDuration, markName) {
        /// <summary>
        /// keeps single events inside limit
        /// </summary>
        /// <param name="event"></param>
        /// <param name="mode"></param>
        /// <param name="leftLimitDate"></param>
        /// <param name="rightLimitDate"></param>
        /// <param name="duration"></param>
        /// <param name="marginDuration"></param>
        /// <param name="markName"></param>
        /// <returns type=""></returns>

        if (+event.start_date < +leftLimitDate + marginDuration) {
            validateLeft(event, mode, leftLimitDate, duration, marginDuration, markName);
        } else if (+event.end_date > +rightLimitDate - marginDuration) {
            validateRight(event, mode, rightLimitDate, duration, marginDuration, markName);
        }
    }

    function moveInterval(event, mode, currSection) {
        var currStartDate = _currDraggedEvent.start_date; // save original start date. dhtmlx pushs dates
        var currEndDate = _currDraggedEvent.end_date;     // save original end date. dhtmlx pushs dates
        var direction = null;

        if (currStartDate > event.start_date) {
            direction = "LEFT";
        } else if (currStartDate < event.start_date) {
            direction = "RIGHT";
        }

        for (var i = 0; i < _intervalsDefinitions.length; i++) {

            var intervalDef = _intervalsDefinitions[i];

            if (event.seqNumber === intervalDef.seqNumber) {
                scheduler.unmarkTimespan(_markedData[MARK_NAMES.INTERVAL]);
                var duration = +event.end_date - +event.start_date;
                var leftAndRight = getLeftAndRight(intervalDef.bounderies, event, currSection, getOtherEvents)

                var left = leftAndRight.left;
                var right = leftAndRight.right;

                if (!left || !right) return;

                validateInsideLimits(event, mode, left.start_date, right.end_date, duration, _marginDuration, MARK_NAMES.INTERVAL);

                if (+event.end_date - +event.start_date < _marginDuration) {
                    if (+event.start_date === +currStartDate) {
                        event.end_date = new Date(+currStartDate + _marginDuration);
                    } else {
                        event.start_date = new Date(+currEndDate - _marginDuration);
                        event.end_date = new Date(+currEndDate);
                    }
                }
                //take the diff of move interval
                var leftDiff = +event.start_date - +left.end_date;
                var rightDiff = +event.end_date - +right.start_date;
                //take the absences workstations fixed and mobile
                var absenceWorkstations = getAbsenceWorkstation(left, currSection, false);
                var fixedAbsenceWorkstations = getAbsenceWorkstation(left, currSection, true);
                //attr start date and end date of interval
                var intervalStart_date = event.start_date;
                var intervalEnd_date = event.end_date;
                var absenceWorkstation = null;
                //Block move interval over absence workstation fixed
                if (fixedAbsenceWorkstations.length > 0) {
                    for (var i = 0; i < fixedAbsenceWorkstations.length; i++) {
                        absenceWorkstation = fixedAbsenceWorkstations[i];
                        var diffDates = 0;
                        if ((absenceWorkstation.end_date > intervalStart_date)
                            && (intervalStart_date > absenceWorkstation.start_date)
                            || (+absenceWorkstation.start_date == +intervalStart_date)) {

                            intervalStart_date = absenceWorkstation.end_date;
                            intervalEnd_date = new Date(+intervalStart_date + duration);

                            event.start_date = intervalStart_date;
                            event.end_date = intervalEnd_date;
                        }
                        if ((absenceWorkstation.end_date > intervalEnd_date)
                            && (intervalEnd_date > absenceWorkstation.start_date)
                            || (+absenceWorkstation.end_date == +intervalEnd_date)) {

                            intervalEnd_date = absenceWorkstation.start_date;
                            intervalStart_date = new Date(+intervalEnd_date - duration);

                            event.start_date = intervalStart_date;
                            event.end_date = intervalEnd_date;
                        }
                        if ((+absenceWorkstation.start_date == +intervalStart_date) || (+absenceWorkstation.end_date == +intervalEnd_date)) {
                            intervalEnd_date = absenceWorkstation.start_date;
                            intervalStart_date = new Date(+intervalEnd_date + duration);

                            event.start_date = intervalStart_date;
                            event.end_date = intervalEnd_date;
                        }
                    }
                }

                //Move absence workstation mobile with interval
                if (absenceWorkstations.length > 0) {
                    for (var i = 0; i < absenceWorkstations.length; i++) {
                        absenceWorkstation = absenceWorkstations[i];
                        if (mode === "move") {
                            var returnInterval = moveAbsenceWorkstation(absenceWorkstation, direction, event, left, right, duration, event.seqNumber, (i == 0) ? null : absenceWorkstations[i - 1], (i == absenceWorkstations.length) ? null : absenceWorkstations[i + 1]);
                        }
                        else if (mode === "resize") {
                            var returnInterval = resizeAbsenceWorkstation(absenceWorkstation, direction, null, event, left, right, duration, event.seqNumber, (i == 0) ? null : absenceWorkstations[i - 1], (i == absenceWorkstations.length) ? null : absenceWorkstations[i + 1]);
                        } else {
                            console.log("Unrecognized mode")
                        }
                    }
                } else {
                    left.end_date = intervalStart_date;
                    right.start_date = intervalEnd_date;

                    scheduler.updateEvent(event.id);
                    scheduler.updateEvent(left.id);
                    scheduler.updateEvent(right.id);
                }
            }
        }
    }

    function updateAbsenceEvent(ev, newStartDate, newEndDate) {
        ev.start_date = newStartDate;
        ev.end_date = newEndDate;

        scheduler.updateEvent(ev.id)
    }

    function moveAbsenceWorkstation(absenceWorkstation, direction, intervalEvent, left, right, duration, seqNumber, previousAbsWorkstation, rearAbsWorkstation) {
        var intervalSize = 0;
        var identationSize = 0;
        var absenceSize = 0;
        var eventSizeRight = 0;
        var eventSizeLeft = 0;

        var newStartDate = intervalEvent.start_date;
        var newEndDate = intervalEvent.end_date;

        absenceSize = +absenceWorkstation.end_date - +absenceWorkstation.start_date;
        if (direction == "LEFT") {
            if (seqNumber == 2 && (right != null && left != null)) {
                eventSizeRight = +right.end_date - +right.start_date;
                eventSizeLeft = +newStartDate - +left.start_date;
                intervalSize = +newEndDate - +newStartDate;

                if (absenceWorkstation.seqPeriod == "PE1") {
                    identationSize = +newStartDate - +absenceWorkstation.end_date;

                    if (absenceSize > eventSizeLeft) {
                        newEndDate = absenceWorkstation.end_date;
                        newStartDate = new Date(+newEndDate - absenceSize);

                        updateAbsenceEvent(absenceWorkstation, newStartDate, newEndDate);
                    } else {
                        newStartDate = new Date(+absenceWorkstation.start_date + identationSize);
                        newEndDate = new Date(+absenceWorkstation.end_date + identationSize);

                        updateAbsenceEvent(absenceWorkstation, newStartDate, newEndDate);
                    }

                    if (newEndDate != intervalEvent.end_date) {
                        intervalEvent.start_date = newEndDate;
                        if ((+intervalEvent.end_date - +intervalEvent.start_date) < intervalSize) {
                            intervalEvent.end_date = new Date(+intervalEvent.end_date + (intervalSize - (+intervalEvent.end_date - +intervalEvent.start_date)))
                        }
                    }

                } else if (absenceWorkstation.seqPeriod == "PB2") {
                    identationSize = +newEndDate - +absenceWorkstation.start_date;

                    if (absenceSize > eventSizeRight) {
                        newEndDate = absenceWorkstation.end_date;
                        newStartDate = new Date(+newEndDate - absenceSize);

                        updateAbsenceEvent(absenceWorkstation, newStartDate, newEndDate);
                    } else {
                        newStartDate = new Date(+absenceWorkstation.start_date + identationSize);
                        newEndDate = new Date(+absenceWorkstation.end_date + identationSize);

                        updateAbsenceEvent(absenceWorkstation, newStartDate, newEndDate);
                    }

                    if (newStartDate != intervalEvent.start_date) {
                        intervalEvent.end_date = newStartDate;
                    }
                }
                left.end_date = intervalEvent.start_date;
                right.start_date = intervalEvent.end_date;

                updateAbsenceEvent(intervalEvent, intervalEvent.start_date, intervalEvent.end_date);
                scheduler.updateEvent(left.id);
                scheduler.updateEvent(right.id);
            }
        } else {
            if (seqNumber == 2 && (right != null && left != null)) {
                eventSizeRight = +right.end_date - +right.start_date;
                eventSizeLeft = +newStartDate - +left.start_date;
                intervalSize = +newEndDate - +newStartDate;

                if (absenceWorkstation.seqPeriod == "PE1") {
                    identationSize = +newStartDate - +absenceWorkstation.end_date;

                    if (absenceSize > eventSizeLeft) {
                        newEndDate = absenceWorkstation.end_date;
                        newStartDate = new Date(+newEndDate - absenceSize);

                        updateAbsenceEvent(absenceWorkstation, newStartDate, newEndDate);
                    } else {
                        newStartDate = new Date(+absenceWorkstation.start_date + identationSize);
                        newEndDate = new Date(+absenceWorkstation.end_date + identationSize);

                        updateAbsenceEvent(absenceWorkstation, newStartDate, newEndDate);
                    }

                    if (newEndDate != intervalEvent.end_date) {
                        intervalEvent.start_date = newEndDate;
                        if ((+intervalEvent.end_date - +intervalEvent.start_date) < intervalSize) {
                            intervalEvent.end_date = new Date(+intervalEvent.end_date + (intervalSize - (+intervalEvent.end_date - +intervalEvent.start_date)))
                        }

                        var diffRear = eventSizeRight;
                        if (typeof rearAbsWorkstation != "undefined") {
                            diffRear = +rearAbsWorkstation.end_date - + rearAbsWorkstation.start_date;
                        }
                        if (diffRear > eventSizeRight) {
                            intervalEvent.end_date = rearAbsWorkstation.start_date;
                            if ((+intervalEvent.end_date - +intervalEvent.start_date) < intervalSize) {
                                intervalEvent.start_date = new Date(+intervalEvent.start_date + ((+intervalEvent.end_date - +intervalEvent.start_date) - intervalSize))
                            }

                            if (+absenceWorkstation.end_date > +intervalEvent.start_date) {
                                absenceWorkstation.end_date = intervalEvent.start_date;
                                absenceWorkstation.start_date = new Date(+absenceWorkstation.end_date - absenceSize);

                                scheduler.updateEvent(absenceWorkstation.id);
                            }
                        }
                    }
                } else if (absenceWorkstation.seqPeriod == "PB2") {
                    identationSize = +newEndDate - +absenceWorkstation.start_date;;

                    if (absenceSize > eventSizeRight) {
                        newEndDate = absenceWorkstation.end_date;
                        newStartDate = new Date(+newEndDate - absenceSize);

                        updateAbsenceEvent(absenceWorkstation, newStartDate, newEndDate);
                    } else {
                        newStartDate = new Date(+absenceWorkstation.start_date + identationSize);
                        newEndDate = new Date(+absenceWorkstation.end_date + identationSize)

                        updateAbsenceEvent(absenceWorkstation, newStartDate, newEndDate);
                    }

                    if (newStartDate != intervalEvent.start_date) {
                        intervalEvent.end_date = newStartDate;
                        intervalEvent.start_date = newEndDate;
                        if ((+intervalEvent.end_date - +intervalEvent.start_date) < intervalSize) {
                            intervalEvent.start_date = new Date(+intervalEvent.start_date + ((+intervalEvent.end_date - +intervalEvent.start_date) - intervalSize))
                        }
                        
                        var diffRear = eventSizeRight;
                        if (typeof rearAbsWorkstation != "undefined"){
                            diffRear = +rearAbsWorkstation.end_date - +rearAbsWorkstation.start_date;
                        } 

                        if (diffRear > eventSizeRight) {
                            intervalEvent.end_date = rearAbsWorkstation.start_date;
                            if ((+intervalEvent.end_date - +intervalEvent.start_date) < intervalSize) {
                                intervalEvent.start_date = new Date(+intervalEvent.start_date + (intervalSize - (+intervalEvent.end_date - +intervalEvent.start_date)))
                            }

                            if (+absenceWorkstation.start_date > +intervalEvent.end_date) {
                                absenceWorkstation.start_date = intervalEvent.end_date;
                                absenceWorkstation.end_date = new Date(+absenceWorkstation.start_date + absenceSize);

                                scheduler.updateEvent(absenceWorkstation.id);
                            }
                        }
                    }
                }
                left.end_date = intervalEvent.start_date;
                right.start_date = intervalEvent.end_date;

                updateAbsenceEvent(intervalEvent, intervalEvent.start_date, intervalEvent.end_date);
                scheduler.updateEvent(left.id);
                scheduler.updateEvent(right.id);
            }
        }
        return {
            newStartDate: newStartDate,
            newEndDate: newEndDate,
        }
    }

    function resizeAbsenceWorkstation(absenceWorkstation, direction, event, intervalEvent, left, right, duration, seqNumber, previousAbsWorkstation, rearAbsWorkstation) {
        var intervalSize = 0;
        var eventSize = 0;
        var identationSize = 0;
        var absenceSize = 0;
        var eventSizeLeft = 0;

        var newStartDate = (event != null) ? event.start_date : intervalEvent.start_date;
        var newEndDate = (event != null) ? event.end_date : intervalEvent.end_date;

        absenceSize = +absenceWorkstation.end_date - +absenceWorkstation.start_date;
        //When the interval exceeds the limit of absence - from right or left
        if (direction == "LEFT") {
            //Period workstation 1 and first interval
            if (seqNumber == 1 && (intervalEvent == null)) {
                eventSize = +event.end_date - +event.start_date;

                if (absenceWorkstation.seqPeriod == "PB1") {
                    newEndDate = new Date(+newStartDate + absenceSize);

                    if (absenceSize > eventSize) {
                        newStartDate = absenceWorkstation.start_date;
                        newEndDate = new Date(+newStartDate + absenceSize);

                        updateAbsenceEvent(event, newStartDate, newEndDate);
                        updateAbsenceEvent(absenceWorkstation, newStartDate, newEndDate);
                    } else {
                        updateAbsenceEvent(absenceWorkstation, newStartDate, newEndDate);
                    }
                } else if (absenceWorkstation.seqPeriod == "PE1") {
                    newStartDate = new Date(+newEndDate - absenceSize);

                    if (absenceSize > eventSize) {
                        newEndDate = absenceWorkstation.end_date;
                        newStartDate = new Date(+newEndDate - absenceSize);

                        updateAbsenceEvent(event, newStartDate, newEndDate);
                        updateAbsenceEvent(absenceWorkstation, newStartDate, newEndDate);
                    } else {
                        updateAbsenceEvent(absenceWorkstation, newStartDate, newEndDate);
                    }
                }
            } else if (seqNumber == 1 && (intervalEvent != null)) {
                eventSize = +event.end_date - +event.start_date;
                intervalSize = +intervalEvent.end_date - +intervalEvent.start_date;

                if (absenceWorkstation.seqPeriod == "PB1") {
                    newEndDate = new Date(+newStartDate + absenceSize);

                    if (absenceSize > eventSize) {
                        newStartDate = absenceWorkstation.start_date;
                        newEndDate = new Date(+newStartDate + absenceSize);

                        updateAbsenceEvent(event, newStartDate, newEndDate);
                        updateAbsenceEvent(absenceWorkstation, newStartDate, newEndDate);
                    } else {
                        updateAbsenceEvent(absenceWorkstation, newStartDate, newEndDate);
                    }
                } else if (absenceWorkstation.seqPeriod == "PE1") {
                    newStartDate = new Date(+newEndDate - absenceSize);

                    if (absenceSize > eventSize) {
                        newEndDate = absenceWorkstation.end_date;
                        newStartDate = new Date(+newEndDate - absenceSize);

                        updateAbsenceEvent(event, newStartDate, newEndDate);
                        updateAbsenceEvent(absenceWorkstation, newStartDate, newEndDate);
                    } else {
                        updateAbsenceEvent(absenceWorkstation, newStartDate, newEndDate);
                    }
                    intervalEvent.start_date = newEndDate;
                    scheduler.updateEvent(intervalEvent.id);
                }
                //Inteval workstation 1
            } else if (seqNumber == 2 && (right != null && left != null)) {
                eventSize = +right.end_date - +right.start_date;
                eventSizeLeft = +newStartDate - +left.start_date;
                intervalSize = +newEndDate - +newStartDate;

                if (absenceWorkstation.seqPeriod == "PE1") {
                    identationSize = +newStartDate - +absenceWorkstation.end_date;

                    if (absenceSize > eventSizeLeft) {
                        newEndDate = absenceWorkstation.end_date;
                        newStartDate = new Date(+newEndDate - absenceSize);

                        updateAbsenceEvent(absenceWorkstation, newStartDate, newEndDate);
                    } else {
                        newStartDate = new Date(+absenceWorkstation.start_date + identationSize);
                        newEndDate = new Date(+absenceWorkstation.end_date + identationSize);

                        updateAbsenceEvent(absenceWorkstation, newStartDate, newEndDate);
                    }

                    if (newEndDate != intervalEvent.end_date) {
                        intervalEvent.start_date = newEndDate;
                    }
                } else if (absenceWorkstation.seqPeriod == "PB2") {
                    identationSize = +newEndDate - +absenceWorkstation.start_date;

                    if (absenceSize > eventSize) {
                        newEndDate = absenceWorkstation.end_date;
                        newStartDate = new Date(+newEndDate - absenceSize);

                        updateAbsenceEvent(absenceWorkstation, newStartDate, newEndDate);
                    } else {
                        newStartDate = new Date(+absenceWorkstation.start_date + identationSize);
                        newEndDate = new Date(+absenceWorkstation.end_date + identationSize);

                        updateAbsenceEvent(absenceWorkstation, newStartDate, newEndDate);
                    }

                    if (newStartDate != intervalEvent.start_date) {
                        intervalEvent.end_date = newStartDate;
                    }
                }
                left.end_date = intervalEvent.start_date;
                right.start_date = intervalEvent.end_date;

                updateAbsenceEvent(intervalEvent, intervalEvent.start_date, intervalEvent.end_date);
                scheduler.updateEvent(left.id);
                scheduler.updateEvent(right.id);
                //Period workstation 2 and right is the first inteval
            } else if (seqNumber == 3 && (intervalEvent != null)) {
                if (absenceWorkstation.seqPeriod == "PB2") {
                    eventSize = +event.end_date - +event.start_date;
                    intervalSize = +intervalEvent.end_date - +intervalEvent.start_date;

                    newEndDate = new Date(+newStartDate + absenceSize);

                    if (absenceSize > eventSize) {
                        newEndDate = absenceWorkstation.end_date;
                        newStartDate = new Date(+newEndDate - absenceSize);

                        updateAbsenceEvent(event, newStartDate, newEndDate);
                        updateAbsenceEvent(absenceWorkstation, newStartDate, newEndDate);
                    } else {
                        updateAbsenceEvent(absenceWorkstation, newStartDate, newEndDate);
                    }
                } else if (absenceWorkstation.seqPeriod == "PE2") {
                    eventSize = +event.end_date - +event.start_date;
                    intervalSize = +intervalEvent.end_date - +intervalEvent.start_date;

                    newStartDate = new Date(+newEndDate - absenceSize);

                    if (absenceSize > eventSize) {
                        newStartDate = absenceWorkstation.start_date;
                        newEndDate = new Date(+newStartDate - absenceSize);

                        updateAbsenceEvent(event, newStartDate, newEndDate);
                        updateAbsenceEvent(absenceWorkstation, newStartDate, newEndDate);
                    } else {
                        updateAbsenceEvent(absenceWorkstation, newStartDate, newEndDate);
                    }
                }
            }
        } else {
            //Period workstation 1
            if (seqNumber == 1 && (intervalEvent == null)) {
                eventSize = +event.end_date - +event.start_date;
                
                if (absenceWorkstation.seqPeriod == "PB1") {
                    newEndDate = new Date(+newStartDate + absenceSize);

                    if (absenceSize > eventSize) {
                        newEndDate = absenceWorkstation.end_date;
                        newStartDate = new Date(+newEndDate - absenceSize);

                        updateAbsenceEvent(event, newStartDate, newEndDate);
                        updateAbsenceEvent(absenceWorkstation, newStartDate, newEndDate);
                    } else {
                        updateAbsenceEvent(absenceWorkstation, newStartDate, newEndDate);
                    }
                } else if (absenceWorkstation.seqPeriod == "PE1") {
                    newStartDate = new Date(+newEndDate - absenceSize);

                    if (absenceSize > eventSize) {
                        newEndDate = absenceWorkstation.end_date;
                        newStartDate = new Date(+newEndDate - absenceSize);

                        updateAbsenceEvent(event, newStartDate, newEndDate);
                        updateAbsenceEvent(absenceWorkstation, newStartDate, newEndDate);
                    } else {
                        updateAbsenceEvent(absenceWorkstation, newStartDate, newEndDate);
                    }
                }
            } else if (seqNumber == 1 && (intervalEvent != null)) {
                eventSize = +event.end_date - +event.start_date;
                intervalSize = +intervalEvent.end_date - +intervalEvent.start_date;
                if (absenceWorkstation.seqPeriod == "PB1") {
                    newEndDate = new Date(+newStartDate + absenceSize);

                    if (absenceSize > eventSize) {
                        newEndDate = absenceWorkstation.end_date;
                        newStartDate = new Date(+newEndDate - absenceSize);

                        updateAbsenceEvent(event, newStartDate, newEndDate);
                        updateAbsenceEvent(absenceWorkstation, newStartDate, newEndDate);

                        intervalEvent.start_date = newEndDate;
                        scheduler.updateEvent(intervalEvent.id);
                    } else {
                        updateAbsenceEvent(absenceWorkstation, newStartDate, newEndDate);
                    }
                } else if (absenceWorkstation.seqPeriod == "PE1") {
                    newStartDate = new Date(+newEndDate - absenceSize);

                    if (absenceSize > eventSize) {
                        newEndDate = absenceWorkstation.end_date;
                        newStartDate = new Date(+newEndDate - absenceSize);

                        updateAbsenceEvent(event, newStartDate, newEndDate);
                        updateAbsenceEvent(absenceWorkstation, newStartDate, newEndDate);

                        intervalEvent.start_date = newEndDate;
                        scheduler.updateEvent(intervalEvent.id);
                    } else {
                        updateAbsenceEvent(absenceWorkstation, newStartDate, newEndDate);
                    }
                }
                //interval workstation 1
            } else if (seqNumber == 2 && (right != null && left != null)) {
                eventSize = +right.end_date - +right.start_date;
                eventSizeLeft = +newStartDate - +left.start_date;
                intervalSize = +newEndDate - +newStartDate;

                if (absenceWorkstation.seqPeriod == "PE1") {
                    identationSize = +newStartDate - +absenceWorkstation.end_date;

                    if (absenceSize > eventSizeLeft) {
                        newEndDate = absenceWorkstation.end_date;
                        newStartDate = new Date(+newEndDate - absenceSize);

                        updateAbsenceEvent(absenceWorkstation, newStartDate, newEndDate);
                    } else {
                        newStartDate = new Date(+absenceWorkstation.start_date + identationSize);
                        newEndDate = new Date(+absenceWorkstation.end_date + identationSize);
                        
                        if ((+right.start_date - +left.end_date) == intervalSize) {
                            newEndDate = left.end_date;
                            newStartDate = right.start_date;
                            updateAbsenceEvent(intervalEvent, newEndDate, newStartDate);
                        } else {
                            updateAbsenceEvent(absenceWorkstation, newStartDate, newEndDate);
                        }
                    }

                    if (newEndDate != intervalEvent.end_date) {
                        intervalEvent.start_date = newEndDate;
                    }
                } else if (absenceWorkstation.seqPeriod == "PB2") {
                    identationSize = +newEndDate - +absenceWorkstation.start_date;;

                    if (absenceSize > eventSize) {
                        newEndDate = absenceWorkstation.end_date;
                        newStartDate = new Date(+newEndDate - absenceSize);

                        updateAbsenceEvent(absenceWorkstation, newStartDate, newEndDate);
                    } else {
                        newStartDate = new Date(+absenceWorkstation.start_date + identationSize);
                        newEndDate = new Date(+absenceWorkstation.end_date + identationSize)

                        updateAbsenceEvent(absenceWorkstation, newStartDate, newEndDate);
                    }

                    if (newStartDate != intervalEvent.start_date) {
                        intervalEvent.end_date = newStartDate;
                    }
                }
                if (!((+right.start_date - +left.end_date) == intervalSize)) {
                    left.end_date = intervalEvent.start_date;
                    right.start_date = intervalEvent.end_date;

                    updateAbsenceEvent(intervalEvent, intervalEvent.start_date, intervalEvent.end_date);
                    scheduler.updateEvent(left.id);
                    scheduler.updateEvent(right.id);
                }
                //Period workstation 2 and left is the first inteval
            } else if (seqNumber == 3 && (intervalEvent != null)) {
                if (absenceWorkstation.seqPeriod == "PB2") {
                    eventSize = +event.end_date - +event.start_date;
                    diffIntervalDates = +intervalEvent.end_date - +intervalEvent.start_date;

                    if (absenceSize > eventSize) {
                        newStartDate = absenceWorkstation.start_date;
                        newEndDate = new Date(+newStartDate + absenceSize);

                        updateAbsenceEvent(event, newStartDate, newEndDate);
                        updateAbsenceEvent(absenceWorkstation, newStartDate, newEndDate);

                        intervalEvent.end_date = newStartDate;
                        scheduler.updateEvent(intervalEvent.id);
                    } else {
                        newEndDate = new Date(+newStartDate + absenceSize);

                        updateAbsenceEvent(absenceWorkstation, newStartDate, newEndDate);
                    }
                } else if (absenceWorkstation.seqPeriod == "PE2") {
                    eventSize = +event.end_date - +event.start_date;

                    if (absenceSize > eventSize) {
                        newEndDate = absenceWorkstation.end_date;
                        newStartDate = new Date(+newEndDate - absenceSize);

                        updateAbsenceEvent(absenceWorkstation, newStartDate, newEndDate);
                        updateAbsenceEvent(event, newStartDate, newEndDate);
                    } else {
                        newStartDate = new Date(+newEndDate - absenceSize);

                        updateAbsenceEvent(absenceWorkstation, newStartDate, newEndDate);
                    }
                }
            }
        }
        return {
            newStartDate: newStartDate,
            newEndDate: newEndDate,
        }
    }

    function getProperties() {
        return {
            _lightboxEvReturn: _lightboxEvReturn,
            _lightboxPeriodReturn: _lightboxPeriodReturn,
        }
    }

    function changeAbsenceWorkstation(ev, isMoveWorkstation) {
        var event = null;
        var periods = null;

        if (isMoveWorkstation) {
            event = ev;
        } else {
            var propert = getProperties();
            periods = propert._lightboxPeriodReturn;
            event = propert._lightboxEvReturn;
        }

        var eventsData = getEventsData(event, event.section_id);
        var eventData = null;
        var absenceWorkstations = getAbsenceWorkstation(event, event.section_id, false);
        var absenceWorkstation = null;
        var direction = "";
        var duration = 0;
        var endDT, startDT;

        if ((eventsData.length > 0) && (absenceWorkstations.length > 0)) {
            for (var i = 0; i < eventsData.length; i++) {
                eventData = eventsData[i];
                for (var y = 0; y < absenceWorkstations.length; y++) {
                    absenceWorkstation = absenceWorkstations[y];
                    if (periods) {
                        startDT = new Date(periods[eventData.seqNumber].minutesStart);
                        endDT = new Date(periods[eventData.seqNumber].minutesEnd);
                    } else {
                        startDT = eventData.event.start_date;
                        endDT = eventData.event.end_date;
                    }

                    if (eventData.seqNumber == 1) {
                        if (absenceWorkstation.seqPeriod == "PB1") {
                            duration = +startDT - +absenceWorkstation.start_date;
                            if (duration < 0) {
                                direction = "LEFT";
                                eventData.event.start_date = startDT;
                                returnInterval = resizeAbsenceWorkstation(absenceWorkstation, direction, eventData.event, (eventsData.length > 1) ? eventsData[i + 1].event : null, null, null, duration, eventData.seqNumber, (y == 0) ? null : absenceWorkstations[y - 1], ((y == (absenceWorkstations.length - 1)) ? null : absenceWorkstations[y + 1]));
                            } else if (duration > 0) {
                                direction = "RIGHT";
                                eventData.event.start_date = startDT;
                                returnInterval = resizeAbsenceWorkstation(absenceWorkstation, direction, eventData.event, (eventsData.length > 1) ? eventsData[i + 1].event : null, null, null, duration, eventData.seqNumber, (y == 0) ? null : absenceWorkstations[y - 1], ((y == (absenceWorkstations.length - 1)) ? null : absenceWorkstations[y + 1]));
                            }
                        } else if (absenceWorkstation.seqPeriod == "PE1") {
                            duration = +endDT - +absenceWorkstation.end_date;
                            if (duration < 0) {
                                direction = "LEFT";
                                eventData.event.end_date = endDT;
                                returnInterval = resizeAbsenceWorkstation(absenceWorkstation, direction, eventData.event, (eventsData.length > 1) ? eventsData[i + 1].event : null, null, null, duration, eventData.seqNumber, (y == 0) ? null : absenceWorkstations[y - 1], ((y == (absenceWorkstations.length - 1)) ? null : absenceWorkstations[y + 1]));
                            } else if (duration > 0) {
                                direction = "RIGHT";
                                eventData.event.end_date = endDT;
                                returnInterval = resizeAbsenceWorkstation(absenceWorkstation, direction, eventData.event, (eventsData.length > 1) ? eventsData[i + 1].event : null, null, null, duration, eventData.seqNumber, (y == 0) ? null : absenceWorkstations[y - 1], ((y == (absenceWorkstations.length - 1)) ? null : absenceWorkstations[y + 1]));
                            }
                        }
                    } else if (eventData.seqNumber == 2) {
                        if (absenceWorkstation.seqPeriod == "PE1") {
                            //startDT = new Date(periods[eventData.seqNumber].minutesStart);
                            duration = +eventData.event.start_date - +absenceWorkstation.end_date;
                            if (duration < 0) {
                                direction = "LEFT";
                                returnInterval = resizeAbsenceWorkstation(absenceWorkstation, direction, null, eventData.event, (eventsData.length > 1) ? eventsData[i - 1].event : null, (eventsData.length > 1) ? eventsData[i + 1].event : null, duration, eventData.seqNumber, (y == 0) ? null : absenceWorkstations[y - 1], ((y == (absenceWorkstations.length - 1)) ? null : absenceWorkstations[y + 1]));
                            } else if (duration > 0) {
                                direction = "RIGHT";
                                returnInterval = resizeAbsenceWorkstation(absenceWorkstation, direction, null, eventData.event, (eventsData.length > 1) ? eventsData[i - 1].event : null, (eventsData.length > 1) ? eventsData[i + 1].event : null, duration, eventData.seqNumber, (y == 0) ? null : absenceWorkstations[y - 1], ((y == (absenceWorkstations.length - 1)) ? null : absenceWorkstations[y + 1]));
                            }
                        } else if (absenceWorkstation.seqPeriod == "PB2") {
                            //endDT = new Date(periods[eventData.seqNumber].minutesEnd);
                            duration = +eventData.event.end_date - +absenceWorkstation.start_date;
                            if (duration < 0) {
                                direction = "LEFT";
                                returnInterval = resizeAbsenceWorkstation(absenceWorkstation, direction, null, eventData.event, (eventsData.length > 1) ? eventsData[i - 1].event : null, (eventsData.length > 1) ? eventsData[i + 1].event : null, duration, eventData.seqNumber, (y == 0) ? null : absenceWorkstations[y - 1], ((y == (absenceWorkstations.length - 1)) ? null : absenceWorkstations[y + 1]));
                            } else if (duration > 0) {
                                direction = "RIGHT";
                                returnInterval = resizeAbsenceWorkstation(absenceWorkstation, direction, null, eventData.event, (eventsData.length > 1) ? eventsData[i - 1].event : null, (eventsData.length > 1) ? eventsData[i + 1].event : null, duration, eventData.seqNumber, (y == 0) ? null : absenceWorkstations[y - 1], ((y == (absenceWorkstations.length - 1)) ? null : absenceWorkstations[y + 1]));
                            }
                        }
                    } else if (eventData.seqNumber == 3) {
                        if (absenceWorkstation.seqPeriod == "PB2") {
                            duration = +startDT - +absenceWorkstation.start_date;
                            if (duration < 0) {
                                direction = "LEFT";
                                eventData.event.start_date = startDT;
                                returnInterval = resizeAbsenceWorkstation(absenceWorkstation, direction, eventData.event, (eventsData.length > 1) ? eventsData[i - 1].event : null, null, null, duration, eventData.seqNumber, (y == 0) ? null : absenceWorkstations[y - 1], ((y == (absenceWorkstations.length - 1)) ? null : absenceWorkstations[y + 1]));
                            } else if (duration > 0) {
                                direction = "RIGHT";
                                eventData.event.start_date = startDT;
                                returnInterval = resizeAbsenceWorkstation(absenceWorkstation, direction, eventData.event, (eventsData.length > 1) ? eventsData[i - 1].event : null, null, null, duration, eventData.seqNumber, (y == 0) ? null : absenceWorkstations[y - 1], ((y == (absenceWorkstations.length - 1)) ? null : absenceWorkstations[y + 1]));
                            }
                        } else if (absenceWorkstation.seqPeriod == "PE2") {
                            duration = +endDT - +absenceWorkstation.end_date;
                            if (duration < 0) {
                                eventData.event.end_date = endDT;
                                direction = "LEFT";
                                returnInterval = resizeAbsenceWorkstation(absenceWorkstation, direction, eventData.event, (eventsData.length > 1) ? eventsData[i - 1].event : null, null, null, duration, eventData.event.seqNumber, (y == 0) ? null : absenceWorkstations[y - 1], ((y == (absenceWorkstations.length - 1)) ? null : absenceWorkstations[y + 1]));
                            } else if (duration > 0) {
                                eventData.event.end_date = endDT;
                                direction = "RIGHT";
                                returnInterval = resizeAbsenceWorkstation(absenceWorkstation, direction, eventData.event, (eventsData.length > 1) ? eventsData[i - 1].event : null, null, null, duration, eventData.event.seqNumber, (y == 0) ? null : absenceWorkstations[y - 1], ((y == (absenceWorkstations.length - 1)) ? null : absenceWorkstations[y + 1]));
                            }
                        }
                    }
                }
            }
        }
    }

    function movePolyvalence(event, mode, currSection) {
        /// <summary>
        /// validates polyvalences moves
        /// </summary>
        /// <param name="event"></param>
        /// <param name="mode"></param>
        /// <param name="currSection"></param>
        /// <returns type=""></returns>
        if (event.isPolyvalent || event.isSectionPolyvalent) {
            scheduler.unmarkTimespan(_markedData[MARK_NAMES.POLYVALENCE]);
            scheduler.unmarkTimespan(_markedData[MARK_NAMES.POLYVALENCE]);

            var mainRangeEvents = getMainOtherPolyvalentEvents(event, currSection);

            var minMaxData = customControlsModule.getMinMaxDate(mainRangeEvents, 'start_date', 'end_date'),
                minDate = minMaxData.minDate,
                maxDate = minMaxData.maxDate;

            var duration = +event.end_date - +event.start_date;

            validateInsideLimits(event, mode, minDate, maxDate, duration, 0, MARK_NAMES.POLYVALENCE);
            validatePolyvalenceCollisions(event, mode, duration, currSection, MARK_NAMES.POLYVALENCE);
            scheduler.updateEvent(event.id);
        }
    }

    function validatePolyvalenceCollisions(event, mode, duration, currSection, markName) {
        /// <summary>
        /// validates polyvalences collisions amongst each other
        /// </summary>
        /// <param name="event"></param>
        /// <param name="mode"></param>
        /// <param name="duration"></param>
        /// <param name="currSection"></param>
        /// <param name="markName"></param>
        /// <returns type=""></returns>
        var currStartDate = _currDraggedEvent.start_date; // save original start date. dhtmlx pushs dates
        var currEndDate = _currDraggedEvent.end_date;     // save original end date. dhtmlx pushs dates

        var otherPolyvalences = getOtherPolyvalences(event, currSection);
        if (otherPolyvalences.length === 0) return;

        $.each(otherPolyvalences, function (index, elem) {
            if (+elem.end_date <= +currStartDate) {
                if (+event.start_date <= +elem.end_date) {
                    validateLeft(event, mode, elem.end_date, duration, 0, markName)
                }
            } else if (+elem.start_date >= +currEndDate) {
                if (+event.end_date >= +elem.start_date) {
                    validateRight(event, mode, elem.start_date, duration, 0, markName)
                }
            }
            scheduler.updateEvent(event.id);
        });
    }
    // #endregion Scheduler moves

    function redrawChart(id, currData, isForced) {
        /// <summary>
        /// updates allocated collabs structure and redraws the chart based on that data
        /// </summary>
        /// <param name="id"></param>
        /// <param name="currData"></param>
        /// <param name="isForced">forces to redraw chart. ignores 'executing' check. by default true</param>
        /// <returns type=""></returns>
        isForced = typeof isForced !== "undefined" ? isForced : true;

        var event = scheduler.getEvent(id);
        if (!event) return;
        var startDate = event.start_date;
        var endDate = event.end_date;

        currData.currStartDate = currData.currStartDate || startDate;
        currData.currEndDate = currData.currEndDate || endDate;

        if (currData.currStartDate.getTime() !== startDate.getTime()
            || currData.currEndDate.getTime() !== endDate.getTime()) {

            //updateAllocatedQuantity(currData.currStartDate, currData.currEndDate, false); // removes
            //updateAllocatedQuantity(startDate, endDate, true);                            // adds
            currData.currStartDate = startDate;
            currData.currEndDate = endDate;
        }

        if (isForced) {
            $(_containerDiv).trigger('schedule.day.updateChartAllocated', { date: startDate });

        } else {
            // only executes if there isn't another update occurring
            if (!_executing) {
                _executing = true;
                $(_containerDiv).trigger('schedule.day.updateChartAllocated', { date: startDate });

                setTimeout(function () {
                    _executing = false;
                }, 300);
            }
        }
    }

    function showInvalidHighlight(markedKey, section, startDate, endDate) {
        /// <summary>
        /// highlights invalid event moves.
        /// an entire line is highlighted.
        /// </summary>
        /// <param name="markedKey"></param>
        /// <param name="section"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns type=""></returns>
        _markedData[markedKey] = scheduler.markTimespan({
            start_date: startDate,
            end_date: endDate,
            css: "red_highlight",
            sections: {
                timeline: [section]
            }
        });
    }

    function formatOnlyTime(dateTime) {
        var formatField = scheduleModule.getSectionParent().find('#hdnMomentFormatTime'),
            newDate = dateTime.toDefaultMomentDate().format(formatField.val());

        return newDate;
    }

    function updateAllocatedQuantity(start, end, isAdd, quantity, granularity) {
        /// <summary>
        /// updates the number of allocated collaborators in a certain period
        /// a structure containing all the divisions (by granularity) 
        /// of the section/workstationtype time is updated
        /// </summary>
        /// <param name="start">begin of </param>
        /// <param name="end">end of the time range</param>
        /// <param name="isAdd">if it's add or remove operation. by default is true (adds)</param>
        /// <param name="quantity">the increment value. by default increments 1 collaborator</param>
        /// <returns type=""></returns>
        isAdd = (typeof isAdd !== "undefined") ? isAdd : true;
        quantity = (typeof quantity !== "undefined") ? quantity : 1;

        var addFn = function (curr, quantity) {
            return curr + quantity || quantity;
        }

        var subtractFn = function (curr, quantity) {
            var res = curr - quantity;
            return (res < 0) ? 0 : res;
        }

        var updateFn = isAdd ? addFn : subtractFn;
        granularity = granularity || _collaboratorsStats.granularity;

        var diff = granularity * _durations.minute;
        for (var curr = start; curr.getTime() < end.getTime() ; curr = new Date(curr.getTime() + diff)) {
            _collaboratorsStats.allocated[curr] = updateFn(_collaboratorsStats.allocated[curr], quantity);
        }
        return _collaboratorsStats;
    }

    function getChartData(start, end, extraChartData, granularity) {
        /// <summary>
        /// gets chart ready data (arrays) i.e: gets the date in the format the chart needs to use it
        /// on its normal use only "hours" and "allocated" info are retrieved
        /// note: ONLY takes info from the allocated structure (collaboratorStats) and maps it to chart consuption data
        /// </summary>
        /// <param name="start"></param>
        /// <param name="end"></param>
        /// <param name="extraChartData">extra data (ideal, calculated, performed) that will be 
        /// simply added (no changes) to the returning object
        /// </param>
        /// <returns type=""></returns>
        if (!start || !end) {
            console.debug('no start or end: ', start, end);
            return;
        }

        var extraChartData = extraChartData ? extraChartData : {};
        var ideal = extraChartData.ideal ? extraChartData.ideal : []
        var calculated = extraChartData.calculated ? extraChartData.calculated : []
        var performed = extraChartData.performed ? extraChartData.performed : []

        var ret = {
            hours: [],
            allocated: [],
            ideal: ideal,
            calculated: calculated,
            performed: performed,
        };
        granularity = granularity || _collaboratorsStats.granularity;

        var diff = granularity * _durations.minute;
        var i = 0;
        for (curr = start; curr.getTime() <= end.getTime() ; curr = new Date(curr.getTime() + diff)) {
            ret.hours[i] = dateModule.formatDate(curr);
            ret.allocated[i] = _collaboratorsStats.allocated[curr] || 0;
            i++;
        }
        return ret;
    }

    function getCollaboratorsChartData(events, extraChartData, granularity) {
        /// <summary>
        /// gets dhtmlx events and updates the allocated collaborators (_collaboratorsStats) structure.
        /// finally, maps the data to be used by the chart
        /// note: despite 'getChartData' function, this function actually resets 
        /// the central sctructure data based on the dhx scheduler events
        /// </summary>
        /// <param name="events"></param>
        /// <param name="extraChartData"></param>
        /// <returns type=""></returns>
        _collaboratorsStats.allocated = {};
        $.map(events, function (ev) {
            if (ev.countAsAllocated && ev.isDayTimelineEvent) {
                // if is marked as allocated and if is an expanded (split event). non split events (original) must not count
                updateAllocatedQuantity(ev.start_date, ev.end_date, true, 1, granularity) // increments collab quantity
            }
        });
        if (!_collaboratorsStats.start || !_collaboratorsStats.end) {
            console.log('no collab stats starrt or no collab stats end');
            return;
        }

        return getChartData(_collaboratorsStats.start, _collaboratorsStats.end, extraChartData, granularity);
    }

    function updateMenuCounters(dayTypeCounters) {
        var inputs = $('#optMenuDayViewContainer .form-cont .input-cont-filter');
        for (var i = 0; i < inputs.length; i++) {
            var divCont = inputs[i];
            var inputVal = $(divCont).find('input').val();
            var labelCounter = $(divCont).find('label .counter');
            labelCounter.text(dayTypeCounters[inputVal]);
        }
    }

    function getFilterSortMenuHTML() {
        var res = _globalResources.getResource().schedule.dayView.optMenu;
        return '' +
            '<div id="optMenuDayViewContainer" class="optMenuDayViewContainer">' +
                '<div id="optMenuDayView" class="optMenuDayView" style="display: none;">' +
                    '<div id="filter-form" class="form-cont">' +
                        '<span>' + res.Filter + ': </span>' +
                        '<div class="input-cont input-cont-filter"><input id="optFilterDayViewWork" type="checkbox" value="W" checked><label for="optFilterDayViewWork"><span class="name">' + res.WorkingDays + '</span> (<span class="counter"></span>)</label></div>' +
                        '<div class="input-cont input-cont-filter"><input id="optFilterDayViewMandRest" type="checkbox" value="MR"><label for="optFilterDayViewMandRest"><span class="name">' + res.MandRests + '</span> (<span class="counter"></span>)</label></div>' +
                        '<div class="input-cont input-cont-filter"><input id="optFilterDayViewCompRest" type="checkbox" value="CR"><label for="optFilterDayViewCompRest"><span class="name">' + res.CompRests + '</span> (<span class="counter"></span>)</label></div>' +
                        '<div class="input-cont input-cont-filter"><input id="optFilterDayViewAbsence" type="checkbox" value="A"><label for="optFilterDayViewAbsence"><span class="name">' + res.Absences + '</span> (<span class="counter"></span>)</label></div>' +
                        '<div class="input-cont input-cont-filter"><input id="optFilterDayViewNonWorking" type="checkbox" value="N"><label for="optFilterDayViewNonWorking"><span class="name">' + res.NonWorking + '</span> (<span class="counter"></span>)</label></div>' +
                        '<div class="input-cont input-cont-filter"><input id="optFilterDayViewHoliday" type="checkbox" value="H"><label for="optFilterDayViewHoliday"><span class="name">' + res.Holidays + '</span> (<span class="counter"></span>)</label></div>' +
                    '</div>' +
                    '<div id="sort-form" class="form-cont">' +
                        '<span>' + res.Sort + ': </span>' +
                        '<div class="input-cont input-cont-sort"><input id="optSortDayViewHour" type="radio" name="sort" value="hour"><label for="optSortDayViewHour">' + res.Schedule + '</label></div>' +
                        '<div class="input-cont input-cont-sort"><input id="optSortDayViewName" type="radio" name="sort" value="name" checked><label for="optSortDayViewName">' + res.Name + '</label></div>' +
                        '<div class="input-cont input-cont-sort"><input id="optSortDayViewMecNr" type="radio" name="sort" value="mecnr"><label for="optSortDayViewMecNr">' + res.MecNr + '</label></div>' +
                    '</div>' +
                '</div>' +
            '</div>';
    }

    function attachOptionsMenu() {
        $('#day_layout_container #optMenuDayViewContainer').remove();
        $('#day_layout_container').prepend(getFilterSortMenuHTML());
    }

    function setTimelineConfigs(configs) {
        /// <summary>
        /// sets timeline view configurations
        /// </summary>
        /// <param name="configs"></param>
        /// <returns type=""></returns>
        var diff = (+configs.rangeEnd - +configs.rangeBegin) / 60000;
        //If given no value or an invalid one, then gets the platform granularity value
        var granularity = configs.granularity <= 0 ? _collaboratorsStats.granularity : configs.granularity;
        var size = diff / granularity;
        var length = 1440 / granularity; // (24*60) / granularity;
        var rangeBegin = ((configs.rangeBegin.getHours() * 60) + configs.rangeBegin.getMinutes()) / granularity;

        _timelineConfigs.name = configs.viewName;
        // _timelineConfigs.y_unit = configs.collaborators
        _yUnitsOriginal = configs.collaborators;
        _timelineConfigs.x_step = granularity;
        _timelineConfigs.x_size = size;
        _timelineConfigs.x_length = length;
        _timelineConfigs.x_start = rangeBegin;
        _timelineConfigs.time_step = granularity;
    }

    function setFilteredEvents(date, refresh, dayTypes, updateCounters) {
        if (!dayTypes) {
            var filterTypes = getMenuFilterTypes();
            dayTypes = menuValuesToTypes(filterTypes);
        }

        refresh = typeof refresh !== 'undefined' ? refresh : true;
        updateCounters = typeof updateCounters !== 'undefined' ? updateCounters : false;

        var yUnits = getFilteredYUnits(dayTypes, date);
        if (updateCounters) {
            var dayTypeCounters = getDayEventsCount(date);
            updateMenuCounters(dayTypeCounters);
        }
        _timelineConfigs.y_unit = yUnits;

        if (refresh) {
            updateTimeline();
        }

        applyLineValidationStyles();
    }

    function deleteOtherEvents(event, seqNumber, isRemovePolyvalents) {
        isRemovePolyvalents = typeof isRemovePolyvalents !== 'undefined' ? isRemovePolyvalents : false;

        var removePolyvalentsCond = function (event, isRemovePolyvalents) {
            var res = true;
            if (!isRemovePolyvalents) {
                res = (event.isPolyvalent || event.isSectionPolyvalent) ? false : true;
            }
            return res;
        }

        var events = getCollabEvents(scheduler.getEvents(), event);
        var eventsToDelete = $.grep(events, function (ev) {
            return ev.seqNumber !== seqNumber &&
                   removePolyvalentsCond(ev, isRemovePolyvalents);

        });

        for (var i = 0; i < eventsToDelete.length; i++) {
            scheduler.deleteEvent(eventsToDelete[i].id);
        }

        var seqNumberEvent = $.grep(events, function (ev) {
            return ev.seqNumber === seqNumber;
        })

        return seqNumberEvent.length > 0 ? seqNumberEvent[0] : null;
    }

    function init(configs, isFirstTime) {
        if (isFirstTime) {
            _expandedDays = [];
        }
        setSchedulerConfigs(configs);
        setTimelineConfigs(configs);
        attachSchedulerEvents();
        setSchedulerTemplates(configs.viewName);
        attachOptionsMenu();
        setDayTimelineEvents(configs.date);
        setFilteredEvents(configs.date, false, { isWorkingDay: true }, true);
        scheduler.createTimelineView(_timelineConfigs);
        // scheduler.setCurrentView(configs.date, configs.viewName);
        registerEvents();
    }

    function setProperties(ev, periods) {
        _lightboxEvReturn = ev;
        _lightboxPeriodReturn = periods;
    }

    return {
        init: init,
        updateAllocatedQuantity: updateAllocatedQuantity,
        getCollaboratorsChartData: getCollaboratorsChartData,
        filterByDay: filterByDay,
        registerEvents: registerEvents,
        getContainer: getContainer,
        applyStyles: applyStyles,
        getValidationArea: getValidationArea,
        getCollabEvents: getCollabEvents,
        updateMenuCounters: updateMenuCounters,
        setFilteredEvents: setFilteredEvents,
        sortCollaborators: sortCollaborators,
        deleteOtherEvents: deleteOtherEvents,
        initEvent: initEvent,
        createIntervalEvent: createIntervalEvent,
        getDayTypesConsts: getDayTypesConsts,
        validateEvent: validateEvent,
        getAbsenceWorkstation:getAbsenceWorkstation,
        changeAbsenceWorkstation: changeAbsenceWorkstation,
        getProperties: getProperties,
        setProperties: setProperties,
        getEventsData: getEventsData,
    };
}();
