﻿var scheduleEditCollaboratorTime = function () {

    var sectionParent = null,
        rangeSettings = null,
        collaboratorID = null,
        date = null,
        isPolyvalent = false,
        containerSetting = null,
        hasAbsenceHalfTurn = null,
        isFirstTime = false,
        absenceTypeID = null,
        initialRangeSettings = null,
        canSaveOperataion = null;

    //#region Helpers

    function getCollaboratorID() {
        return collaboratorID;
    }

    function getSectionParent() {
        return sectionParent;
    }

    function getRangeSettings() {
        return rangeSettings;
    }

    function getSelectedView() {
        return $('#divEditLayer').find('#divViewChoose').data('selected');
    }

    function hasChange() {
        //o usuário acionou o modo "folga"
        if ($("#divEditLayer #divInfoChangeToAbsenceArea").is(":visible")) {
            return true;
        }

        // Verifica se os ranges possuem o mesmo tamanho
        if (rangeSettings.length != initialRangeSettings.length) {
            return false;
        }

        var changed = false;
        for (var i = 0; i < rangeSettings.length; i++) {

            // Verifica se houve alguma exclusão
            if (rangeSettings[i].HasDelete != initialRangeSettings[i].HasDelete) {
                changed = true;
            }

            // Se o indece for o principal
            if (rangeSettings[i].IsMainRange) {

            }

            // Se o indece for do intervalo
            if (rangeSettings[i].IsInterval) {
                // Verifica se houve alteração
                if (rangeSettings[i].IntervalTypeID != initialRangeSettings[i].IntervalTypeID) {
                    changed = true;
                }
            }

            // Verifica se houve alteração no posto de trabalho
            if (rangeSettings[i].WorkstationID != initialRangeSettings[i].WorkstationID) {
                changed = true;
            }

            // Verifica se houve alteração no tipo de posto
            if (rangeSettings[i].WorkstationTypeID != initialRangeSettings[i].WorkstationTypeID) {
                changed = true;
            }

            // Verifica se houve alteração de seção
            if (rangeSettings[i].SectionID != initialRangeSettings[i].SectionID) {
                changed = true;
            }

            // Verifica se houve alteração nos horários
            if (rangeSettings[i].BeginHourWork != initialRangeSettings[i].BeginHourWork) {
                changed = true;
            }

            // Verifica se houve alteração nos horários
            if (rangeSettings[i].EndHourWork != initialRangeSettings[i].EndHourWork) {
                changed = true;
            }

            // Verifica se foi removido a fogla
            if (rangeSettings[i].AbsenceType != initialRangeSettings[i].AbsenceType) {
                changed = true;
            }

            // Verifica se houve somente alteração no posto de trabalho
            if (rangeSettings[i].WorkstationID != initialRangeSettings[i].WorkstationID && changed == false) {
                changed = true;
                rangeSettings[i].HasEditWorkstation = true;
            }
        }

        return changed;
    }

    //#endregion Helpers

    //#region Actions   
    function openEdit(id, selectedDate) {
        if (scheduleModule.isCurrentDataTab()) {

            collaboratorID = id;
            date = selectedDate;

            //Serealiza parametros
            var parameters = JSON.stringify({
                unitID: $("#ddlUnit").val(),
                sectionID: $("#ddlSection").val(),
                workstatitonTypeID: $("#ddlWorkstationType").val(),
                collaboratorID: collaboratorID,
                date: date.toMSDate()
            });

            $.ajax({
                url: urlConfig.schedule.openEdit,
                data: parameters,
                success: function (response) {
                    if (response) {
                        // Converte o retorno em um objeto JSON
                        var result = JSON.parse(response);
                        if (result) {
                            if (result.hasSuccess) {
                                $("#divViewsAreaMessage").height($("#divViewsAreaMessage").parent().height());
                                $("#divViewsAreaMessage").empty().html(result.successResult);
                                $("#divViewsAreaMessage").slideDown("slow");
                                applySelect();
                                configAbsence();
                            } else {
                                dialogModule.showDialog(result.errorResult);
                            }
                        }
                    } else {
                        // Retorna a mensagem de erro
                        dialogModule.createDialog(0, _globalResources.getResource().ErrorTitle, _globalResources.getResource().CommunicationError);
                    }
                }
            });
        }
    }

    function saveAbsence() {
        var mainRangeSetting = null;

        for (var i = 0; i < rangeSettings.length; i++) {
            if (rangeSettings[i].IsMainRange === true) {
                mainRangeSetting = rangeSettings[i];
            }
        }

        if (!mainRangeSetting) {
            mainRangeSetting = rangeSettings[0];
        }

        var parameters = JSON.stringify({
            unitID: $("#ddlUnit").val(),
            sectionID: $("#ddlSection").val(),
            CollaboratorIDFrom: collaboratorID,
            WorkDayTypeFrom: $("#hdnOriginalDayTypeID").attr('data-value'),
            DateFrom: date.toMSDate(),
            StartTimeFrom: mainRangeSetting.BeginHourWork.toMSDate(),
            IntervalStartTimeFrom: mainRangeSetting.IntervalStartTimeFrom ? mainRangeSetting.IntervalStartTimeFrom.toMSDate() : null,
            IntervalEndTimeFrom: mainRangeSetting.IntervalEndTimeFrom ? mainRangeSetting.IntervalEndTimeFrom.toMSDate() : null,
            EndTimeFrom: mainRangeSetting.EndHourWork.toMSDate(),
            CollaboratorIDTo: collaboratorID,
            WorkDayTypeTo: $("#hdnChangeToAbsenceDayTypeID").attr('data-value'),
            DateTo: date.toMSDate(),
            RequestReasonID: (sectionParent.find("#ddlAlterReason").val() == '' ? null : sectionParent.find("#ddlAlterReason").val())
        });

        $.ajax({
            url: urlConfig.schedule.saveEditAbsence,
            data: parameters,
            success: function (response) {
                if (response) {
                    var result = JSON.parse(response);

                    if (result) {
                        if (result.hasSuccess) {
                            $("#divEditLayer").find("#btnEditClose").trigger('click');
                            dialogModule.showDialog(result.successResult);
                            scheduleModule.updateSchedule();
                        } else {
                            dialogModule.showDialog(result.errorResult);
                        }
                    }
                } else {
                    // Retorna a mensagem de erro
                    dialogModule.createDialog(0, _globalResources.getResource().ErrorTitle, _globalResources.getResource().CommunicationError);
                }
            }
        });
    }

    function saveEdit() {
        if (scheduleModule.isCurrentDataTab()) {

            if (!hasChange()) {
                // Retorna uma mensagem de alerta que não houve alterações
                dialogModule.createDialog(0, _globalResources.getResource().schedule.edit.NothingChangeTitle, _globalResources.getResource().schedule.edit.NothingChangeMessage);
                return;
            }

            var sectionParent = $("#divEditLayer");
            if ($("#divEditLayer #divInfoChangeToAbsenceArea").is(":visible")) {
                saveAbsence();
                return;
            }

            //Serializa parametros
            var parameters = JSON.stringify({
                collaboratorID: collaboratorID,
                date: date.toMSDate(),
                alterReasonID: (sectionParent.find("#ddlAlterReason").val() == '' ? null : sectionParent.find("#ddlAlterReason").val()),
                scheduleID: sectionParent.find("#hdnScheduleID").val(),
                rangeValues: rangeSettings
            });

            $.ajax({
                url: urlConfig.schedule.saveEdit,
                data: parameters,
                success: function (response) {
                    if (response) {
                        // Converte o retorno em um objeto JSON
                        var result = JSON.parse(response);
                        if (result) {
                            $("#divViewsAreaMessage").height($("#divViewsAreaMessage").parent().height());
                            if (result.hasSuccess) {
                                sectionParent.find("#btnEditClose").trigger('click');
                                dialogModule.showDialog(result.successResult);
                                // Chama a atualização dos dados da visão aberta no momento
                                scheduleModule.updateSchedule();
                            } else {
                                dialogModule.showDialog(result.errorResult);
                            }
                        }
                    } else {
                        // Retorna a mensagem de erro
                        dialogModule.createDialog(0, _globalResources.getResource().ErrorTitle, _globalResources.getResource().CommunicationError);
                    }
                }
            });

        }
    }

    function deleteEdit(answer) {
        if (answer || answer === true) {
            if (scheduleModule.isCurrentDataTab()) {

                //Serealiza parametros
                var parameters = JSON.stringify({
                    collaboratorID: collaboratorID,
                    scheduleID: sectionParent.find("#hdnScheduleID").val(),
                    date: date.toMSDate(),
                    isPolyvalent: isPolyvalent
                });

                $.ajax({
                    url: urlConfig.schedule.deleteEdit,
                    data: parameters,
                    success: function (response) {
                        if (response) {
                            // Converte o retorno em um objeto JSON
                            var result = JSON.parse(response);
                            if (result) {
                                $("#divViewsAreaMessage").height($("#divViewsAreaMessage").parent().height());
                                if (result.hasSuccess) {
                                    sectionParent.find("#btnEditClose").trigger('click');
                                    dialogModule.showDialog(result.successResult);
                                    // Chama a atualização dos dados da visão aberta no momento
                                    scheduleModule.updateSchedule();

                                    sectionParent.slideUp("slow");

                                    setTimeout(function () {
                                        //destroySlider();
                                        $("#divViewsAreaMessage").height(0);
                                        $("#divViewsAreaMessage").hide();
                                        $("#divViewsAreaMessage").empty();
                                    }, 500);

                                } else {
                                    dialogModule.showDialog(result.errorResult);
                                }
                            }
                        } else {
                            // Retorna a mensagem de erro
                            dialogModule.createDialog(0, _globalResources.getResource().ErrorTitle, _globalResources.getResource().CommunicationError);
                        }
                    }
                });
            }
        }
    }

    function buildAbsenceRangeSettings() {
        rangeSettings[0].AbsenceType = "F";
        rangeSettings[0].BeginHourWork = rangeSettings[0].BeginRange.toMSDate();
        rangeSettings[0].EndHourWork = rangeSettings[0].EndRange.toMSDate();
        rangeSettings[0].HasEdit = true;
    }
    //#endregion

    //#region Events - Buttons
    function deleteEditTime(e) {
        var isMain = $(e.target).data('main'),
            isInterval = $(e.target).data('interval'),
            index = $(e.target).data('index');

        // Verifica se é a range principal
        if (isMain.toLowerCase() === 'true') {
            // Click do botão de exclusão da layer
            sectionParent.find("#btnEditDelete").trigger('click');
        } else if (isInterval.toLowerCase() === 'true') {
            // Se clicou no botão de exclusão do intervalo
            // Seta o select para 'S': Sem Intervalo
            sectionParent.find('#ddlIntervalType_' + index).val('S').trigger('update');
            // Seta o range com o valor sem intervalo
            rangeSettings[index].IntervalTypeID = 'S';
            // Desabilidata o click do botão
            sectionParent.find('#btnEditTimeDelete_' + index).off('click').addClass('button-disabled');
            // Desabilita o slider ou os inputs
            scheduleManualEditCollaboratorTime.disabledInterval(index);
            scheduleVisualEditCollaboratorTime.disabledInterval(index);
            // Marco como alterado
            rangeSettings[index].HasEdit = true;
        } else {
            // Trata os demais casos, removendo a polivalência
            rangeSettings[index].HasDelete = true;
            $(e.target).parents('.container-time').remove();
        }
    }

    function saveEditClick(e) {


        if (e.data.action == 'save') {
            if ($('#divTimeArea').data("has-error") === true)
                return;

            if (sectionParent.find('#ddlAlterReason').val() == '' && !isPolyvalent) {
                validateModule.appendStyleError(sectionParent.find('#ddlAlterReason').siblings());
                validateModule.appendStyleError(sectionParent.find('#ddlAlterReason'));
                dialogModule.showOK(_globalResources.getResource().schedule.edit.RequeriedField, _globalResources.getResource().schedule.edit.SaveRequeriedAlterReason);
                return;
            } else {
                validateModule.removeStyleError(sectionParent.find('#ddlAlterReason').siblings());
                validateModule.removeStyleError(sectionParent.find('#ddlAlterReason'));
                // Chama a função para realizar o save dos horários
                saveEdit();
            }
        } else {
            sectionParent.slideUp("slow");

            setTimeout(function () {
                $("#divViewsAreaMessage").height(0);
                $("#divViewsAreaMessage").hide();
                $("#divViewsAreaMessage").empty();
            }, 500);
        }
    }

    function confirmDeleteTimeClick(e) {
        // Apresenta a modal para confirmação de exclusão
        dialogModule.showYesOrNo(_globalResources.getResource().schedule.edit.ConfirmDeleteTile, _globalResources.getResource().schedule.edit.ConfirmDeleteMessage, deleteEdit);
    }

    function confirmChangeClick(e) {
        // Apresenta a modal para confirmação de exclusão
        dialogModule.showYesOrNo(_globalResources.getResource().schedule.edit.AbsenceHalfTurnTitle, _globalResources.getResource().schedule.edit.AbsenceHalfTurnMessage, changeHalfAbsence);
    }

    function showViewMode(e) {
        var divViewChoose = sectionParent.find('#divViewChoose'),
            action = e.data.isFirstTime;

        if (e.data.action === 'visual') {
            if ($('#divTimeArea').data("has-error") !== true) {
                $('#lnkVisual').addClass('active');
                $('#lnkManual').removeClass('active');

                sectionParent.find('.manual-view').hide();
                sectionParent.find('.visual-view').show();

                scheduleVisualEditCollaboratorTime.init(isFirstTime, (canSaveOperation == 'true'));

                isFirstTime = false;

                divViewChoose.data('selected', 'visual');
            }
        } else if (e.data.action === 'manual') {
            $('#lnkManual').addClass('active');
            $('#lnkVisual').removeClass('active');

            sectionParent.find('.visual-view').hide();
            sectionParent.find('.manual-view').show();

            scheduleManualEditCollaboratorTime.init(canSaveOperation == 'true');

            divViewChoose.data('selected', 'manual');
        }
    }
    //#endregion Events - Buttons

    //#region Events to Absence

    function clickUndoAbsence(e) {
        sectionParent = $("#divEditLayer");
        sectionParent.find('#divInfoAbsenceArea').hide();
        sectionParent.find('#divTimeArea').show();

        // Remove o tipo de folga do objeto
        $(rangeSettings).each(function (index) {
            if ($(this).isMain) {
                $(this).AbsenceType = null;
            }
        });

        openViewMode();
    }

    function clickUndoChangeToAbsence(e) {
        sectionParent = $("#divEditLayer");
        var editAbsenceArea = sectionParent.find('#divInfoChangeToAbsenceArea')
        editAbsenceArea.hide();
        sectionParent.find('#' + editAbsenceArea.data('last-visible-area')).show();
    }

    function absenceClick() {
        var sectionParent = $("#divEditLayer");

        var editAbsenceArea = sectionParent.find('#divInfoChangeToAbsenceArea');

        if (sectionParent.find('#divTimeArea').is(':visible'))
            editAbsenceArea.data('last-visible-area', 'divTimeArea');

        if (sectionParent.find('#divInfoAbsenceArea').is(':visible'))
            editAbsenceArea.data('last-visible-area', 'divInfoAbsenceArea');

        sectionParent.find('#divTimeArea').hide();
        sectionParent.find('#divInfoAbsenceArea').hide();
        editAbsenceArea.show();

        editAbsenceArea.find('#lblChangeToAbsenceUndoOperation').off('click').on('click', clickUndoChangeToAbsence);
    }

    //#endregion Events to Absence

    //#region Functions    

    function closeEdit() {
        $("#divEditLayer").find("#btnEditClose").trigger('click');
    }

    function configAbsence() {
        var sectionParent = $("#divEditLayer");

        if (absenceTypeID) {
            sectionParent.find('#divTimeArea').hide();
            sectionParent.find('#divInfoAbsenceArea').show();
            sectionParent.find('#lblUndoOperation').off('click').on('click', clickUndoAbsence);
        } else {
            sectionParent.find('#divTimeArea').show();
            sectionParent.find('#ddlAlterReason').removeAttr('disabled');
        }
    }

    function registerEvents() {
        var container = sectionParent;
        // Registra o botão folgar
        container.find('#btnEditAbsence').off('click').on('click', absenceClick);
        // Registra o botão fechar
        container.find('#btnEditClose').off('click').on('click', { action: 'close' }, saveEditClick);
        // Registra o botão salvar
        container.find('#btnEditSave').off('click').on('click', { action: 'save' }, saveEditClick);
        // Registra o botão deletar
        container.find('#btnEditDelete').off('click').on('click', confirmDeleteTimeClick);
        // Registra o click para alternar as visões de edição
        container.find('#lnkVisual').off('click').on('click', { action: 'visual' }, showViewMode);
        container.find('#lnkManual').off('click').on('click', { action: 'manual' }, showViewMode);
        // Registra o click para os botões de Delete de Intervalos, Polivalências e Jornada principal
        sectionParent.find('.container-button a').off('click').on('click', deleteEditTime);
    }

    function setSize() {
        var mainWidth = $("#tabData").width(),
            rangeArea = sectionParent.find('.container-time').find('#divTimeContainer'),
            containerButtonWidth = sectionParent.find('.container-button').width(),
            containerWidth = sectionParent.find('.container').width();

        rangeArea.width(mainWidth - containerButtonWidth - containerWidth - 50);
    }

    function openViewMode() {
        var sectionParent = $("#divEditLayer"),
            divViewChoose = sectionParent.find('#divViewChoose');

        switch (divViewChoose.data('selected')) {
            default:
            case 'visual':
                sectionParent.find('#lnkVisual').trigger('click');
                break;
            case 'manual':
                sectionParent.find('#lnkManual').trigger('click');
                break;
        }
    }

    function applySelect() {
        customControlsModule.applySelectControl("divEditLayer", true);
        openViewMode();
    }

    function adjustHeight(height) {
        // Se estiver selecionada a tab de dados de escalas
        if (scheduleModule.isCurrentDataTab()) {
            // Se estiver visivel a layer de edição
            if (scheduleModule.getSectionParent().find('#divEditLayer').is(':visible')) {
                scheduleModule.getSectionParent().find('#divEditLayer').css('height', height);
                scheduleModule.getSectionParent().find('#divViewsAreaMessage').css('height', height);
            }
        }
    }

    //#endregion Functions

    function init(absenceTypeId, absenceHalfTurn, settings, canSave) {
        canSaveOperation = canSave;
        sectionParent = $("#divEditLayer");
        rangeSettings = JSON.parse(settings);
        // Armazena os valores originais do range de configurações da edição
        initialRangeSettings = JSON.parse(settings);
        hasAbsenceHalfTurn = absenceHalfTurn;
        absenceTypeID = absenceTypeId;
        isFirstTime = true;

        setSize();
        registerEvents();

        var divHalfAbsence = sectionParent.find('.half-absence');
        // Verifica se possui folga de meio turno            
        if (hasAbsenceHalfTurn === 'true') {
            divHalfAbsence.show();
            divHalfAbsence.find('#chkHasHalfAbsence').off('change').on('change', confirmChangeClick).prop('checked', true);
        } else {
            divHalfAbsence.hide();
        }

        scrollModule.createScrollPaneAdjustedHeight(sectionParent);

        sectionParent.find('[name="section"]').each(function (index) {
            $(this).trigger('change');
        });
    }

    return {
        init: init,
        applySelect: applySelect,
        openEdit: openEdit,
        closeEdit: closeEdit,
        adjustHeight: adjustHeight,
        getCollaboratorID: getCollaboratorID,
        getRangeSettings: getRangeSettings,
        getSectionParent: getSectionParent,
        getSelectedView: getSelectedView,
        deleteEdit: deleteEdit,
        deleteEditTime: deleteEditTime
    }

}();