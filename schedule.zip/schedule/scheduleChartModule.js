var scheduleChartModule = function () {

    var chartElement = null;
    var arrayAllocatedValue = null;
    var arrayAllocatedValueUpdated = null;
    var _chartData = [];

    function init(element) {
        chartElement = element;
        chartElement.highcharts({
            chart: {
                //zoomType: 'xy',
                // renderTo: 'container',
                animation: false
            },
            credits: {
                enabled: false
            },
            //exporting: {
            //    enabled: true
            //},
            title: {
                text: ''
            },
            tooltip: {
                shared: false
            },
            plotOptions: {
                spline: {
                    marker: {
                        radius: 4,
                        lineColor: '#666666',
                        lineWidth: 1
                    }
                }
            },
            xAxis: {
                categories: [],
                opposite: true,
                labels: {
                    rotation: -90,
                    y: -25,
                    x: 4,
                    zIndex: 6
                }
            },
            yAxis: {
                opposite: true,
                title: '',
                allowDecimals: false,
                stackLabels: {
                    verticalAlign: null
                },
                labels: {
                    zIndex: 6
                }
            },
            tooltip: {
                formatter: function () {
                    return '<b>' + this.series.name + '</b><br/>' +
                    this.x + ': ' + '<b>' + this.y + '</b>';
                }
            },
            legend: {
                layout: 'horizontal',
                backgroundColor: 'white',
                floating: false,
                draggable: false,
                zIndex: 900
            },
            series: [
            {
                type: 'column',
                name: _globalResources.getResource().schedule.chart.Ideal,
                data: [],
                color: '#6FC984'
            },
            {
                type: 'spline',
                name: _globalResources.getResource().schedule.chart.Allocated,
                data: [],
                color: '#FF0000',
                marker: {
                    symbol: 'square',
                    radius: 3,
                    lineWidth: 2,
                    lineColor: '#FF0000',
                    fillColor: 'white'
                },
                dataLabels: {
                    enabled: true,
                }
            },
            {
                type: 'spline',
                name: _globalResources.getResource().schedule.chart.Calculated,
                data: [],
                color: '#909992',
                marker: {
                    symbol: 'diamond',
                    radius: 3,
                    lineWidth: 2,
                    lineColor: '#909992',
                    fillColor: 'white'
                }
            },
            {
                type: 'spline',
                name: _globalResources.getResource().schedule.chart.Performed,
                data: [],
                color: '#003DCC',
                marker: {
                    symbol: 'circle',
                    radius: 3,
                    lineWidth: 2,
                    lineColor: '#003DCC',
                    fillColor: 'white'
                }
            }
            ]
        });
    }

    //Função chamada para trazer os dados do período selecionado
    function updateChart(element, startDate, isFirstTime) {
        if (scheduleModule.isCurrentDataTab()) {

            scheduleModule.getTopViewPageLoader().show();

            // Inicializa o gráfico
            if (isFirstTime === true) {
                init(element);
            }

            var workstationTypeIDsToInt = [];
            if ($("#ddlWorkstationType").val() != null && $("#ddlWorkstationType").val() != "")
            {
                workstationTypeIDsToInt = $("#ddlWorkstationType").val().map(function (item) {
                    return parseInt(item, 10);
                });
            }
            
            startDate = scheduleBaseTimelineModule.stringToDate(startDate, 'dd/mm/yyyy', '/');
            startDate = new Date(+startDate - (startDate.getTimezoneOffset() * 60000));

            //Serealiza parametros
            var parameters = JSON.stringify({
                unitID: $("#ddlUnit").val(),
                sectionID: $("#ddlSection").val(),
                workstationTypeID: workstationTypeIDsToInt,
                startDate: startDate
            });

            $.ajax({
                url: urlConfig.schedule.chart,
                data: parameters,
                success: function (response) {
                    if (response) {
                        //Parsevar RetVal;
                        var result = JSON.parse(response);

                        if (result) {

                            if (result.hasSuccess) {

                                $("#divChartAreaMessage").empty();
                                chartElement.show();
                                var chart = chartElement.highcharts();
                                arrayAllocatedValue = result.successResult.EstimateValues;
                                arrayAllocatedValueUpdated = result.successResult.EstimateValuesUpdated;

                                chart.xAxis[0].setCategories(result.successResult.Hours, false);
                                chart.series[0].setData(result.successResult.Ideal, false);
                                chart.series[1].setData(result.successResult.Allocated, false);
                                chart.series[2].setData(result.successResult.Calculated, false);
                                chart.series[3].setData(result.successResult.Performed, false);
                                chart.redraw();

                            } else {
                                chartElement.hide();
                                $("#divChartAreaMessage").html(result.errorResult);
                            }

                            scheduleModule.getTopViewPageLoader().hide();
                        }
                    }
                }
            });
        }
    }

    function updateChart_DISCARDED(element, startDate, isFirstTime)
    {
        if (scheduleModule.isCurrentDataTab()) {

            var sectionListIDs      = $("#ddlSection").val(),
                sectionListIDsNew   = $("#ddlSectionMulti").val(),
                workstationListIDs  = $("#ddlWorkstationTypeMulti").val() || [],
                _chartData          = [],
                errorRsp;

            scheduleModule.getTopViewPageLoader().show();

            // Inicializa o gráfico
            if (isFirstTime === true) {
                init(element);
            }

            //Invoke recursive function to transform Asynchronous Ajax Call in Synchronous Call
            //because Chart must be created only AFTER all Ajax Calls done
            getChartValues(sectionListIDsNew, sectionListIDsNew.length, 0, workstationListIDs, workstationListIDs.length, 0, startDate, _chartData, errorRsp, function (err, chartData) {
               var hours      = [],
                   ideal      = [],
                   allocated  = [],
                   calculated = [],
                   performed  = [];

               if (chartData.length > 0)
               {
                   hours = chartData[0].hours;

                    //It's necessary to merge all Ajax Responses to draw the Chart
                   for (i = 0; i < chartData.length; i++) {

                       arrayAllocatedValue = chartData[0].arrayAllocatedValue;
                       arrayAllocatedValueUpdated = chartData[0].arrayAllocatedValueUpdated;

                       //Merge all Arrays from Ajax Calls
                       for (j = 0; j < hours.length; j++) {

                           ideal[j]      = (ideal[j] || 0)      + chartData[i].ideal[j];
                           allocated[j]  = (allocated[j] || 0)  + chartData[i].allocated[j];
                           calculated[j] = (calculated[j] || 0) + chartData[i].calculated[j];
                           performed[j]  = (performed[j] || 0)  + chartData[i].performed[j];
                       }
                   }

                   //Draw the chart with merged Data
                   $("#divChartAreaMessage").empty();
                   chartElement.show();
                   var chart = chartElement.highcharts();

                   chart.xAxis[0].setCategories(hours, false);
                   chart.series[0].setData(ideal, false);
                   chart.series[1].setData(allocated, false);
                   chart.series[2].setData(calculated, false);
                   chart.series[3].setData(performed, false);
                   chart.redraw();

               } else {
                   chartElement.hide();
                   $("#divChartAreaMessage").html(err.errorResult);
               }
               scheduleModule.getTopViewPageLoader().hide();
            });
        }

    }

    function getChartValues(sectionListIDs, sectionListSize, sectionListPosi, workstationListIDs, workstationListIDsSize, workstationListIDsPosi, startDate, chartData, errorRsp, callback)
    {
        if (sectionListPosi < sectionListSize) {
            //If Multiselection Section
            if (sectionListSize > 1 || workstationListIDsSize <= 1)
            {
            //Serealiza parametros
            var parameters = JSON.stringify({
                unitID: $("#ddlUnit").val(),
                sectionID: sectionListIDs[sectionListPosi],
                workstationTypeID: workstationListIDs[workstationListIDsPosi] || "",
                startDate: startDate.toMSDate()
            });

            requestAjax(parameters, function (err, data) {
                if (!err) {
                    chartData.push(data);

                    getChartValues(sectionListIDs, sectionListSize, sectionListPosi + 1, workstationListIDs, workstationListIDsSize, workstationListIDsPosi, startDate, chartData, errorRsp, callback);
                }
                else {
                    errorRsp = err;
                    getChartValues(sectionListIDs, sectionListSize, sectionListPosi + 1, workstationListIDs, workstationListIDsSize, workstationListIDsPosi, startDate, chartData, errorRsp, callback);
                }
            });
            } else {
                //If only one Section is selected
                if (workstationListIDsPosi < workstationListIDsSize) {
                    //Serealiza parametros
                    var parameters = JSON.stringify({
                        unitID: $("#ddlUnit").val(),
                        sectionID: sectionListIDs[sectionListPosi],
                        workstationTypeID: workstationListIDs[workstationListIDsPosi],
                        startDate: startDate.toMSDate()
                    });

                    requestAjax(parameters, function (err, data) {
                        if (!err) {
                            chartData.push(data);

                            getChartValues(sectionListIDs, sectionListSize, sectionListPosi, workstationListIDs, workstationListIDsSize, workstationListIDsPosi + 1, startDate, chartData, errorRsp, callback);
                        }
                        else {
                            errorRsp = err;
                            getChartValues(sectionListIDs, sectionListSize, sectionListPosi, workstationListIDs, workstationListIDsSize, workstationListIDsPosi + 1, startDate, chartData, errorRsp, callback);
                        }
                    });
                } else {
                    callback(errorRsp, chartData);
                }
            }
    }
        else {
            callback(errorRsp, chartData);
        }
    }

    function requestAjax(parameters, callback) {
            $.ajax({
                url: urlConfig.schedule.chart,
                data: parameters,
                success: function (response) {
                    if (response) {
                        //Parsevar RetVal;
                        var result = JSON.parse(response);

                        if (result) {
                            if (result.hasSuccess) {
                                var chartDataObj = {
                                    arrayAllocatedValue: result.successResult.EstimateValues,
                                    arrayAllocatedValueUpdated: result.successResult.EstimateValuesUpdated,
                                    hours: result.successResult.Hours,
                                    ideal: result.successResult.Ideal,
                                    allocated: result.successResult.Allocated,
                                    calculated: result.successResult.Calculated,
                                    performed: result.successResult.Performed
                                };

                                callback(null, chartDataObj);
                            } else {
                                callback(result);
                            }
                        }
                    }
                },
                error: function (response) {
                    callback(response);
                }
            });
    };

    function updatedAllocatedAxi(index, newValue) {

        if (newValue == 0) {
            newValue = arrayAllocatedValue[index];
        }
        arrayAllocatedValueUpdated[index] = parseInt(newValue);

        var chart = chartElement.highcharts();
        chart.series[1].update({
            data: arrayAllocatedValueUpdated
        });
        chart.series[1].show();
    }

    return {
        updateChart: updateChart,
        //updateChartMulti: updateChartMulti,
        updatedAllocatedAxi: updatedAllocatedAxi
    };

}();
