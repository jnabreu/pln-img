var scheduleRestDaysYearModule = function () {

    var gSchedulerConfigs = {
        xmlDate: "%Y-%m-%d %H:%i",
        showLoading: true,
        yearX: 4,
        yearY: 4,
        readonly: true,
    };

    var gCurrentCollabID = 0;

    // function loadView(unitID, sectionID, workstationTypeID, selectedDate, endDate) {
    //     if (scheduleModule.isCurrentRestTab()) {
    //         loadSchedule();
    //     }
    // }

    function getContainer() {
        return $('#restYearContent');
    }
    
    // TODO: select year and collaborator
    function loadSchedule(collab, year, dateSel) {
        /// <summary>
        /// requests the load of the scheduler view
        /// </summary>
        /// <returns type=""></returns>

        year = year ? year : newDate().getYear();

        $('#restYearContent').show();
        scheduleModule.showDropdowns(true, true, true, true, false, false);
        scheduleModule.enableDropdowns(false, false, false, false, false, false);

        $("#ddlCollaborator").clearSelect();
        $('#ddlCollaborator').fillSelect([{ ID: collab.id, Name: collab.name }], 'ID', 'Name', true);
        $('#ddlCollaborator').val(collab.id).change();
        var visibleCategories = []; // [DATE_CATEGORIES.REST, DATE_CATEGORIES.ABSENCE];
        var visibleTypes = [];

        initDHXScheduler(collab.id, gSchedulerConfigs, dateSel);
        scheduleModule.getMainPageLoader().hide();
    }

    function applyCSSEventColor(type, color) {
        $('.dhx_month_head.dhx_year_event' + '.' + type).css('background-color', color);
    }

    function defineEventClass(start, end, event) {
        return (event.type ? event.type : "");
    }

    function defineYearMonth(date) {
        var date_to_str = scheduler.date.date_to_str("%F %Y");
        return '<a href="#" class="gotoTimeline" data-gototimeline="' + date.toISOString() + '">' +
                date_to_str(date) + '</a>';
    }

    function filterYearViewClosure(collaboratorID) {
        return function (eventId, event) {
            if (typeof (collaboratorID) === 'number') {
                collaboratorID = collaboratorID.toString();
            }
            if (event.collabID === collaboratorID) {
                return true;
            } else {
                return false;
            }
        }
    }

    function pushDHXTabsLeft() {
        //$('.schedule-container .content .tabs .tabRest #restYearContent .dhx_cal_tab.tab_week').css('left', '14px');
        //$('.schedule-container .content .tabs .tabRest #restYearContent .dhx_cal_tab.tab_month').css('left', '75px');
        //$('.schedule-container .content .tabs .tabRest #restYearContent .dhx_cal_tab.tab_year').css('left', '160px');

        // $('.schedule-container .content .tabs .tabRest #restYearContent .dhx_cal_tab.tab_year').css('left', '14px');
    }

    // DEPRECATED: with no approve button there is no need to refresh the view after approve
    //function refreshYearView() {
    //    $.map(gEventDates, function(elem) {
    //        return schedulerRestDays.updateType(elem,
    //            schedulerRestDays.DATE_CATEGORIES.REST,
    //            schedulerRestDays.DATE_TYPES.REST,
    //            schedulerRestDays.REST_STATE.APPROVED);
    //    });
    //}

    // DEPRECATED: approve button is not used on yearly view
    //function registerClickApproveCollaborator(collabID) {
    //    $('#tabRest #divRestButtonsArea #btnApproveRest').off('click').on('click', function(ev) {
    //        scheduleEventsModule.approveCollaboratorsRest([collabID], refreshYearView);
    //    });
    //}

    function registerMarkToApprove(collabID) {
        $('#tabRest #divRestButtonsArea #checkMarkApprove').off('change').on('change', function (ev) {
            if ($(this).is(':checked')) {
                scheduleRestDaysTimelineModule.addToSelectedCollaborators(collabID.toString());
            } else if ($(this).is(':unchecked')) {
                scheduleRestDaysTimelineModule.removeFromSelectedCollaborators(collabID.toString());
            } else {
                console.error("Couldn't perform select operation");
            }
        });
        // scheduleEventsModule.approveCollaboratorsRest([collabID], refreshYearView);
    }

    function registerClickGotoTimeline() {
        var elem = $('#year_rest_schedule .gotoTimeline');
        // var openDate = new Date(elem.data('gototimeline'));
        elem.off('click').on('click', scheduleRestDaysTimelineModule.gotoTimelineCallback);
    }

    function registerCloseEvent() {
        $('#yearCloseButton').off('click').on('click',
            scheduleRestDaysTimelineModule.closeRestDayYearView);
    }

    function testAndApplyCheckbox(collabID) {
        var checkbox = $('#tabRest #divRestButtonsArea #checkMarkApprove');
        if (scheduleRestDaysTimelineModule.existsOnSelectedCollaborators(collabID.toString())) {
            checkbox.prop('checked', true);
        } else {
            checkbox.prop('checked', false);
        }
    }

    function viewChangeCallback(params) {
        var events = params[0],
            collabID = params[1];

        // var triggeredFrom = (params[2] ? params[2] : "not defined");
        // console.info("Triggered by: ", triggeredFrom);

        for (var key in events) {
            var event = events[key];
            vPath = scheduleEventsModule.getVPathFromType(event.type);
            applyCSSEventColor(event.type, scheduleEventsModule
                .getProperty(vPath, scheduleEventsModule.getConstants().PROPERTIES.COLOR));
        }

        pushDHXTabsLeft();
        registerCloseEvent();
        registerClickGotoTimeline();
        testAndApplyCheckbox(collabID);
        registerMarkToApprove(collabID);
    }

    function overrideDHXTooltipBehavior() {
        scheduler._init_year_tooltip = function () {
            scheduler._detachDomEvent(scheduler._els["dhx_cal_data"][0], "mouseover", scheduler._year_view_tooltip_handler);
            // Commented in order NOT TO SHOW the tooltip
            // dhtmlxEvent(scheduler._els["dhx_cal_data"][0], "mouseover", scheduler._year_view_tooltip_handler);
        };
    }

    function getEvents(collabID) {
        var events = $.grep(scheduler.getEvents(), function (elem, index) {
            return elem.collabID == collabID;
        });
        return events;
    }

    function initDHXScheduler(collabID, configs, dateSel) {
        // TODO: format date accordingly with location
        scheduler.config.xml_date = configs.xmlDate;
        scheduler.config.show_loading = configs.showLoading;
        scheduler.config.year_x = configs.yearX;
        scheduler.config.year_y = configs.yearY;
        scheduler.config.readonly = configs.readonly;

        scheduler.locale = dhtmlxSchedulerLocale.getDHTMLXLocale();
        scheduler.locale.labels['close' + '_tab'] = "&times;";

        scheduler.templates.event_class = defineEventClass;
        scheduler.templates.year_month = defineYearMonth;

        scheduler.filter_year = filterYearViewClosure(collabID);

        var eventDates = getEvents(collabID);

        scheduleEventsModule.attachEventToScheduler("onViewChange", viewChangeCallback, [eventDates, collabID, "onViewChange"]);
        scheduleEventsModule.attachEventToScheduler("onSchedulerResize", viewChangeCallback, [eventDates, collabID, "resize"]);
        overrideDHXTooltipBehavior();

        scheduler.init('year_rest_schedule', new Date(parseInt(dateSel.toMSDate().substr(6))), "year");
        viewChangeCallback([eventDates, collabID, 'After Init']);
    }

    return {
        loadSchedule: loadSchedule,
    }
}();

