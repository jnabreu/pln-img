﻿var scheduleWeekDetailModule = function () {

    var _unitID, _sectionID, _workstationTypeID = [], _searchTermCollaborator, _scheduleWeekDetaiHeight, _startDate, _endDate;

    //#region Helpers
    function getContainer() {
        return $('#divViewWeekDetail');
    }

    function getScrollContainer() {
        return 'divViewWeekDetailScroll';
    }

    function setVisibleArea() {
        var heightParent = parseInt(getContainer().parent().css('height')),
            height = parseInt($('#tblWeekDetail').css('height'));

        getContainer().find('#' + getScrollContainer()).css({ 'height': (heightParent - height) + 'px' });
        getContainer().find('#' + getScrollContainer()).scrollTop(0);
        scrollModule.updateScroll(getScrollContainer());
    }
    //#endregion Helpers

    function myParent() {
        return $("#tabWeek");
    }

    function mySelf() {
        return myParent().find("#week-detail");
    }

    function loadView(unitID, sectionID, workstationTypeID, startDate, endDate, searchTermCollaborator) {
        if (scheduleModule.isCurrentWeekTab()) {

            scheduleModule.getMainPageLoader().show();
            //Fecha a tela de Detalhe Diário
            scheduleDailyDetailModule.close();

            _unitID = _unitID,
            _sectionID = sectionID,
            //_workstationTypeID = workstationTypeID,
            _searchTermCollaborator = searchTermCollaborator,
            _startDate = startDate,
            _endDate = endDate;

            if ($("#ddlWorkstationType").val() != null && $("#ddlWorkstationType").val() != "") {
                _workstationTypeID = $("#ddlWorkstationType").val().map(function (item) {
                    return parseInt(item, 10);
                });
            } else {
                _workstationTypeID = [];
            }

            //Serealiza parametros
            var parameters = JSON.stringify({
                unitID: unitID,
                sectionID: sectionID,
                workstationTypeID: _workstationTypeID,
                startDate: startDate.toMSDate(),
                endDate: endDate.toMSDate(),
                searchTermCollaborator: searchTermCollaborator
            });

            $.ajax({
                url: urlConfig.schedule.showWeeklyDetail,
                data: parameters,
                success: function (response) {
                    if (response) {
                        // Converte o retorno em um objeto JSON
                        var result = JSON.parse(response);
                        if (result) {
                            if (result.hasSuccess) {
                                //Valida se já tem tamanho definido na grade de dados
                                if (!_scheduleWeekDetaiHeight)
                                    _scheduleWeekDetaiHeight = myParent().height() - myParent().find(".buttons-area").height();
                                mySelf().height(_scheduleWeekDetaiHeight).empty().html(result.successResult);
                                lcmModule.registerCheckLCMScheduleEvent('divBottomArea');
                            } else {
                                mySelf().empty().html(result.errorResult);
                            }
                        }
                    } else {
                        // Retorna a mensagem de erro
                        dialogModule.createDialog(0, _globalResources.getResource().ErrorTitle, _globalResources.getResource().CommunicationError);
                    }

                    scheduleModule.getMainPageLoader().hide();
                }
            });
        }
    }

    function printReport() {
        var url = urlConfig.reports.weekDetailSchedule,
            showDifference = myParent().find('#chkHasDifference').is(':checked');

        weekDetailScheduleReportModule.printReport(url, _unitID, _sectionID, _workstationTypeID, _startDate, _endDate, _searchTermCollaborator, showDifference);
    }

    function showHasDifference(e) {
        if ($(e.target).is(':checked')) {
            myParent().find('[data-diff="0"]').hide();
            myParent().find('[data-diff="1"]').show();
        } else {
            myParent().find('[data-diff="0"]').show();
            myParent().find('[data-diff="1"]').show();
        }
        setVisibleArea();
    }

    function hide() {
        mySelf().hide();
    }

    function show() {
        var btnComeBack = myParent().find("#btnWeekBack");
        btnComeBack.prop("disabled", true);
        btnComeBack.css({ cursor: "default" });
        btnComeBack.off("click");

        myParent().find('#btnDetailPrint').off('click').on('click', printReport);

        $("#divTitle").text(_globalResources.getResource().schedule.header.WeeklyDetailTitle);
        $("#divSubtitle").html(_globalResources.getResource().schedule.header.WeeklyDetailSubtitle).show();

        mySelf().show();
    }

    function registerEvents() {
        $("#divViewWeekDetail").find(".table-column[data-date]").off("click").on("click", function () {
            scheduleDailyDetailModule.loadView(_unitID, _sectionID, _workstationTypeID, $(this).data("date"), _searchTermCollaborator);
        });

        myParent().find('#btnDetailPrint').off('click').on('click', printReport);
        myParent().find('#chkHasDifference').off('click').on('click', showHasDifference);
    }

    //#region Init
    function init() {
        scheduleModule.setSize();
        myParent().find("#btnWeekBack").addClass("button-disabled");
        registerEvents();
        setVisibleArea();
        scrollModule.createScroll('divViewWeekDetailScroll');
    }
    //endregion

    return {
        init: init,
        loadView: loadView,
        hide: hide,
        show: show
    };

}();