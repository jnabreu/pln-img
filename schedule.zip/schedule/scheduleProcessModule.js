var scheduleProcessModule = function () {

    //#region Attributes
    var intervalID = null,
        totalProcess = 0;
    //#endregion Attributes

    //#region Functions
    function getStatusProcess() {
        if (scheduleModule.isCurrentProcessTab()) {

            scheduleModule.getMainPageLoader().show();
            $.ajax({
                url: urlConfig.schedule.getProcessStatus,
                data: JSON.stringify({
                    unitID: $("#ddlUnit").val(),
                    sectionID: $("#ddlSection").val(),
                    startDate: $("#startDate").val().toMSDate(),
                    endDate: $("#endDate").val().toMSDate()
                }),
                success: function (response) {
                    if (response) {
                        // Converte o retorno em um objeto JSON
                        var result = JSON.parse(response);
                        if (result) {
                            if (result.hasSuccess) {
                                $("#processContent").empty().html(result.successResult);
                            } else {
                                $("#processContent").empty().html(result.errorResult);
                            }
                        }
                    } else {
                        // Retorna a mensagem de erro
                        dialogModule.showDialog(_globalResources.getResource().CommunicationError);
                    }

                    scheduleModule.getMainPageLoader().hide();
                    scrollModule.updateScroll('tabProcessContainer');
                }
            });
        } else {
            stopTimer();
        }
    }

    function addTotal(value) {
        if (value) {
            totalProcess = value;
        } else {
            totalProcess += 1;
        }
        updateTotal();
    }

    function subTotal(value) {
        if (value) {
            totalProcess = value;
        } else {
            totalProcess -= 1;
        }
        updateTotal();
    }

    function updateTotal() {
        if (totalProcess == 0) {
            $("#scheduleHeader").find("#processTab #lblTotal").empty();
        } else {
            $("#scheduleHeader").find("#processTab #lblTotal").text(totalProcess);
        }
    }

    function confirmExecution(processType, processCallback, answerCode) {
        answerCode = typeof answerCode !== 'undefined' ? answerCode : "";
        if (processType == "S") {
            $.ajax({
                url: urlConfig.schedule.totalProcessType,
                success: function (response) {
                    if (response) {
                        var result = JSON.parse(response);
                        if (result) {
                            dialogModule.showYesOrNoDialog(result.questionResult, function (answer, args) {
                                if (answer === true) {
                                    processCallback(processType);
                                }
                            }, [processType, answerCode]);
                        }
                    }
                }
            });
        }
        else {
            processCallback(processType);
        }
    }

    function stopTimer() {
        if (intervalID) {
            clearInterval(intervalID);
        }
        intervalID = null;
    }

    function registerTimer() {
        stopTimer();
        if (scheduleModule.isCurrentProcessTab()) {
            intervalID = setInterval(function () {
                getStatusProcess();
            }, 30000);
        }
    }
    //#endregion Actions

    //#region Init
    function init() {
        //if (totalProcess != undefined) {
        //    addTotal(totalProcess);
        //} else {
        //    totalProcess = 0;
        //    updateTotal();
        //}

        var periodHeader = $('#schedulePeriodHeader');
        totalHeight = $('.page-footer').offset().top - (periodHeader.offset().top + parseInt(periodHeader.css('height'), 10));
        $('#tabProcessContainer').css('height', totalHeight);

        scrollModule.createScroll('tabProcessContainer');
    }
    //#endregion Init

    return {
        init: init,
        stop: stopTimer,
        addTotal: addTotal,
        subTotal: subTotal,
        confirmExecution: confirmExecution,
        getStatusProcess: getStatusProcess,
        registerTimer: registerTimer
    }
}();