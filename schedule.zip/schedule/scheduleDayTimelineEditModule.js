var scheduleDayTimelineEditModule = function () {

    function ajaxRequest(url, params) {
        var deferred = $.Deferred();

        $.ajax({
            url: url,
            data: params,
            success: function (response) {
                if (response != null) {
                    deferred.resolve($.parseJSON(response));
                } else {
                    deferred.reject();
                }
            },
            error: function (error) {
                deferred.reject(error);
            }
        });

        return deferred.promise();
    }

    function validateCollaboratorTimeRequest(collaboratorID, date, alterReasonID, scheduleID, rangeValues) {
                
        var parameters = JSON.stringify({
            collaboratorID: collaboratorID,
            date: date,
            alterReasonID: alterReasonID,
            scheduleID: scheduleID,
            rangeValues: rangeValues,
        });

        return ajaxRequest(urlConfig.schedule.validateEdit, parameters);
    }

    function saveCollaboratorsTimesRequest(collaboratorsTimes) {
        var parameters = JSON.stringify({
            collaboratorsTimes: collaboratorsTimes
        });

        return ajaxRequest(urlConfig.schedule.saveCollaboratorsTimes, parameters);
    }

    function validateCollaboratorTime(dhxEvents, onSuccessCallback, onErrorCallback, onWarningCallback, params) {
        /// <summary>
        /// validates a collab events against the server
        /// </summary>
        /// <param name="dhxEvents">dhx collab events</param>
        /// <param name="onSuccessCallback">callback on succes</param>
        /// <param name="onErrorCallback">callback on error</param>
        /// <param name="params">error callback params</param>
        /// <returns type=""></returns>

        var request = processEvents(dhxEvents);
        if (!request) {
            console.debug('[validate] !request');
            $(scheduleDayTimelineModule.getValidationArea()).trigger('schedule.day.validate');
            return;
        }
        validateCollaboratorTimeRequest(request.collaboratorID, request.date, request.alterReasonID, request.scheduleID, request.rangeValues)
            .done(function (response) {
                if (response.hasSuccess) {
                    onSuccessCallback(response.successResult, params);
                } else {
                    if (response.hasInformation || response.hasQuestion) {
                        onWarningCallback(response.informationResult || response.questionResult, params);
                    }
                    else if (onErrorCallback) {
                        onErrorCallback(response.errorResult, params);
                    }
                }
            })
            .fail(function (error) {
                dialogModule.createDialog(0, _globalResources.getResource().ErrorTitle,
                    _globalResources.getResource().CommunicationError);
            });
    }

    function saveCollaboratorsTimes(collaboratorsTimes, onSuccessCallback, onErrorCallback) {
        saveCollaboratorsTimesRequest(collaboratorsTimes)
            .done(function (response) {
                var savedCollaborators = response.informationResult.savedCollaborators,
                    errorCollaborators = response.informationResult.errorCollaborators;

                params = [savedCollaborators, errorCollaborators];
                if (response.hasSuccess) {
                    onSuccessCallback(response.successResult, params);
                } else {
                    if (onErrorCallback) {
                        onErrorCallback(response.errorResult, params);
                    }
                }
            })
            .fail(function (error) {
                dialogModule.createDialog(0, _globalResources.getResource().ErrorTitle,
                    _globalResources.getResource().CommunicationError);
            });
    }

    function getDayType(event) {
        DAY_TYPES = scheduleDayTimelineModule.getDayTypesConsts();

        var res = {
            dayType: null,
            absenceType: null,
        };

        switch (event.dayType) {
            case DAY_TYPES.WORKING:
                res.dayType = 'T';
                break;
            case DAY_TYPES.MAND_REST:
                res.dayType = 'F';
                res.absenceType = '0';
                break;
            case DAY_TYPES.COMP_REST:
                res.dayType = 'F';
                res.absenceType = '1';
                break;
            case DAY_TYPES.NON_WORKING:
                res.dayType = 'N';
            default:
                // nothing;
                break;
        }
        return res;
    }

    function processEvents(dhxEvents) {
        /// <summary>
        /// transforms dhx events into an object of params needed by "validateCollaboratorTimeRequest"
        /// </summary>
        /// <param name="dhxEvents"></param>
        /// <returns type=""></returns>
        if (dhxEvents.length === 0) {
            console.debug('[validate] no dhx events');
            return;
        };

        dhxEvents = $.map(dhxEvents, function (el) {
            el.hasEdit = true;
            return el;
        });


        var rangeValues = createRanges(dhxEvents),
            firstEvent = dhxEvents[0],
            collaboratorID = firstEvent.collabID,
            startDate = firstEvent.date,
            date = moment.utc(firstEvent.date).toMSDate(),
            alterReasonID = firstEvent.changeReason || 0,
            scheduleID = firstEvent.scheduleID,
            enrollmentNumber = firstEvent.enrollmentNumber,
            collaboratorName = firstEvent.collabLabel;

        date = new Date(parseInt(date.substr(6)));
        date = new Date(+date - (date.getTimezoneOffset() * 60000));
        
        for (var key = 0; key < rangeValues.length; key++) {
            rangeValues[key].beginHourWork = new Date(parseInt(rangeValues[key].beginHourWork.substr(6)));
            rangeValues[key].beginHourWork = new Date(+rangeValues[key].beginHourWork - (rangeValues[key].beginHourWork.getTimezoneOffset() * 60000));
            rangeValues[key].beginRange = new Date(parseInt(rangeValues[key].beginRange.substr(6)));
            rangeValues[key].beginRange = new Date(+rangeValues[key].beginRange - (rangeValues[key].beginRange.getTimezoneOffset() * 60000));
            
            rangeValues[key].endHourWork = new Date(parseInt(rangeValues[key].endHourWork.substr(6)));
            rangeValues[key].endHourWork = new Date(+rangeValues[key].endHourWork - (rangeValues[key].endHourWork.getTimezoneOffset() * 60000));
            rangeValues[key].endRange = new Date(parseInt(rangeValues[key].endRange.substr(6)));
            rangeValues[key].endRange = new Date(+rangeValues[key].endRange - (rangeValues[key].endRange.getTimezoneOffset() * 60000));
        }

        return {
            collaboratorID: collaboratorID,
            date: date,
            alterReasonID: alterReasonID,
            scheduleID: scheduleID,
            enrollmentNumber: enrollmentNumber,
            collaboratorName: collaboratorName,
            rangeValues: rangeValues,
        }
    }

    function getRanges(collabEvents, isPolyvalent, functions) {
        var ranges = [];
        var mainEvents = $.grep(collabEvents, function (elem) {
            return elem.isMainRange;
        });

        if (mainEvents.length > 0) {
            var mainRange = functions.getMainRange(mainEvents);
            ranges = ranges.concat(mainRange);
        }

        var intervalEvents = $.grep(collabEvents, function (elem) {
            return elem.isInterval;
        });

        if (intervalEvents.length > 0) {
            for (var i = 0; i < intervalEvents.length; i++) {
                var intervalRange = functions.getIntervalRange(intervalEvents[i]);
                ranges = ranges.concat(intervalRange);
            }
        }

        if (isPolyvalent) {
            var polyvalentEvents = $.grep(collabEvents, function (elem) {
                return elem.isDayTimelineEvent && (elem.isPolyvalent || elem.isSectionPolyvalent);
            });
            ranges = ranges.concat(getPolyvalentsRanges(polyvalentEvents));
        }
        return ranges;
    }

    function createRanges(collabEvents) {
        /// <summary>
        /// creates ranges needed to be validated based on dhx events
        /// </summary>
        /// <param name="collabEvents"></param>
        /// <returns type=""></returns>
        var polyvalents = $.grep(collabEvents, function (el) {
            return ((el.isPolyvalent || el.isSectionPolyvalent) && !(el.absenceReasonID));
        });

        var isPolyvalent = false,
            functions = {};

        if (polyvalents.length > 0) {
            isPolyvalent = true;
            functions = {
                getMainRange: getMainRangePolyvalent,
                getIntervalRange: getIntervalRange,
            }
        } else {
            isPolyvalent = false;
            functions = {
                getMainRange: getMainRangeNoPolyvalents,
                getIntervalRange: getIntervalRange,
            };
        }
        return getRanges(collabEvents, isPolyvalent, functions)
    }

    function getMainRangeNoPolyvalents(mainEvents) {
        var dateToMS2000 = customControlsModule.dateToMS2000;
        var beforeEvent = mainEvents[0];
        var afterEvent = mainEvents[1];
        var extraEvent = mainEvents[2];
        var rootDate = beforeEvent.date;

        var endHourWork = dateToMS2000(beforeEvent.end_date, rootDate);
        if (afterEvent) {
            endHourWork = dateToMS2000(afterEvent.end_date, rootDate);
        }

        if (extraEvent) {
            endHourWork = dateToMS2000(extraEvent.end_date, rootDate);
        }
        // afterEvent ? dateToMS2000(afterEvent.end_date, rootDate) : dateToMS2000(beforeEvent.end_date, rootDate),    
        return {
            scheduleID: beforeEvent.scheduleID,
            workContractID: beforeEvent.workContractID,
            beginHourWork: dateToMS2000(beforeEvent.start_date, rootDate),
            endHourWork: endHourWork,
            beginRange: dateToMS2000(beforeEvent.rangeBegin, rootDate),
            endRange: dateToMS2000(beforeEvent.rangeEnd, rootDate),
            sectionID: beforeEvent.sectionID,
            workstationTypeID: beforeEvent.workstationTypeID || null,
            workstationTypeColor: beforeEvent.workstationTypeColor,
            workstationID: beforeEvent.workstationID || null,
            isSectionPolyvalent: beforeEvent.isSectionPolyvalent,
            isPolyvalent: beforeEvent.isPolyvalent,
            typeDay: getDayType(beforeEvent).dayType,
            absenceType: getDayType(beforeEvent).absenceType,
            isInterval: false,
            isMainRange: true,
            canEdit: false,   // TODO: verify this property
            hasDelete: false, // TODO: delete mode should change this to true
            hasEdit: beforeEvent.hasEdit || (afterEvent ? afterEvent.hasEdit : false),
            hasEditWorkstation: false, // TODO: editing workstation shoud change this to true
        };
    }

    function getMainRangePolyvalent(mainEvents) {
        // same behavior as no polyvalents main range
        return getMainRangeNoPolyvalents(mainEvents);
    }

    function getIntervalRange(intervalEvent) {
        var dateToMS2000 = customControlsModule.dateToMS2000;
        var rootDate = intervalEvent.date;
        return {
            scheduleID: 0,
            workContractID: 0,
            beginHourWork: dateToMS2000(intervalEvent.start_date, rootDate),
            endHourWork: dateToMS2000(intervalEvent.end_date, rootDate),
            beginRange: dateToMS2000(intervalEvent.rangeBegin, rootDate),
            endRange: dateToMS2000(intervalEvent.rangeEnd, rootDate),
            sectionID: 0,
            isSectionPolyvalent: intervalEvent.isSectionPolyvalent,
            isPolyvalent: intervalEvent.isPolyvalent,
            isInterval: true,
            isMainRange: false,
            intervalTypeID: intervalEvent.intervalTypeID,
            canEdit: false,   // TODO: verify this property
            hasDelete: false, // TODO: delete mode should change this to true
            hasEdit: intervalEvent.hasEdit,
            hasDelete: intervalEvent.hasDelete,
            hasEditWorkstation: false, // TODO: editing workstation shoud change this to true
        };
    }

    function getPolyvalentRange(polyvalent) {
        var dateToMS2000 = customControlsModule.dateToMS2000;
        var rootDate = polyvalent.date;
        return {
            scheduleID: 0,
            workContractID: 0,
            beginHourWork: dateToMS2000(polyvalent.start_date, rootDate),
            endHourWork: dateToMS2000(polyvalent.end_date, rootDate),
            beginRange: dateToMS2000(polyvalent.rangeBegin, rootDate),
            endRange: dateToMS2000(polyvalent.rangeEnd, rootDate),
            sectionID: polyvalent.sectionID,
            workstationTypeID: polyvalent.workstationTypeID || null,
            workstationTypeColor: polyvalent.workstationTypeColor,
            workstationID: polyvalent.workstationID || null,
            isSectionPolyvalent: polyvalent.isSectionPolyvalent,
            isPolyvalent: polyvalent.isPolyvalent,
            isInterval: false,
            isMainRange: false,
            canEdit: false,   // TODO: verify this property
            hasDelete: false, // TODO: delete mode should change this to true
            hasEdit: polyvalent.hasEdit,
            hasDelete: polyvalent.hasDelete,
            hasEditWorkstation: false, // TODO: editing workstation shoud change this to true 
        }
    }

    function getPolyvalentsRanges(polyvalentEvents) {
        var ranges = [];
        $.each(polyvalentEvents, function (index, ev) {
            ranges.push(getPolyvalentRange(ev));
        })
        return ranges;
    }

    return {
        validateCollaboratorTime: validateCollaboratorTime,
        saveCollaboratorsTimes: saveCollaboratorsTimes,
        processEvents: processEvents,
        createRanges: createRanges,
    };

}();;
