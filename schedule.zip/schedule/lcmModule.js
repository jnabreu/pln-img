var lcmModule = function () {

    var defaultLCMSchedule = null;

    var TYPES = {
        GRID: 'grid',
        CHART_COLLAB: 'chartCollab',
        CHART_COLLAB_TABLE: 'chartCollabTable',
        ABSENCE: 'absence',
    };

    function getTypes() {
        return TYPES;
    }

    function setDefaultLCMSchedule(lcm) {
        defaultLCMSchedule = lcm;
    }

    // regista evento MMC quando é apresentado num pane/grid
    function registerCheckLCMPaneEvent(paneContext) {
        var checks = $('#' + paneContext + ' input[type=checkbox]');
        if (checks.length > 0) {
            checks.on('ifChecked ifUnchecked', { context: paneContext }, updateLCMPane);
        }
    }

    // regista o evento MMC quando é apresentado no ecrã principal de escalas
    function registerCheckLCMScheduleEvent(elemId, type) {
        var checks = $('#' + elemId + ' input[type=checkbox]');
        if (checks.length > 0) {
            checks.on('change',
            {
                elemId: elemId,
                type: type,
            },
            updateLCMSchedule);
        }
    }

    function rCalcLCM(adaptList) {
        if (adaptList.length <= 1) {
            return adaptList[0];
        }
        return calcLCM(adaptList[0], rCalcLCM(adaptList.slice(1)));
    }

    function calcLCM(num1, num2) {
        return Math.abs(num1 * num2) / calcGCD(num1, num2);
    }

    function calcGCD(num1, num2) {
        if (num2 === 0) {
            return num1;
        }
        return calcGCD(num2, num1 % num2)
    }

    function getGridSelectors(paneContext, columnN) {
        return {
            checked: '#' + paneContext + ' #inputItem:checked',
            adapt: function(checkContext) {
              return $(checkContext).closest('.divContentRow').children('.divContentRowCell:nth-child(' + columnN + ')').text()
            },
        }
    }

    function getChartCollaboratorSelectors(elemId) {
        return {
            checked: '#' + elemId + ' input[type="checkbox"]:checked',
            adapt: function(checkContext) {
                return $(checkContext).parents('.boxInfo').find('.collaboratorAdapt').text()
            },
        }
    }

    function getChartCollaboratorTableViewSelectors(elemId) {
        return {
            checked: '#' + elemId + ' input[type=checkbox]:checked',
            adapt: function (checkContext) {
                return $(checkContext).parents('.line-collaborator').find('.collaboratorAdapt').text()
            },
        }
    }

    function getAbsenceSelectors(elemId) {
        return {
            checked: '#' + elemId + ' input[type=checkbox]:checked',
            adapt: function(checkContext) {
                return $(checkContext).parents('.employee').find('.collaboratorAdapt').text()
            },
        }
    }

    function getSelectedAdaptItems(selectors) {
        var list = [];
        var checked = selectors.checked;
        $(checked).each(function (elem) {
            list.push(selectors.adapt(this));
        });
        return list;
    }

    function getSelectors(type, args) {
        if (type === TYPES.GRID)
            return getGridSelectors(args.paneContext, args.columnN);
        else if (type === TYPES.CHART_COLLAB)
            return getChartCollaboratorSelectors(args.elemId);
        else if (type === TYPES.CHART_COLLAB_TABLE)
            return getChartCollaboratorTableViewSelectors(args.elemId);
        else if (type === TYPES.ABSENCE)
            return getAbsenceSelectors(args.elemId);
        else
            return null;
    }

    function filterUniqueAdapts(selectedItems) {
        var uniqueAdapts = [];
        $.each(selectedItems, function (i, el) {
            var parsedVal = parseInt(el, 10);
            if (!isNaN(parsedVal)) {
                if (parsedVal === 0) return;
                if ($.inArray(parsedVal, uniqueAdapts) === -1) {
                    uniqueAdapts.push(parsedVal);
                }
            }
        });
        return uniqueAdapts;
    }

    function getUpdatedLCM(selectors) {
        var selectedItems = getSelectedAdaptItems(selectors);
        var uniqueAdapts = filterUniqueAdapts(selectedItems);
        return rCalcLCM(uniqueAdapts);
    }

    function applyLCMValSchedule(lcmDivContainerSchedule, lcmContainerSchedule, lcmValSchedule, adaptVal) {
        var lcmDivContainerSchedule = $('#' + lcmDivContainerSchedule);
        
        lcmDivContainerSchedule.show();
        lcmDivContainerSchedule.find('#' + lcmContainerSchedule).remove();
        lcmDivContainerSchedule.append('<span id="' + lcmContainerSchedule + '" class="'
            + lcmContainerSchedule + '"> (<span id="' + lcmValSchedule + '" />)</span>');

        $('#' + lcmValSchedule).text(adaptVal);
    }

    function updateLCMSchedule(e) {
        var lcmValSchedule = 'lcmValSchedule';
        var lcmContainerSchedule = 'lcmContainerSchedule';
        var lcmDivContainerSchedule = 'lcmDivContainerSchedule';

        var selectors = getSelectors(e.data.type, { elemId: e.data.elemId });        
        var resultLCM = getUpdatedLCM(selectors);
        var adaptVal = defaultLCMSchedule;

        if (typeof resultLCM === 'number') {
            adaptVal = resultLCM;
        }

        applyLCMValSchedule(lcmDivContainerSchedule, lcmContainerSchedule, lcmValSchedule, adaptVal);
    }

    function updateLCMPane(e) {
        var lcmValPane = 'lcmValPane';
        var lcmContainerPane = 'lcmContainerPane';
        var lcmContainer = $('#' + e.data.context + ' .calculatedHeader');

        var columnN = lcmContainer.parent().index() + 1;
        var selectors = getSelectors(TYPES.GRID, { paneContext: e.data.context, columnN: columnN })

        var resultLCM = getUpdatedLCM(selectors);

        lcmContainer.find('#' + lcmContainerPane).remove();
        if (typeof resultLCM === 'number') {
            lcmContainer.append('<span id="' + lcmContainerPane + '"> (<span id="' + lcmValPane + '" />)</span>');
            $('#' + lcmValPane).text(resultLCM);
        }
    }

    return {
        registerCheckLCMPaneEvent: registerCheckLCMPaneEvent,
        registerCheckLCMScheduleEvent: registerCheckLCMScheduleEvent,
        applyLCMValSchedule: applyLCMValSchedule,    
        getTypes: getTypes,
        setDefaultLCMSchedule: setDefaultLCMSchedule,
    };
}();