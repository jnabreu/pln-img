var scheduleDayTimelineLightboxModule = function () {
    var TRIGGERS = {
        CHANGE_REASONS_UPDATED: 'schedule.dayView.lightbox.changeReasonsUpdated',
    };

    var TIME_STEP = 15;

    var BEGIN = 'begin',
        END = 'end';

    var SHOW = 'show',
        HIDE = 'hide';

    var SECTIONS = {
        TITLE: 'title',
        PERIOD1: 'period1',
        PERIOD2: 'period2',
        PERIOD3: 'period3',
        ACTIONS: 'actions',
        CHANGE_REASONS: 'changeReasons',
    };

    var DAY_TYPES = {
        WORKING: 'W',
        COMP_REST: 'CREST',
        MAND_REST: 'MREST',
        ABSENCE: 'A',
        NON_WORKING: 'N',
        HOLIDAY: 'H',
    };

    var ACTIONS = {
        ADJUSTMENT: 1,
        COMP_REST: 2,
        MAND_REST: 3,
        NON_WORKING: 4,
    };

    var _periods = [1, 3, 5];

    var _customPeriodsValues = {};

    var _changeReasons = null,
        _eventSpecificDataFns = null,
        _numberOfTimeFields = 1,
        _onEventSaveData = null;

    function getDefaultReason() {
        return {
            key: 0,
            label: _globalResources.getResource().schedule.dayView.lightbox.changeReasons.DefaultReason
        };
    }

    function getDefaultTimeFormat() {
        return ['%H:%i', '%m', '%d', '%Y'];
    }

    function getTitle() {

        return '<b><p class="custom-lightbox lightbox-title">' +
                _globalResources.getResource().schedule.dayView.lightbox.SaveCollaboratorAbsence +
                '</p></b><br>';
    }

    // TODO: refactor to return a Promise
    function getChangeReasons() {
        $.ajax({
            url: urlConfig.schedule.getChangeReasons,
            async: false,
            data: null,
            success: function (response) {
                if (response) {
                    var result = JSON.parse(response);
                    if (result) {
                        setChangeReasonOptions(result);
                    }
                } else {
                    console.log("Error: getChangeReasons with no Result");
                    return false;
                }
            }
        });
    }

    function getLightboxValues() {
        var values = {};

        values[SECTIONS.ACTIONS] = scheduler.formSection(SECTIONS.ACTIONS).getValue(),
        values[SECTIONS.CHANGE_REASONS] = scheduler.formSection(SECTIONS.CHANGE_REASONS).getValue();

        return values;
    }

    function getActionsOptions() {
        return [
            { key: ACTIONS.ADJUSTMENT, label: _globalResources.getResource().schedule.dayView.lightbox.actions.Adjust },
            { key: ACTIONS.COMP_REST, label: _globalResources.getResource().schedule.dayView.lightbox.actions.CompRest },
            { key: ACTIONS.MAND_REST, label: _globalResources.getResource().schedule.dayView.lightbox.actions.MandRest },
        ];
    }

    function setLightboxSections() {
        scheduler.config.lightbox.sections = [
          { name: SECTIONS.TITLE, height: 36, type: 'template', map_to: 'auto', default_value: getTitle() },
          { name: SECTIONS.PERIOD1, type: 'customTimePeriod', map_to: 'auto', time_format: getDefaultTimeFormat() },
          { name: SECTIONS.PERIOD2, type: 'customTimePeriod', map_to: 'auto', time_format: getDefaultTimeFormat() },
          { name: SECTIONS.PERIOD3, type: 'customTimePeriod', map_to: 'auto', time_format: getDefaultTimeFormat() },
          { name: SECTIONS.ACTIONS, map_to: 'auto', type: 'select', options: getActionsOptions(), onchange: onLightboxSelectChange },
          { name: SECTIONS.CHANGE_REASONS, map_to: 'auto', type: 'select', options: [{ key: 0, label: '' }] },
        ];
    }

    // DEPRECATED
    function getRange(limit) {
        var res = null;
        var rndEvent = scheduler.getEvents()[0];
        if (limit === BEGIN) {
            res = rndEvent.rangeBegin.getHours();
        } else if (limit === END) {
            res = rndEvent.rangeEnd.getHours();
            if (rndEvent.rangeEnd.getMinutes() !== 0) {
                res += 1;
            }
        } else {
            console.debug('not a valid limit: ', limit);
        }
        return res;
    }

    function validatePeriod(period, name, required, prevPeriod, prevNotNull) {
        var res = {
            isSuccess: true,
            messages: [],
        };

        if (!required && !period.minutesStart && !period.minutesEnd) {
            return res;
        }

        if (!period.minutesStart || !period.minutesEnd) {
            res.messages.push(name + ': ' + _globalResources.getResource().schedule.dayView.lightbox.messages.DatesRequired);
            res.isSuccess = false;
        } else {
            if (prevNotNull && (!prevPeriod.minutesStart && !prevPeriod.minutesEnd)) {
                res.messages.push(_globalResources.getResource().schedule.dayView.lightbox.messages.PreviousPeriodRequired);
                res.isSuccess = false;
            }

            if (parseInt(period.minutesEnd) <= parseInt(period.minutesStart)) {
                res.messages.push(name + ': ' + _globalResources.getResource().schedule.dayView.lightbox.messages.BeginDateGreaterThanEnd);
                res.isSuccess = false;
            }
            if (prevPeriod.minutesEnd) {
                if (parseInt(period.minutesStart) <= parseInt(prevPeriod.minutesEnd)) {
                    res.messages.push(_globalResources.getResource().schedule.dayView.lightbox.messages.BeginDatePeriodGreaterThanEndPeriod(name, prevPeriod.name));
                    res.isSuccess = false;
                }
            }
        }


        return res;
    }

    function validatePeriods() {
        var res = {
            isSuccess: true,
            messages: [],
        };

        var prevPeriod = {
            minutesStart: null,
            minutesEnd: null,
            name: null,
        };

        for (var i = 0; i < _periods.length; i++) {
            var key = _periods[i];
            if (!_customPeriodsValues.hasOwnProperty(key)) {
                continue;
            }
            var currPeriod = _customPeriodsValues[key],
                periodName = '<b>Período ' + (i + 1) + '</b>',
                required = key == 1 ? true : false,
                prevNotNull = key == 1 ? false : true;

            var periodValidations = validatePeriod(currPeriod, periodName, key == 1 ? true : false, prevPeriod, prevNotNull);

            prevPeriod = {
                minutesStart: _customPeriodsValues[key].minutesStart,
                minutesEnd: _customPeriodsValues[key].minutesEnd,
                name: periodName,
            };

            res.isSuccess = periodValidations.isSuccess == false ? false : res.isSuccess;
            res.messages = res.messages.concat(periodValidations.messages);
        }

        return res;
    }

    function validateLightboxFields() {
        var res = {
            isSuccess: true,
            messages: [],
        };

        var selectedAction = scheduler.formSection(SECTIONS.ACTIONS).getValue(),
            selectedChangeReason = scheduler.formSection(SECTIONS.CHANGE_REASONS).getValue();

        var isValidatePeriods = false;
        if (parseInt(selectedAction) === ACTIONS.ADJUSTMENT) {
            isValidatePeriods = true;
        }

        if (isValidatePeriods) {
            res = validatePeriods();
        }

        // Change reason validation
        //if (selectedChangeReason <= 0) {
        //    res.isSuccess = false;
        //    res.messages.push(_globalResources.getResource().schedule.dayView.lightbox.messages.ChangeReasonRequired);
        //}

        return res;
    }

    function setChangeReasonOptions(result) {
        var options = [];

        options.push(getDefaultReason());
        $.each(result, function (index, value) {
            options.push({
                key: value.ID,
                label: value.Name,
            });
        });

        _changeReasons = options;
        $('#dayDataContent').trigger(TRIGGERS.CHANGE_REASONS_UPDATED, { options: options });
    }

    function updateChangeReasonOptions(ev, data) {
        var options = data.options;

        try {
            scheduler.formSection(SECTIONS.CHANGE_REASONS).section.options = options;
            scheduler.resetLightbox();
        } catch (ex) {
            // do nothing
        }
    }

    function lightboxHeaderTemplate(start, end, event) {
        var collabLabel = event.collabLabel ? ("<b>" + (event.enrollmentNumber ? event.enrollmentNumber + " - " : "") + event.collabLabel + "</b>") : "";
        return collabLabel;
    }

    function setLabels() {
        var labels = scheduler.locale.labels;
        labels['section_' + SECTIONS.TITLE] = '';
        labels['section_' + SECTIONS.PERIOD1] = _globalResources.getResource().schedule.dayView.lightbox.TimeLabel + ' 1';
        labels['section_' + SECTIONS.PERIOD2] = _globalResources.getResource().schedule.dayView.lightbox.TimeLabel + ' 2';
        labels['section_' + SECTIONS.PERIOD3] = _globalResources.getResource().schedule.dayView.lightbox.TimeLabel + ' 3';
        labels['section_' + SECTIONS.ACTIONS] = _globalResources.getResource().schedule.dayView.lightbox.ActionLabel;
        labels['section_' + SECTIONS.CHANGE_REASONS] = _globalResources.getResource().schedule.dayView.lightbox.ChangeReasonLabel;
    }

    function changeDayType(from, to, event, data) {
        switch (parseInt(to)) {
            case ACTIONS.ADJUSTMENT:
                handleWorkingDay(from, event, data);
                break;
            case ACTIONS.COMP_REST:
                handleCompRest(from, event, data);
                break;
            case ACTIONS.MAND_REST:
                handleMandRest(from, event, data);
                break;
            case ACTIONS.NON_WORKING:
                handleNonWorkingDay(from, event, data);
                break;
            default:
                return false;
        }
    }

    // adapted dhtmlx source code in order to fullfill custom timeline scheduler/lightbox
    function getCustomTimePeriod() {
        function getTargetSeqNumber(node) {
            var targetSeqNumber = 1;
            var id = $(node).prev().attr('id');

            switch (id) {
                case scheduler.formSection(SECTIONS.PERIOD1).section.id:
                    targetSeqNumber = 1;
                    break;
                case scheduler.formSection(SECTIONS.PERIOD2).section.id:
                    targetSeqNumber = 3;
                    break;
                case scheduler.formSection(SECTIONS.PERIOD3).section.id:
                    targetSeqNumber = 5;
                    break;
                default:
                    console.debug('error getting "targetSeqNumber"');
                    return false;
            }
            return targetSeqNumber;
        }

        function render(sns) {
            sns.time_format = ['%H:%i'];
            // map: default order => real one
            sns._time_format_order = {};
            var time_format = sns.time_format;

            var cfg = scheduler.config;
            var dt = this.date.date_part(scheduler._currentDate());

            var first = 0,
                last = 24;

            if (cfg.customRangeBegin && cfg.customRangeEnd) {
                first = +cfg.customRangeBegin,
                last = +cfg.customRangeEnd;
            } else {
                console.debug('no custom range begin or custom range end configured');
            }

            var step = cfg.time_step * 60 * 1000;

            if (scheduler.config.limit_time_select) {
                dt.setHours(cfg.first_hour);
            }
            var html = "";

            for (var p = 0; p < time_format.length; p++) {
                var time_option = time_format[p];

                // adding spaces between selects
                if (p > 0) {
                    html += " ";
                }

                sns._time_format_order[0] = p;
                //hours
                html += "<select>";
                var i = first;
                var tdate = dt.getDate();
                sns._time_values = [];

                // added empty value
                html += "<option value=''> </option>";

                for (var i = first; i <= last; i += step) {
                    var time = new Date(i);
                    var timeText = this.templates.time_picker(time) + ' - ' + this.templates.day_date(time);
                    html += "<option value='" + i + "'>" + timeText + "</option>";
                    sns._time_values.push(i);
                }

                html += "</select>";
                break;

            }

            return "<div style='height:30px;padding-top:0px;font-size:inherit;' class='dhx_section_time'>"
                + html
                + "<span style='font-weight:normal; font-size:10pt;'> &nbsp;&ndash;&nbsp; </span>"
                + html
                + "</div>";
        }

        function set_value(node, value, ev, config) {
            var cfg = scheduler.config;
            var s = node.getElementsByTagName("select");
            var map = config._time_format_order;
            var start_date, end_date;

            var targetSeqNumber = getTargetSeqNumber(node);
            var events = scheduleDayTimelineModule.getCollabEvents(scheduler.getEvents(), ev);

            var targetEventArray = $.grep(events, function (ev) {
                return ev.seqNumber === targetSeqNumber &&
                       ev.dayType === DAY_TYPES.WORKING;
            });

            var selectStartDate,
                selectEndDate;

            if (targetEventArray.length > 0) {
                ev = targetEventArray[0];
                selectStartDate = ev.start_date;
                selectEndDate = ev.end_date;
            } else {
                console.debug('the event being targeted does not exist. seqNumber: ', targetSeqNumber);
                selectStartDate = "";
                selectEndDate = "";
            }

            function _fill_lightbox_select(s, i, d) {
                if (!d) {
                    s[i + map[0]].selectedIndex = -1
                } else {
                    var time_values = config._time_values;
                    // var direct_value = d.getHours() * 60 + d.getMinutes();
                    var direct_value = d.getTime();
                    var fixed_value = direct_value;
                    var value_found = false;
                    for (var k = 0; k < time_values.length; k++) {
                        var t_v = time_values[k];
                        if (t_v === direct_value) {
                            value_found = true;
                            break;
                        }
                        if (t_v < direct_value)
                            fixed_value = t_v;
                    }

                    s[i + map[0]].value = (value_found) ? direct_value : fixed_value;
                    if (!(value_found || fixed_value)) {
                        s[i + map[0]].selectedIndex = -1;//show empty select in FF
                    }
                }

            }

            _fill_lightbox_select(s, 0, selectStartDate);
            // set 2nd parameter to 1
            // FIX to the case where there is only begin hour and end hour
            _fill_lightbox_select(s, _numberOfTimeFields, selectEndDate);
        }

        function get_value(node, ev, config) {
            var s = node.getElementsByTagName("select");
            var map = config._time_format_order;

            // ev.start_date = new Date(s[map[3]].value, s[map[2]].value, s[map[1]].value, 0, s[map[0]].value);
            // ev.end_date = new Date(s[map[3] + _numberOfTimeFields].value, s[map[2] + _numberOfTimeFields].value, s[map[1] + _numberOfTimeFields].value, 0, s[map[0] + _numberOfTimeFields].value);

            var targetSeqNumber = getTargetSeqNumber(node);

            _customPeriodsValues[targetSeqNumber] = {
                minutesStart: parseInt(s[map[0]].value),
                minutesEnd: parseInt(s[map[0] + _numberOfTimeFields].value),
            };

            if (ev.end_date <= ev.start_date)
                ev.end_date = scheduler.date.add(ev.start_date, scheduler.config.time_step, "minute");

            // returns an empty object so dhtmlx does not override the original event object
            return {};
        }

        function focus(node) {
            scheduler._focus(node.getElementsByTagName("select")[0]);
        }

        return {
            render: render,
            set_value: set_value,
            get_value: get_value,
            focus: focus,
        }
    }

    function onBeforeLightboxCallback(id) {
        _onEventSaveData = {
            saved: false,
            id: null,
            event: null,
        };

        _customPeriodsValues = {};
        if (!scheduler.getEvent(id).hasOwnProperty('isVisible')) {
            dhtmlx.alert('error: on before');
            return false;
        }

        var event = scheduler.getEvent(id);
        scheduler.config.customRangeBegin = event.rangeBegin
        scheduler.config.customRangeEnd = event.rangeEnd;

        updateChangeReasonOptions(null, { options: _changeReasons }); // force change reasons to be updated

        scheduler.resetLightbox();

        return true;
    }

    function onAfterLightboxCallback() {
        // validates updated event
        if (_onEventSaveData.saved) {
            scheduleDayTimelineModule.validateEvent(_onEventSaveData.event);
            scheduleDayTimelineModule.setFilteredEvents(scheduler.getState().date, true, null, true);
            scheduleDayTimelineModule.sortCollaborators(scheduler.getState().date);
        }

        // reset all Lightbox data
        scheduler.resetLightbox();
    }

    function onEventSaveCallback(id, ev, isNew) {
        var event = scheduler.getEvent(id);

        var actionKey = scheduler.formSection(SECTIONS.ACTIONS).getValue(),
            changeReason = scheduler.formSection(SECTIONS.CHANGE_REASONS).getValue();

        var validations = validateLightboxFields();
        if (!validations.isSuccess) {
            var message = buildHtmlErrorMessage(validations.messages);
            dhtmlx.alert({
                title: _globalResources.getResource().schedule.dayView.lightbox.Error,
                type: 'alert-error-custom',
                text: message,
            });

            return false;
        }

        _onEventSaveData = {
            saved: true,
            id: id,
            event: event,
        };

        var data = {
            id: id,
            event: event,
            isNew: isNew,
            changeReason: changeReason,
        };

        changeDayType(event.dayType, actionKey, ev, data);

        var absenceWorkstation = scheduleDayTimelineModule.getAbsenceWorkstation(event, event.section_id, false);
        var eventsData = scheduleDayTimelineModule.getEventsData(_onEventSaveData.event, _onEventSaveData.event.section_id);
        if ((absenceWorkstation.length > 0) && (typeof eventsData[2] != "undefined")) {
            var periods = scheduleDayTimelineModule.getProperties()._lightboxPeriodReturn;
            if (typeof periods[3] != "undefined") {
                if (!(isNaN(periods[3].minutesEnd))) {
                    var endDT = new Date(periods[3].minutesEnd);
                        eventsData[2].event.end_date = endDT;
                        scheduler.updateEvent(eventsData[2].event.id);
                }
                scheduleDayTimelineModule.changeAbsenceWorkstation(_onEventSaveData.event, true);
            }
        }
        return true;
    }

    function buildHtmlErrorMessage(messages) {
        var message = '<ul>';

        for (var i = 0; i < messages.length; i++) {
            message += '<li>- ' + messages[i] + '</li>';
        }
        message += '</ul>'

        return message;
    }

    function showOrHideSection(name, mode) {
        var section = $('#' + scheduler.formSection(name).section.id).parent();
        if (mode === SHOW) {
            section.show();
        } else if (mode === HIDE) {
            section.hide();
        } else {
            console.debug('invalid mode: ', mode);
        }
    }

    function showOrHidePeriodSections(mode) {
        showOrHideSection(SECTIONS.PERIOD1, mode);
        showOrHideSection(SECTIONS.PERIOD2, mode);
        showOrHideSection(SECTIONS.PERIOD3, mode);
    }

    function onLightboxSelectChange(ev) {
        var action = scheduler.formSection(SECTIONS.ACTIONS).getValue();
        if (action == ACTIONS.ADJUSTMENT) {
            showOrHidePeriodSections(SHOW);
        } else {
            showOrHidePeriodSections(HIDE);
        }
        scheduler.setLightboxSize();
    }

    function changeToWorkDay(event) {
        //TODO: change this to get data from scheduleEventsModule
        var eventProps = {
            color: 'rgb(20, 161, 156)',
            dayType: DAY_TYPES.WORKING,
            type: 'T_T T',
            isFullDayType: false,
            text: "Work"
        }
        mergeObjects(eventProps, event);
    }

    function handleWorkingDay(from, event, data) {
        var workData = _eventSpecificDataFns.getWorkData(null, data.event.start_date, data.event.end_date);

        var collabEvents = scheduleDayTimelineModule.getCollabEvents(scheduler.getEvents(), data.event);
        var evs = $.grep(collabEvents, function (ev) {
            return ev.seqNumber === 1 || ev.seqNumber === 0; // if is first event or is rest/non working
        })

        var ev = evs.length > 0 ? evs[0] : null;
        if (!ev) return;

        ev.seqNumber = 1; // ev can be rest or non working. seqNumber must be forced to be 1
        ev.changeReason = parseInt(data.changeReason) || 0; // event itself must save the alter reasons for future use when saving events

        var ev1 = ev;
        var seqNumber = 1;
        scheduleDayTimelineModule.setProperties(ev1, _customPeriodsValues);
        // event start and end date must be updated on 'event' because the 'event' object is going to be used by dhtmlx
        event.start_date = ev1.start_date = new Date(_customPeriodsValues[seqNumber].minutesStart);
        event.end_date = ev1.end_date = new Date(_customPeriodsValues[seqNumber].minutesEnd);

        // update ev1 to be a work day type if it isn't already
        if (from !== ACTIONS.ADJUSTMENT) {
            changeToWorkDay(ev1);
        }

        // set currennt lightbox to event 1
        scheduler._lightbox_id = ev1.id;

        scheduleDayTimelineModule.deleteOtherEvents(ev1, 1, false); // do not delete polyvalents

        var prev = ev1;
        for (var key in _customPeriodsValues) {
            var periods = _customPeriodsValues[key];
            var seqNumber = parseInt(key);
            if (!periods.minutesStart || !periods.minutesEnd || seqNumber === 1) {
                continue;
            }

            var interval = scheduleDayTimelineModule.createIntervalEvent(ev1);
            interval.seqNumber = seqNumber - 1;

            if (interval.isInterval) {
                interval.intervalTypeID = 'N';
            }

            var period = scheduleDayTimelineModule.initEvent(ev1);
            period.seqNumber = seqNumber;

            period.start_date = new Date(_customPeriodsValues[seqNumber].minutesStart);
            period.end_date = new Date(_customPeriodsValues[seqNumber].minutesEnd);

            var intervalStartDate = prev.end_date,
                intervalEndDate = period.start_date;

            scheduler.addEvent(intervalStartDate, intervalEndDate, interval.text, null, interval);
            scheduler.addEvent(period.start_date, period.end_date, period.text, null, period);

            prev = period;
        }
    }

    function handleCompRest(from, event, data) {
        var compRestProps = _eventSpecificDataFns.getRestFCData();
        //TODO: change this to get data from scheduleEventsModule
        var eventProps = {
            color: 'orange',
            dayType: DAY_TYPES.COMP_REST,
            type: 'F_1 FC light',
        };
        mergeObjects(compRestProps, event);
        auxHandleNonWorkingTypeDays(DAY_TYPES.COMP_REST, from, event, data, eventProps);
    }

    function handleMandRest(from, event, data) {
        var mandRestData = _eventSpecificDataFns.getRestFOData();
        //TODO: change this to get data from scheduleEventsModule
        var eventProps = {
            color: 'rgb(255, 116, 0)',
            dayType: DAY_TYPES.MAND_REST,
            type: 'FO light',
        };
        mergeObjects(mandRestData, event);
        auxHandleNonWorkingTypeDays(DAY_TYPES.MAND_REST, from, event, data, eventProps);
    }

    function handleNonWorkingDay(from, event, data) {
        var nonWorkingData = _eventSpecificDataFns.getNonWorkingData();
        //TODO: change this to get data from scheduleEventsModule
        var eventProps = {
            color: 'rgb(187, 210, 149)',
            dayType: DAY_TYPES.NON_WORKING,
            type: 'N_N V light',
        }
        mergeObjects(nonWorkingData, event);
        auxHandleNonWorkingTypeDays(DAY_TYPES.NON_WORKING, from, event, data, eventProps);
    }

    function auxHandleNonWorkingTypeDays(type, from, event, data, eventProps) {
        if (from === DAY_TYPES.WORKING) {
            var ev1 = scheduleDayTimelineModule.deleteOtherEvents(data.event, 1, true); // do delete polyvalents
            if (!ev1) return;
            scheduler._lightbox_id = ev1.id;
        }

        mergeObjects(eventProps, event);

        event.isFullDayType = true;
        event.changeReason = data.changeReason;
        event.start_date = data.event.rangeBegin;
        event.end_date = data.event.rangeEnd;
    }

    // TODO: change to other file
    function mergeObjects(obj1, obj2) {
        for (var key in obj1) {
            obj2[key] = obj1[key];
        }
        return obj2;
    }

    function initLightbox() {
        setLightboxSections();
        _eventSpecificDataFns = scheduleMonthTimelineModule.getEventSpecificDataFunctions();

        $('#dayDataContent')
            .off(TRIGGERS.CHANGE_REASONS_UPDATED)
            .on(TRIGGERS.CHANGE_REASONS_UPDATED, updateChangeReasonOptions);

        getChangeReasons();

        setLabels(); //TODO: change this to dhtmlx resources
        scheduler.config.buttons_right = [];
        scheduler.config.limit_time_select = true;
        //scheduler.config.time_step = TIME_STEP;
        scheduler.config.auto_end_date = true;
        scheduler.templates.lightbox_header = lightboxHeaderTemplate;
        scheduler.form_blocks['customTimePeriod'] = getCustomTimePeriod();
    }

    return {
        initLightbox: initLightbox,
        onBeforeLightboxCallback: onBeforeLightboxCallback,
        onEventSaveCallback: onEventSaveCallback,
        onAfterLightboxCallback: onAfterLightboxCallback,
    };

}();
