var scheduleDayChartModule = function () {
    
    var _chartElem = null;

    function init(elem) {
        //#region chartConfigs
        var chartConfigs = {
            chart: {
                //zoomType: 'xy',
                // renderTo: 'container',
                animation: false
            },
            credits: {
                enabled: false
            },
            //exporting: {
            //    enabled: true
            //},
            title: {
                text: ''
            },
            tooltip: {
                shared: false
            },
            plotOptions: {
                spline: {
                    marker: {
                        radius: 4,
                        lineColor: '#666666',
                        lineWidth: 1
                    }
                },
                series: {
                    animation: false,
                },
            },
            xAxis: {
                categories: [],
                opposite: false,
                labels: {
                    rotation: -90,
                    y: 25,
                    x: 4,
                    zIndex: 6
                },
                padding: 7,
            },
            yAxis: {
                opposite: true,
                title: '',
                allowDecimals: false,
                stackLabels: {
                    verticalAlign: null
                },
                labels: {
                    zIndex: 6
                }
            },
            tooltip: {
                formatter: function () {
                    return '<b>' + this.series.name + '</b><br/>' +
                    this.x + ': ' + '<b>' + this.y + '</b>';
                }
            },
            legend: {
                layout: 'horizontal',
                backgroundColor: 'white',
                floating: false,
                draggable: false,
                zIndex: 900,
                y: 5,
                height: 24
            },
            series: [
                {
                    type: 'column',
                    name: _globalResources.getResource().schedule.chart.Ideal,
                    data: [],
                    color: '#6FC984'
                },
                {
                    type: 'spline',
                    name: _globalResources.getResource().schedule.chart.Allocated,
                    data: [],
                    color: '#FF0000',
                    marker: {
                        symbol: 'square',
                        radius: 3,
                        lineWidth: 2,
                        lineColor: '#FF0000',
                        fillColor: 'white'
                    },
                    dataLabels: {
                        enabled: true,
                        style: { color: 'gray' },
                    }
                },
                {
                    type: 'spline',
                    name: _globalResources.getResource().schedule.chart.Calculated,
                    data: [],
                    color: '#909992',
                    marker: {
                        symbol: 'diamond',
                        radius: 3,
                        lineWidth: 2,
                        lineColor: '#909992',
                        fillColor: 'white'
                    }
                },
                {
                    type: 'spline',
                    name: _globalResources.getResource().schedule.chart.Performed,
                    data: [],
                    color: '#003DCC',
                    marker: {
                        symbol: 'circle',
                        radius: 3,
                        lineWidth: 2,
                        lineColor: '#003DCC',
                        fillColor: 'white'
                    }
                }
            ]
        };
        //#endregion

        var html = '<a class="button-save-single bt" href="#" id="saveCollaboratorsButton"></a>'; //TODO: change where html comes from

        _chartElem = elem;
        if (!_chartElem) return;
        _chartElem.highcharts(chartConfigs, renderButtonsClosure(html));

        registerEvents();
    }

    function registerEvents() {
        $('#dayChart')
            .off('schedule.day.updateChartSize')
            .on('schedule.day.updateChartSize', updateButtonsPosition);

        $('#dayChart #saveCollaboratorsButton')
            .off('click')
            .on('click', saveCollaborators);

        $('#dayDataContent #day_layout_container')
            .off('schedule.chart.updateAllocated')
            .on('schedule.chart.updateAllocated', updateAllocatedWrapper);
    }

    function saveCollaborators() {
        $('#dayDataContent')
            .trigger('schedule.day.saveCollaborators');
    }

    function getNewButtonsPos(chartWidth, chartHeight) {
        return {
            left: chartWidth - 70,
            top: chartHeight - 40,
        };
    }

    function updateButtonsPosition(ev, payload) {
        var chartWidth = payload.chartWidth,
            chartHeight = payload.chartHeight;
        var pos = getNewButtonsPos(chartWidth, chartHeight);

        $('#saveCollaboratorsButton').parent().parent().css({
            top: pos.top,
            left: pos.left,
        });
    }

    function renderButtonsClosure(html, css) {
        return function (chart) {
            var pos = getNewButtonsPos(chart.chartWidth, chart.chartHeight);
            chart.renderer.label(html, pos.left, pos.top, 'rect', 0, 0, true).add();
        }    
    }

    function updateChart(elem, data, isFirstTime) {

        if (isFirstTime) {
            init(elem);
        }
        
        if (!_chartElem) return;
        var chart = _chartElem.highcharts();
        chart.xAxis[0].setCategories(data.hours, false);
        chart.series[0].setData(data.ideal, false);
        chart.series[1].setData(data.allocated, false);
        chart.series[2].setData(data.calculated, false);
        chart.series[3].setData(data.performed, false);
        chart.redraw();
    }

    function updateAllocated(allocated) {
        if (!_chartElem) return;
        
        var chart = _chartElem.highcharts();
        // chart.series[1].setData(allocated, true, {}, false);
        // chart.series[1].setData(allocated);
        chart.series[1].update({
            data: allocated
        });
    }

    function updateAllocatedV2(allocated) {
        if (!_chartElem) return;

        var chart = _chartElem.highcharts();
        var N = allocated.length;
        setTimeout(function () {
            for (var i = 0; i < N - 1; i++) {
                chart.series[1].data[i].update(allocated[i], false);
            }
            chart.series[1].data[N - 1].update(allocated[N - 1], true);
        }, 0);
    }

      function countFn(N) {
        var count = 0;
        for (var i = 0; i < N; i++) {
            count += i;
        }          
        return count;
    }

    function updateAllocatedWrapper(ev, evData) {
        updateAllocatedV2(evData.allocated);
    }

    function redrawChart() {
        var chart = _chartElem.highcharts();
        chart.redraw();
    }

    function getDayChartDataRequest() {
        var deferred = $.Deferred();

        var parameters = JSON.stringify({
            unitID: unitID,
            sectionID: sectionID,
            date: date,
        });

        $.ajax({
            url: urlConfig.schedule.chart,
            data: parameters,
            success: function (response) {
                if (response != null) {
                    deferred.resolve($.parseJSON(response));
                } else {
                    deferred.reject();
                }
            },
            error: function (error) {
                deferred.reject();
            }
        });

        return deferred.promise();
    }

    return {
        updateChart: updateChart,
        updateAllocated: updateAllocated,
        redrawChart: redrawChart,
    };
}();