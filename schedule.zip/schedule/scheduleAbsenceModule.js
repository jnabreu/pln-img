var scheduleAbsenceModule = function () {

    //#region Helpers

    function myName() {
        return "view-absence";
    }

    function getParent() {
        return $('#divViewsArea').parent();
    }

    function getContainer() {
        return $("#divViewAbsence");
    }

    function getScrollContainer() {
        return 'divAbsenceScroll';
    }

    function setVisibleArea() {
        if (scheduleModule.isCurrentDataTab() && scheduleModule.getSelectedView() == myName()) {
            var heightParent = parseInt(getContainer().parent().css('height')),
                height = parseInt(getContainer().find('#tblAbsence').css('height'));

            getContainer().find('#' + getScrollContainer()).css({ 'height': (heightParent - height) + 'px' });
            getContainer().find('#' + getScrollContainer()).scrollTop(0);
            scrollModule.updateScroll(getScrollContainer());
        }
    }

    function getSelectedCollaborators(allOfThem) {
        var listStructureModel = [];
        if (scheduleModule.isCurrentDataTab() && scheduleModule.getSelectedView() == myName()) {

            if (allOfThem) {
                getContainer().find("input[type='checkbox']").each(function (index) {
                    listStructureModel.push(new Number(this.value));
                });
            } else {
                getContainer().find("input[type='checkbox']:checked").each(function (index) {
                    listStructureModel.push(new Number(this.value));
                });
            }
        }
        return listStructureModel;
    }
    //#endregion Helpers

    function loadView(date, searchTermCollaboratorName, searchTermWorkLoad) {
        if (scheduleModule.isCurrentDataTab() && scheduleModule.getSelectedView() == myName()) {

            scheduleModule.getBottonViewPageLoader().show();

            //Serealiza parametros
            var parameters = JSON.stringify({
                unitID: $("#ddlUnit").val(),
                sectionID: $("#ddlSection").val(),
                workstatitonTypeID: $("#ddlWorkstationType").val(),
                date: date.toMSDate(),
                searchTermCollaborator: searchTermCollaboratorName,
                searchTermWorkLoad: searchTermWorkLoad
            });

            $.ajax({
                url: urlConfig.schedule.absenceView,
                data: parameters,
                success: function (response) {
                    if (response) {
                        // Converte o retorno em um objeto JSON
                        var result = JSON.parse(response);
                        if (result) {
                            if (result.hasSuccess) {
                                $("#divViewsArea").height(getParent().height());
                                $("#divViewsArea").empty().html(result.successResult);
                                lcmModule.registerCheckLCMScheduleEvent('divBottomArea', lcmModule.getTypes().ABSENCE);
                            } else {
                                $("#divViewsArea").height(getParent().height());
                                $("#divViewsArea").empty().html(result.errorResult);
                            }
                        }
                    } else {
                        // Retorna a mensagem de erro
                        dialogModule.createDialog(0, _globalResources.getResource().ErrorTitle, _globalResources.getResource().CommunicationError);
                    }

                    scheduleModule.getBottonViewPageLoader().hide();
                }
            });
        }
    }

    function registerEvents() {
        // $("#divViewsArea").find('.info').off('click').on('click', function (e) {
        //     scheduleEditCollaboratorTime.openEdit($(this).data("id"), scheduleModule.getSelectedWeekDay());
        //     e.stopPropagation();
        // });
    }

    function init() {
        registerEvents();
        setVisibleArea();
        scrollModule.createScroll(getScrollContainer());
    }

    return {
        init: init,
        loadView: loadView,
        myName: myName,
        setVisibleArea: setVisibleArea,
        getSelectedCollaborators: getSelectedCollaborators
    }

}();
