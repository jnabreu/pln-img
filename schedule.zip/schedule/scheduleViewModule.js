var scheduleViewModule = function () {

    function loadView(unitID, sectionID, workstationTypeID, selectedDate, isFirstTime, isFilter, collaboratorName, workLoad, sorting, orderBy) {
        if (scheduleModule.isCurrentDataTab()) {
            if (isFilter) {
                $.when(
                    scheduleChartCollaboratorModule.loadView(unitID, sectionID, workstationTypeID, selectedDate, collaboratorName, workLoad),
                    scheduleChartCollaboratorTableViewModule.loadView(selectedDate, collaboratorName, workLoad, sorting, orderBy),
                    scheduleAbsenceModule.loadView(selectedDate, collaboratorName, workLoad)
                ).done(function () {
                    scheduleModule.getMainPageLoader().hide();
                });
            } else {
                $.when(
                    scheduleChartModule.updateChart($("#divChartArea"), selectedDate, isFirstTime),
                    scheduleChartCollaboratorModule.loadView(unitID, sectionID, workstationTypeID, selectedDate, null, null),
                    scheduleChartCollaboratorTableViewModule.loadView(selectedDate),
                    scheduleAbsenceModule.loadView(selectedDate)
                ).done(function () {
                    scheduleModule.getMainPageLoader().hide();
                });
            }
        }
    }

    function setVisibleArea() {
        //scheduleChartCollaboratorModule.loadView(unitID, sectionID, workstationTypeID, selectedDate, collaboratorName, workLoad),
        scheduleChartCollaboratorTableViewModule.setVisibleArea();
        scheduleAbsenceModule.setVisibleArea();
    }

    return {
        loadView: loadView,
        setVisibleArea: setVisibleArea
    }

}();