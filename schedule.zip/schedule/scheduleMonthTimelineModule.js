var scheduleMonthTimelineModule = function () {

    var _containerDiv = '#monthDataContent';
    var _contextData = {};
    var _monthsLoaded = [];
    var _chartData = [];
    var _eventsHash = {};
    var _outPolyvalents = { objPaths: [] };
    var _isFirstTime = true;
    var _operations = null;
    // remove this line
    var _dayInMonthView = [];

    var _dhtmlxSchedulerSettings = {
        properties: {
            viewName: 'timeline_month_data',
            labelName: 'Timeline',
            openDate: new Date(),
            dhxContainer: 'monthly_timeline',
            linkTitle: "", // TODO: edit linkTitle (_globalResources.getResource().schedule.OpenYearDetail),
            allCollaborators: [],
            schedulerConfigs: {
                time_step: 15,
                xy: {
                    nav_height: 36,
                }
            },
            timelineConfigs: {
                dx: 200,
            },
        },
        methods: {},
        templatesHandlers: {
            defineEventFilter: defineFilterMonthTimeline,
            defineTooltipText: defineMonthTooltipText,
            defineTimelineScaleLabelClosure: defineTimelineMonthScaleLabelClosure,
        },
        eventHandlers: {
            onBeforeViewChangeCallback: onBeforeViewChangeCallbackExtended,
            onViewChangeCallback: onViewChangeCallbackExtended,
        },
    };

    function getEventsHash() {
        return _eventsHash;
    }

    function getMonthlyEventsRequest(unitID, sectionID, workstationTypeID, startDate, endDate) {
        var deferred = $.Deferred();

        var parameters = JSON.stringify({
            unitID: unitID,
            sectionID: sectionID,
            workstationTypeID: workstationTypeID,
            startDate: startDate,
            endDate: endDate,
        });

        $.ajax({
            url: urlConfig.schedule.monthData,
            async: true,
            data: parameters,
            success: function (response) {
                if (response != null) {
                    deferred.resolve($.parseJSON(response));
                } else {
                    deferred.reject();
                }
            },
            error: function (error) {
                deferred.reject(error);
            }
        });
        //#region mock data

        //var resp = {};
        //var result = { "ExtendProperties": null, "HasError": false, "HasInformation": false, "HasQuestion": false, "ItensAmount": 0, ... }
        //resp.successResult = result;
        //resp.hasSuccess = true;
        //deferred.resolve(resp);

        //#endregion

        return deferred.promise();
    }

    function getMonthlyEvents(unitID, sectionID, workstationTypeID, dateNow, onSuccessCallback, params) {
        scheduleModule.showPageLoader('month.getMonthlyEvents');

        var dates = scheduleBaseTimelineModule.getStartAndEndDate(dateNow),
            startDate = dates.startDate,
            endDate = dates.endDate;

        _contextData.dateNow = startDate;
        _dhtmlxSchedulerSettings.properties.openDate = startDate;

        getMonthlyEventsRequest(unitID, sectionID, workstationTypeID, startDate, endDate)
            .done(function (response) {
                if (response.hasSuccess) {
                    $(_containerDiv).show();
                    _monthsLoaded.push(dateNow);
                    onSuccessCallback(response.successResult, params);
                } else {
                    handleError(response);
                }
            })
            .fail(function (error) {
                dialogModule.createDialog(0, _globalResources.getResource().ErrorTitle,
                    _globalResources.getResource().CommunicationError);
            })
            .always(function () {
                scheduleModule.hidePageLoader('month.getMonthlyEvents')
            });
    }

    function loadView(unitID, sectionID, workstationTypeID, operations, selectedDate, endDate) {
        scheduleDayTimelineModule.getContainer().hide();
        _operations = operations;
        if (scheduleModule.isCurrentMonthDataTab()) {
            resetGlobalVars();

            //if not a valid date - return a empty date - create one based on selectedDate
            if (isNaN(dateNow))
                //dateNow = new Date(parseInt(selectedDate.toMSDate().substr(6)))|| new Date();
                dateNow = scheduleBaseTimelineModule.stringToDate(selectedDate, 'dd/mm/yyyy', '/')
                || new Date();

            _contextData = {
                unitID: unitID,
                sectionID: sectionID,
                workstationTypeID: workstationTypeID,
                dateNow: dateNow,
            }
            getMonthlyEvents(unitID, sectionID, workstationTypeID, dateNow, init);
        }
    }

    // TODO: remove this func
    function isMonthEventFn(collabLabel, date, isSectionPolyvalent, isPolyvalent) {
        var hash = collabLabel + '.' + date.getTime();

        if (($.inArray(hash, _dayInMonthView) > -1) || isPolyvalent || isSectionPolyvalent) {
            return false;
        } else {
            _dayInMonthView.push(hash);
            return true;
        }
    }

    function handleDate(collaboratorData) {
        /// <summary>
        /// Handles a collaborator dates (rest, absence, etc)
        /// </summary>
        /// <param name="collaboratorData">the collaborator date</param>
        /// <returns type="dhx event type">a dhtmlx event object. 
        /// i.e: {id, start_date, end_date, ... } </returns> 

        var dhxEvent = {};
        var propertiesMethods = scheduleEventsModule.getPropertiesMethods();

        var dhxDates = getDhxDates(collaboratorData);
        var eventSpecificData = getEventSpecificData(collaboratorData, dhxDates.startDate, dhxDates.endDate);

        var monthView = {}, dayView = {};
        dhxEvent.details = monthView.details = '';
        dhxEvent.text = monthView.text = eventSpecificData.text;
        dhxEvent.type = monthView.type = propertiesMethods.getType(collaboratorData) + ' ' + getApprovedClass(collaboratorData);
        dhxEvent.color = monthView.color = propertiesMethods.getColor(collaboratorData);
        dhxEvent.textColor = monthView.textColor = propertiesMethods.getTextColor(collaboratorData);
        dhxEvent.start_date = monthView.start_date = dhxDates.fullDayStartDate;
        dhxEvent.end_date = monthView.end_date = dhxDates.fullDayEndDate;

        dhxEvent.date = dhxDates.date;
        dhxEvent.realStartDate = dayView.start_date = dhxDates.startDate;  // the real event start date
        dhxEvent.realEndDate = dayView.end_date = dhxDates.endDate;        // the real event end date
        dhxEvent.fullDayStartDate = dhxDates.fullDayStartDate;             // start date as 00:00
        dhxEvent.fullDayEndDate = dhxDates.fullDayEndDate;                 // start date + 1 as 00:00
        dhxEvent.isFullDayType = eventSpecificData.isFullDayType;
        dhxEvent.dayType = eventSpecificData.dayType;
        dhxEvent.isVisible = eventSpecificData.isVisible;
        dhxEvent.countAsAllocated = eventSpecificData.countAsAllocated;
        dhxEvent.collabLabel = collaboratorData.CollaboratorName;
        dhxEvent.enrollmentNumber = collaboratorData.Enrollment;
        dhxEvent.intervalStart = dhxDates.intervalStart;
        dhxEvent.intervalEnd = dhxDates.intervalEnd;
        dhxEvent.intervalStart2 = dhxDates.intervalStart2;
        dhxEvent.intervalEnd2 = dhxDates.intervalEnd2;
        dhxEvent.workstationType = collaboratorData.WorkstationType;
        dhxEvent.isDayTimelineEvent = false;
        dhxEvent.scheduleID = collaboratorData.ScheduleID;
        dhxEvent.rangeBegin = dhxDates.rangeBegin;
        dhxEvent.rangeEnd = dhxDates.rangeEnd;
        dhxEvent.granularity = collaboratorData.Granularity;
        dhxEvent.sectionID = collaboratorData.SectionID;
        dhxEvent.workstationName = collaboratorData.WorkstationName;
        dhxEvent.workstationTypeName = collaboratorData.WorkstationTypeName;
        dhxEvent.workstationTypeID = collaboratorData.WorkstationTypeID || null;
        dhxEvent.workstationTypeColor = collaboratorData.WorkstationTypeColor;
        dhxEvent.workstationID = collaboratorData.WorkstationID || null;
        dhxEvent.isSectionPolyvalent = collaboratorData.IsSectionPolyvalent;
        dhxEvent.isPolyvalent = collaboratorData.IsPolyvalent;
        dhxEvent.workContractID = collaboratorData.WorkContractID;
        dhxEvent.intervalTypeID = collaboratorData.IntervalTypeID;
        dhxEvent.weeklyWorkLoad = collaboratorData.WeeklyWorkLoad;
        dhxEvent.dailyWorkLoad = collaboratorData.DailyWorkload;
        dhxEvent.hasHalfTurnAbsence = collaboratorData.HasHalfTurnAbsence;
        dhxEvent.situation = collaboratorData.Situation;
        dhxEvent.seqNumber = 0;
        dhxEvent.hasEdit = false;
        dhxEvent.hasDelete = false;
        dhxEvent.belongsToPolyvalent = false;
        dhxEvent.isFill = false;
        dhxEvent.isRest = false;
        dhxEvent.absenceRuleID = collaboratorData.AbsenceRuleID;
        dhxEvent.absenceReasonID = collaboratorData.AbsenceReasonID;
        dhxEvent.isAbsenceWorkstation = (collaboratorData.AbsenceReasonID) ? true : false;
        dhxEvent.isFixedWorkstation = collaboratorData.IsFixedWorkstation;
        dhxEvent.seqPeriod = collaboratorData.SeqPeriod;
        dhxEvent.description = eventSpecificData.description ? eventSpecificData.description : null;
        dayView.type = dhxEvent.type + " " + eventSpecificData.type;

        dhxEvent.monthView = monthView;
        dhxEvent.dayView = dayView;
        return dhxEvent;
    }

    function getApprovedClass(collaboratorData) {
        return collaboratorData.Situation === 'A' ? 'approved' : '';
    }

    function getDhxDates(collaboratorDate) {
        var date = new Date(+new Date(parseInt(collaboratorDate.Date.substr(6))) + (new Date(parseInt(collaboratorDate.Date.substr(6))).getTimezoneOffset() * 60000))

        var auxEndDate = new Date(date);

        var parsedStartDate = new Date(new Date(parseInt(collaboratorDate.StartDate.substr(6))).getUTCFullYear(), 
                                       new Date(parseInt(collaboratorDate.StartDate.substr(6))).getUTCMonth(), 
                                       new Date(parseInt(collaboratorDate.StartDate.substr(6))).getUTCDate(), 
                                       new Date(parseInt(collaboratorDate.StartDate.substr(6))).getUTCHours(), 
                                       new Date(parseInt(collaboratorDate.StartDate.substr(6))).getUTCMinutes(), 
                                       new Date(parseInt(collaboratorDate.StartDate.substr(6))).getUTCSeconds());
        
        var parsedEndDate = new Date(new Date(parseInt(collaboratorDate.EndDate.substr(6))).getUTCFullYear(), 
                                     new Date(parseInt(collaboratorDate.EndDate.substr(6))).getUTCMonth(), 
                                     new Date(parseInt(collaboratorDate.EndDate.substr(6))).getUTCDate(), 
                                     new Date(parseInt(collaboratorDate.EndDate.substr(6))).getUTCHours(), 
                                     new Date(parseInt(collaboratorDate.EndDate.substr(6))).getUTCMinutes(), 
                                     new Date(parseInt(collaboratorDate.EndDate.substr(6))).getUTCSeconds());
            
        var parsedIntervalStart = collaboratorDate.IntervalBeginHour ? 
                                 new Date(new Date(parseInt(collaboratorDate.IntervalBeginHour.substr(6))).getUTCFullYear(), 
                                     new Date(parseInt(collaboratorDate.IntervalBeginHour.substr(6))).getUTCMonth(), 
                                     new Date(parseInt(collaboratorDate.IntervalBeginHour.substr(6))).getUTCDate(), 
                                     new Date(parseInt(collaboratorDate.IntervalBeginHour.substr(6))).getUTCHours(), 
                                     new Date(parseInt(collaboratorDate.IntervalBeginHour.substr(6))).getUTCMinutes(), 
                                     new Date(parseInt(collaboratorDate.IntervalBeginHour.substr(6))).getUTCSeconds())
                                  : null;

        var parsedIntervalEnd = collaboratorDate.IntervalEndHour ?
                                new Date(new Date(parseInt(collaboratorDate.IntervalEndHour.substr(6))).getUTCFullYear(),
                                            new Date(parseInt(collaboratorDate.IntervalEndHour.substr(6))).getUTCMonth(),
                                            new Date(parseInt(collaboratorDate.IntervalEndHour.substr(6))).getUTCDate(),
                                            new Date(parseInt(collaboratorDate.IntervalEndHour.substr(6))).getUTCHours(),
                                            new Date(parseInt(collaboratorDate.IntervalEndHour.substr(6))).getUTCMinutes(),
                                            new Date(parseInt(collaboratorDate.IntervalEndHour.substr(6))).getUTCSeconds())
                                    : null;

        var parsedIntervalStart2 = collaboratorDate.IntervalBeginHour2 ?
                                new Date(new Date(parseInt(collaboratorDate.IntervalBeginHour2.substr(6))).getUTCFullYear(),
                                         new Date(parseInt(collaboratorDate.IntervalBeginHour2.substr(6))).getUTCMonth(),
                                         new Date(parseInt(collaboratorDate.IntervalBeginHour2.substr(6))).getUTCDate(),
                                         new Date(parseInt(collaboratorDate.IntervalBeginHour2.substr(6))).getUTCHours(),
                                         new Date(parseInt(collaboratorDate.IntervalBeginHour2.substr(6))).getUTCMinutes(),
                                         new Date(parseInt(collaboratorDate.IntervalBeginHour2.substr(6))).getUTCSeconds())
                                    : null;

        var parsedIntervalEnd2 = collaboratorDate.IntervalEndHour2 ?
                                new Date(new Date(parseInt(collaboratorDate.IntervalEndHour2.substr(6))).getUTCFullYear(),
                                            new Date(parseInt(collaboratorDate.IntervalEndHour2.substr(6))).getUTCMonth(),
                                            new Date(parseInt(collaboratorDate.IntervalEndHour2.substr(6))).getUTCDate(),
                                            new Date(parseInt(collaboratorDate.IntervalEndHour2.substr(6))).getUTCHours(),
                                            new Date(parseInt(collaboratorDate.IntervalEndHour2.substr(6))).getUTCMinutes(),
                                            new Date(parseInt(collaboratorDate.IntervalEndHour2.substr(6))).getUTCSeconds())
                                    : null;

        var parsedRangeBegin = collaboratorDate.RangeBegin ?
                                new Date(new Date(parseInt(collaboratorDate.RangeBegin.substr(6))).getUTCFullYear(),
                                         new Date(parseInt(collaboratorDate.RangeBegin.substr(6))).getUTCMonth(),
                                         new Date(parseInt(collaboratorDate.RangeBegin.substr(6))).getUTCDate(),
                                         new Date(parseInt(collaboratorDate.RangeBegin.substr(6))).getUTCHours(),
                                         new Date(parseInt(collaboratorDate.RangeBegin.substr(6))).getUTCMinutes(),
                                         new Date(parseInt(collaboratorDate.RangeBegin.substr(6))).getUTCSeconds())
                                : null;

        var parsedRangeEnd = collaboratorDate.RangeEnd ?
                                new Date(new Date(parseInt(collaboratorDate.RangeEnd.substr(6))).getUTCFullYear(),
                                         new Date(parseInt(collaboratorDate.RangeEnd.substr(6))).getUTCMonth(),
                                         new Date(parseInt(collaboratorDate.RangeEnd.substr(6))).getUTCDate(),
                                         new Date(parseInt(collaboratorDate.RangeEnd.substr(6))).getUTCHours(),
                                         new Date(parseInt(collaboratorDate.RangeEnd.substr(6))).getUTCMinutes(),
                                         new Date(parseInt(collaboratorDate.RangeEnd.substr(6))).getUTCSeconds())
                                : null;

        var fullDayStartDate = new Date(date.getFullYear(),
                                date.getMonth(),
                                date.getDate(),
                                0, 0);

        var fullDayEndDate = new Date(fullDayStartDate);

        fullDayEndDate.setDate(fullDayStartDate.getDate() + 1);

        var startDate = new Date(date.getFullYear(),
                        date.getMonth(),
                        date.getDate(),
                        parsedStartDate.getHours(),
                        parsedStartDate.getMinutes());

        
        if (parsedEndDate.getDate() === 2) { // 02-01-2000 HH:MM or 01-01-2000 HH:MM
            auxEndDate.setDate(date.getDate() + 1);
        }
        var endDate = new Date(auxEndDate.getFullYear(), auxEndDate.getMonth(), auxEndDate.getDate(), parsedEndDate.getHours(), parsedEndDate.getMinutes());

        var intervalStart = null;
        if (parsedIntervalStart) {
            var auxIntervalStart = new Date(date);
            if (parsedIntervalStart.getDate() === 2) {
                auxIntervalStart.setDate(date.getDate() + 1);
            }
            intervalStart = new Date(auxIntervalStart.getFullYear(), auxIntervalStart.getMonth(), auxIntervalStart.getDate(), parsedIntervalStart.getHours(), parsedIntervalStart.getMinutes());
        }

        var intervalEnd = null;
        if (parsedIntervalEnd) {
            var auxIntervalEnd = new Date(date);
            if (parsedIntervalEnd.getDate() === 2) {
                auxIntervalEnd.setDate(date.getDate() + 1);
            }
            intervalEnd = new Date(auxIntervalEnd.getFullYear(), auxIntervalEnd.getMonth(), auxIntervalEnd.getDate(), parsedIntervalEnd.getHours(), parsedIntervalEnd.getMinutes());
        }

        var intervalStart2 = null;
        if (parsedIntervalStart2) {
            var auxIntervalStart2 = new Date(date);
            if (parsedIntervalStart2.getDate() === 2) {
                auxIntervalStart2.setDate(date.getDate() + 1);
            }
            intervalStart2 = new Date(auxIntervalStart2.getFullYear(), auxIntervalStart2.getMonth(), auxIntervalStart2.getDate(), parsedIntervalStart2.getHours(), parsedIntervalStart2.getMinutes());
        }

        var intervalEnd2 = null;
        if (parsedIntervalEnd2) {
            var auxIntervalEnd2 = new Date(date);
            if (parsedIntervalEnd2.getDate() === 2) {
                auxIntervalEnd2.setDate(date.getDate() + 1);
            }
            intervalEnd2 = new Date(auxIntervalEnd2.getFullYear(), auxIntervalEnd2.getMonth(), auxIntervalEnd2.getDate(), parsedIntervalEnd2.getHours(), parsedIntervalEnd2.getMinutes());
        }

        var rangeBegin = null;
        if (parsedRangeBegin) {
            var auxRangeBegin = new Date(date);
            if (parsedRangeBegin.getDate() === 2) {
                auxRangeBegin.setDate(date.getDate() + 1);
            }
            rangeBegin = new Date(auxRangeBegin.getFullYear(), auxRangeBegin.getMonth(), auxRangeBegin.getDate(), parsedRangeBegin.getHours(), parsedRangeBegin.getMinutes());
        }

        var rangeEnd = null;
        if (parsedRangeEnd) {
            var auxRangeEnd = new Date(date);
            if (parsedRangeEnd.getDate() === 2) {
                auxRangeEnd.setDate(date.getDate() + 1);
            }
            rangeEnd = new Date(auxRangeEnd.getFullYear(), auxRangeEnd.getMonth(), auxRangeEnd.getDate(), parsedRangeEnd.getHours(), parsedRangeEnd.getMinutes());
        }

        return {
            date: date,
            startDate: startDate,
            endDate: endDate,
            fullDayStartDate: fullDayStartDate,
            fullDayEndDate: fullDayEndDate,
            intervalStart: intervalStart,
            intervalEnd: intervalEnd,
            intervalStart2: intervalStart2,
            intervalEnd2: intervalEnd2,
            rangeBegin: rangeBegin,
            rangeEnd: rangeEnd,
        }
    }

    function getWorkTypeLabel(startDate, endDate) {
        return "<span>"
               + ('0' + startDate.getHours()).slice(-2) + ":" + ('0' + startDate.getMinutes()).slice(-2)
               + "<br />"
               + ('0' + endDate.getHours()).slice(-2) + ":" + ('0' + endDate.getMinutes()).slice(-2)
               + "</span>";
    }

    function getRestFCData(collaboratorData) {
        return {
            text: "FC",
            isFullDayType: true,
            isVisible: true,
            countAsAllocated: false,
            type: "FC light",
            dayType: "CREST",
        }
    }

    function getRestFOData(collaboratorData) {
        return {
            text: "FO",
            isFullDayType: true,
            isVisible: true,
            countAsAllocated: false,
            type: "FO light",
            dayType: "MREST"
        }
    }

    function getNonWorkingData(collaboratorData) {
        return {
            text: "V",
            isFullDayType: true,
            isVisible: true,
            countAsAllocated: false,
            type: "V light",
            dayType: "N",
        }
    }

    function getHolidayData(collaboratorData) {
        return {
            text: "FER",
            isFullDayType: true,
            isVisible: true,
            countAsAllocated: false,
            type: "FER light",
            dayType: "H",
        }
    }

    function getWorkData(collaboratorData, startDate, endDate) {
        return {
            text: getWorkTypeLabel(startDate, endDate),
            isFullDayType: false,
            isVisible: true,
            countAsAllocated: true,
            dayType: "W",
        }
    }

    function getAbsenceData(collaboratorData) {
        return {
            text: collaboratorData.AbsenceReasonAlias,
            isFullDayType: true,
            isVisible: true,
            countAsAllocated: false,
            type: "ABS light",
            dayType: "A",
            description: collaboratorData.AbsenceReasonDescription,
        }
    }

    function getEventSpecificData(collaboratorData, startDate, endDate) {
        var res = {};
        var dayType = collaboratorData.DayType;

        if (dayType === "F") {  // Rest
            var restType = collaboratorData.RestType;
            switch (restType) {
                case "0": // FO
                    res = getRestFOData();
                    break;
                case "1": // FC
                    res = getRestFCData();
                    break;
            }
        } else if (dayType === "N") { // Non working day
            res = getNonWorkingData(collaboratorData);
        } else if (dayType === "R") { // Holiday
            res = getHolidayData(collaboratorData);
        } else if (dayType === "T") { // Work
            res = getWorkData(collaboratorData, startDate, endDate);
        } else if (dayType === "A") { // Absence
            res = getAbsenceData(collaboratorData);
        }
        return res;
    }

    function getEventSpecificDataFunctions() {
        return {
            getRestFCData: getRestFCData,
            getRestFOData: getRestFOData,
            getNonWorkingData: getNonWorkingData,
            getWorkData: getWorkData,
        };
    }

    function addMonthDataCallback(successResult, params) {
        dateNow = scheduleBaseTimelineModule.partsToDate(params.newDate.getDate(), params.newDate.getMonth(), params.newDate.getFullYear());

        scheduler.clearAll();
        var resHandler = scheduleEventsModule.handleCollaboratorsTree(successResult.EventsTree, handleDate, { allCollabs: false, shortenNames: true });
        _chartData = handleChartDataDates(successResult.ChartData) || [];
        _dhtmlxSchedulerSettings.properties.timelineConfigs.y_unit = resHandler.groups;
        _dhtmlxSchedulerSettings.properties.allCollaborators = resHandler.collabs;
        scheduleBaseTimelineModule.init(_dhtmlxSchedulerSettings);
        scheduler.setCurrentView();
        _eventsHash = organizeEvents(resHandler.events, _outPolyvalents, {});
        handlePolyvalentEvents();
        scheduleBaseTimelineModule.addData(resHandler.events);
        onViewChangeCallbackExtended(params.newMode, params.newDate);
    }

    function isMonthLoaded(newDate) {
        for (var i = 0; i < _monthsLoaded.length; i++) {
            if (customControlsModule.compareDatesByMonth(newDate, _monthsLoaded[i])) {
                return true;
            }
        }
        return false;
    }

    function sortAllCollaboratorsByName(a, b) {
        var nameA = (a.name.indexOf('-') > -1 ? a.name.split("-")[1].trim() : a.name);
        var nameB = (b.name.indexOf('-') > -1 ? b.name.split("-")[1].trim() : b.name);

        if (nameA == nameB) return 0;
        return (nameA < nameB) ? -1 : 1;
    }

    function clickDayCallback(ev) {
        console.log("on click day callback")
        scheduleModule.showPageLoader('clickDay');

        var allCollaborators = _dhtmlxSchedulerSettings.properties.allCollaborators;
        allCollaborators.sort(sortAllCollaboratorsByName);
        allCollaborators = $.map(allCollaborators, function (el) {
            return {
                key: "COL_" + el.id,
                label: '<span data-collabid="' + el.id + '" style="display: none">' + el.name + '</span>',
                id: el.id,
                originalLabel: el.name,
            };
        });

        var dateString = $(this).children().data('timespan');
        var date = new Date(dateString);
        var events = $.grep(scheduler.getEvents(), function (event) {
            return customControlsModule.compareDatesByDay(event.date, date);
        });

        if (events.length === 0) {
            scheduleModule.hidePageLoader('clickDay');
            dialogModule.showOK(
                _globalResources.getResource().schedule.NoSchedule,
                _globalResources.getResource().schedule.NoSchedule);
            return;
        }

        $('#tabMonthData').trigger('detachEvents');
        $(_containerDiv).hide();
        scheduleDayTimelineModule.getContainer().show();

        var rangeBegin = null,
            rangeEnd = null,
            granularity = 15;

        if (events.length > 0) {
            rangeBegin = events[0].rangeBegin;
            rangeEnd = events[0].rangeEnd;
            granularity = events[0].granularity;
        }

        var configs = {
            date: date,
            collaborators: allCollaborators,
            rangeBegin: rangeBegin,
            rangeEnd: rangeEnd,
            granularity: granularity,
            chartData: _chartData,
        };

        scheduleDayLayoutModule.loadView(configs, _isFirstTime);
        scheduleModule.hidePageLoader('clickDay');
    }

    function sortByCollabAndDate(a, b) {
        if (a.collabID === b.collabID) {
            if (customControlsModule.compareDatesByDay(a.date, b.date)) {
                return 0;
            } else if (+a.date < +b.date) {
                return -1;
            } else {
                return 1;
            }
        } else {
            if (a.collabID < b.collabID) {
                return -1;
            } else {
                return 1;
            }
        }
    }

    function byString(o, s) {
        s = s.replace(/\[(\w+)\]/g, '.$1'); // convert indexes to properties
        s = s.replace(/^\./, '');           // strip a leading dot
        var a = s.split('.');
        for (var i = 0, n = a.length; i < n; ++i) {
            var k = a[i];
            if (k in o) {
                o = o[k];
            } else {
                return;
            }
        }
        return o;
    }

    function organizeEvents(events, outPolyvalents, eventsHash) {

        for (var key in events) {
            var event = events[key];
            if (+event.date in eventsHash) {
                var dateObj = eventsHash[+event.date];
                if (event.collabID in dateObj) {
                    var auxArray = dateObj[event.collabID];
                    auxArray.push(event);
                    dateObj[event.collabID] = auxArray;
                } else {
                    dateObj[event.collabID] = [event];
                }
            } else {
                eventsHash[+event.date] = {};
                eventsHash[+event.date][event.collabID] = [event];
            }
            if (event.isPolyvalent || event.isSectionPolyvalent) {
                outPolyvalents.objPaths = outPolyvalents.objPaths.concat(+event.date + '.' + event.collabID);
            }
        }

        return eventsHash;
    }

    function changePolyvalenceDescription(polyvalents) {
        if (!polyvalents) return;

        var main = $.grep(polyvalents, function (el) {
            return el.seqNumber === 0;
        })
        if (main.length > 0) {
            var minMax = customControlsModule.getMinMaxDate(polyvalents, 'realStartDate', 'realEndDate');
            main[0].text = getWorkTypeLabel(minMax.minDate, minMax.maxDate);
        }
    }

    function handlePolyvalentEvents() {
        var polyCollabs = [];

        $.each(_outPolyvalents.objPaths, function (idx, el) {
            var poly = null;
            if (poly = byString(_eventsHash, el)) {
                polyCollabs.push(poly);
            }
        });

        //var collapsedEvents = [];
        $.each(polyCollabs, function (index, polyvalents) {
            //collapsedEvents.push(changePolyvalenceDescription(polyvalents));
            changePolyvalenceDescription(polyvalents);
        });
    }

    function getChartData(date, mode) {
        /// <summary>
        /// getter for _chartData to be used outside this module
        /// </summary>
        /// <param name="date"></param>
        /// <param name="mode"></param>
        /// <returns type=""></returns>
        var res = null;
        if (mode === "day") {
            var resList = $.grep(_chartData, function (el) {
                return customControlsModule.compareDatesByDay(el.date, date);
            });
            if (resList.length > 0) {
                res = resList[0].chartData;
            }
        } else if (mode === "month") {
            console.debug("Mode not implemented: ", mode);
        } else {
            console.debug("unrecognized mode: ", mode);
        }
        return res;
    }

    function handleChartDataDates(chartData) {
        if (!(chartData && chartData.length > 0)) return;
        return $.map(chartData, function (elem) {
            elem.chartData = {};
            for (var key in elem.ChartData) {
                elem.chartData[key.toLowerCase()] = elem.ChartData[key];
                delete elem.ChartData[key];
            }
            delete elem.ChartData;
            if (elem.Date) {
                elem.date = new Date(parseInt(elem.Date.substr(6)));
                elem.date = new Date(elem.date.getUTCFullYear(), elem.date.getUTCMonth(), elem.date.getUTCDate());
                
            }
            delete elem.Date;
            return elem;
        });
    }

    //function defineFilterMonthTimeline(id, event) {
    //    if (!event.isDayTimelineEvent && !(event.isPolyvalent || event.isSectionPolyvalent)) {
    //        return true;
    //    } else {
    //        return false;
    //    }
    //}

    function defineFilterMonthTimeline(id, event) {
        if (!event.isDayTimelineEvent && !(event.isPolyvalent || event.isSectionPolyvalent)) {
            return true;
        } else {
            return false;
        }
    }

    function getTooltipData(event) {
        // TODO: refactor this code to handle intervals as array

        var hasInterval = event.intervalStart ? true : false,
            hasInterval2 = event.intervalStart2 ? true : false;

        var intervalStartDate = event.intervalStart,
            intervalEndDate = event.intervalEnd,
            intervalStartDate2 = event.intervalStart2,
            intervalEndDate2 = event.intervalEnd2;

        var intervalsForDailyWork = [];
        if (hasInterval) {
            intervalsForDailyWork.push({
                startDate: intervalStartDate,
                endDate: intervalEndDate,
            });
        }

        if (hasInterval2) {
            intervalsForDailyWork.push({
                startDate: intervalStartDate2,
                endDate: intervalEndDate2,
            });
        }

        return {
            enrollmentNumber: event.enrollmentNumber,
            collabLabel: event.collabLabel,
            startDate: event.realStartDate,
            endDate: event.realEndDate,
            hasInterval: hasInterval,
            hasInterval2: hasInterval2,
            intervalStartDate: event.intervalStart,
            intervalEndDate: event.intervalEnd,
            intervalStartDate2: event.intervalStart2,
            intervalEndDate2: event.intervalEnd2,
            dailyWork: scheduleTooltipHelper.getDailyWork(event.realStartDate, event.realEndDate, intervalsForDailyWork),
            workstationName: scheduleTooltipHelper.getWorkstationName(event),
        }
    }

    function defineMonthTooltipText(start, end, event) {
        var tooltip = '';
        if (event.isFullDayType) {
            tooltip = scheduleTooltipHelper.getFullDayTooltip(start, end, event);
        } else if (event.isSectionPolyvalent || event.isPolyvalent) {
            tooltip = scheduleTooltipHelper.getPolyvalentTooltip(start, end, event);
        } else {
            var data = getTooltipData(event);
            tooltip = scheduleTooltipHelper.getTooltipString(data);
        }
        return tooltip;
    }

    function defineTimelineMonthScaleLabelClosure(linkTitle) {
        return function (key, label, section) {
            var result = label;
            var prefix = key.substring(0, 4);
            var collabID = key.substring(4); // take id from the key;

            var resCollabs = $.grep(_dhtmlxSchedulerSettings.properties.allCollaborators, function (el) {
                return el.id == collabID
            });

            if (resCollabs.length > 0) {
                linkTitle = resCollabs[0].name;
            }

            if (!section.open && prefix === 'COL_') {
                return '<input data-collabid="' +
                    collabID + '" type="checkbox"></input> ' +
                    '<a href="#" title="' + linkTitle + '">' + label + '</a>';
            }
            return result;
        };
    }

    function closeTimelineView() {
        _isFirstTime = false;
        scheduleDayTimelineModule.getContainer().hide();
        $(_containerDiv).show();
        scheduleBaseTimelineModule.init(_dhtmlxSchedulerSettings);
        //Needed to update cached info - from DB - not between day view - month view 
        //loadView(_contextData.unitID, _contextData.sectionID, _contextData.workstationTypeID, _operations, null, null);
    }

    function registerClickDay(clickCallback) {
        var firstScale = $(_containerDiv + ' .dhx_scale_bar');
        var secondScale = $(_containerDiv + ' .dhx_second_scale_bar');
        firstScale.off('click').on('click', clickCallback);
        secondScale.off('click').on('click', clickCallback);
    }

    function onBeforeViewChangeCallbackExtended(oldMode, oldDate, newMode, newDate) {
        if (newDate != oldDate) {
            var dateNow = _contextData.dateNow || new Date();
            var newDate = newDate || new Date();

            var params = {
                newMode: newMode,
                newDate: newDate,
            };

            if (newMode === _dhtmlxSchedulerSettings.properties.viewName) {
                if (!customControlsModule.compareDatesByMonth(dateNow, newDate)) {
                    getMonthlyEvents(_contextData.unitID, _contextData.sectionID, _contextData.workstationTypeID, newDate, addMonthDataCallback, params);
                }
            }
            scheduleBaseTimelineModule.getDefaultEventHandlers().onBeforeViewChangeCallback(oldMode, oldDate, newMode, newDate);
            return true;
        }
    }

    function applyStyles() {
        var pointerCursorStyle = { "cursor": "pointer" };
        var defaultCursorStyle = { "cursor": "default" };

        $(_containerDiv + ' .dhx_scale_bar').css(pointerCursorStyle);
        $(_containerDiv + ' .dhx_second_scale_bar').css(pointerCursorStyle);
        $(_containerDiv + ' td.dhx_matrix_scell.item a').css(defaultCursorStyle);
        $(_containerDiv + ' .dhx_cal_data .dhx_row_item td').not('.dhx_matrix_scell').find('.dhx_data_table tbody tr').css(defaultCursorStyle);
        $(_containerDiv + ' .dhx_cal_event_line').css(defaultCursorStyle);
    }

    function switchScheduleCallback(answer, args, n_from, n_to) {
        if (answer) {
            console.log('Answered yes| Args: ', args);
            var form = '#divDialog';
            var datum;
            if (!args.datum) {
                datum = {
                    cid_from: $(form).find('#txtFrom').val(),
                    cid_to: $(form).find('#txtTo').val(),
                    date_source: $(form).find('#txtSourceDate').val().toMSDate(),
                    date_target: $(form).find('#txtTargetDate').val().toMSDate(),
                    questionPopup: false, // Not anymore
                    answer: args.answer,
                    unitID: $('#ddlUnit').val(),
                    sectionID: $('#ddlSection').val(),
                }
            }
            else {
                datum = args.datum;
            }
            datum.answer = answer;
            $.ajax({
                url: urlConfig.schedule.monthSwitchSchedule,
                async: true,
                data: JSON.stringify(datum),
                success: function (response) {
                    if (response) {
                        var result = JSON.parse(response);
                        if (result) {
                            if (result.hasSuccess) {
                                dialogModule.showDialog(result.successResult);
                                switch_nodes(n_from, n_to);
                            } else if (result.hasQuestion) {
                                if (result.genericMessage != null) {
                                    answerCode = result.genericMessage;
                                }
                                dialogModule.showYesOrNoDialog(result.questionResult, switchScheduleCallback, {
                                    answerCode: answerCode,
                                    datum: datum,
                                });
                            } else {
                                dialogModule.showDialog(result.errorResult);
                            }
                        }
                    }
                    else {
                        // Retorna a mensagem de erro
                        dialogModule.createDialog(0, _globalResources.getResource().ErrorTitle, _globalResources.getResource().CommunicationError);
                    }
                }
            });
        }
        else {
            console.log('Answered No');;
        }
    }

    function switch_nodes(node1, node2) {
        scheduleModule.updateSchedule(); // Update a Vista Mensal
        return true;
        // Older, better, behaviour
        if (!node1 || !node2) {
            scheduleModule.updateSchedule(); // Update a Vista Mensal
        }
        console.log("Nodes: ", node1, node2);
        var props = ['top', 'left', 'right', 'bottom'];
        var css1 = node1.css(props);
        var css2 = node2.css(props);
        // Switch the CSS
        node1.css(css2);
        node2.css(css1);
        return true;
    }

    function applySwitchSchedule() {
        var nodeSelector = ".dhx_cal_event_line:not(.approved)";
        var nodes = $(_containerDiv + ' ' + nodeSelector);
        // Double Click
        nodes.dblclick(function (event) {
            // Source
            var e_source = $(event.target);
            if (e_source[0].tagName === 'SPAN') {
                // Use the parent node
                e_source = $(e_source[0].parentElement);
            }
            var cid_from = e_source.parent().parent().prev().find('input[type="checkbox"]').data('collabid');
            var cindex_source = Array.prototype.indexOf.call(e_source[0].parentNode.children, e_source[0]) + 1; //CSS is 1-index
            var t_source = scheduler.getEventStartDate($(e_source).attr('event_id'));
            var timespan_source = customControlsModule.timestampToUTCHack(t_source);
            // Frontend Request
            var datum = {
                questionPopup: true,
                cid_from: cid_from,
                date_source: timespan_source,
            };
            $('#rootPageLoader').show().addClass('transparent');
            $.ajax({
                url: urlConfig.schedule.monthSwitchSchedule,
                async: true,
                data: JSON.stringify(datum),
                success: function (response) {
                    $('#rootPageLoader').hide().removeClass('transparent');
                    if (response) {
                        var result = JSON.parse(response);
                        if (result) {
                            if (result.hasSuccess) {
                                dialogModule.showDialog(result.successResult);
                                scheduleModule.updateSchedule(); // Update a Vista Mensal
                            } else if (result.hasQuestion) {
                                if (result.genericMessage != null) {
                                    answerCode = result.genericMessage;
                                }
                                dialogModule.showYesOrNoDialog(result.questionResult, switchScheduleCallback, {
                                    event: event,
                                    answerCode: answerCode,
                                });
                            } else {
                                dialogModule.showDialog(result.errorResult);
                            }
                        }
                    }
                    else {
                        // Retorna a mensagem de erro
                        dialogModule.createDialog(0, _globalResources.getResource().ErrorTitle, _globalResources.getResource().CommunicationError);
                    }
                },
                error: function () {
                    $('#rootPageLoader').hide().removeClass('transparent');
                },
            });
        });
        // Drag "events"
        nodes.draggable({
            revert: "invalid",
            appendTo: $("body"),
            zIndex: 1000,
            helper: "clone", // Drag a copy
            start: function (event, ui) {
                $(event.target).addClass("TST");
                console.error("Dragging Start");
            },
            stop: function (event, ui) {
                $(event.target).removeClass("TST");
                console.log("Dragging End");
            }
        });
        for (var idx = 0, l = nodes.length; idx < l; idx++) {
            var node = $(nodes[idx]);
            var currentRow = node.parent().find(nodeSelector);
            node.droppable({
                hoverClass: "TST-hover",
                accept: currentRow,
                drop: function (event, ui) {
                    // Source
                    var e_source = $(ui.draggable);
                    var cid_from = e_source.parent().parent().prev().find('input[type="checkbox"]').data('collabid');
                    var t_source = scheduler.getEventStartDate($(e_source).attr('event_id'));
                    var timespan_source = customControlsModule.timestampToUTCHack(t_source);
                    // Target
                    var e_target = $(event.target);
                    var cid_to = e_target.parent().parent().prev().find('input[type="checkbox"]').data('collabid');
                    var t_target = scheduler.getEventStartDate($(e_target).attr('event_id'));
                    var timespan_target = customControlsModule.timestampToUTCHack(t_target);

                    // Frontend Request
                    var datum = {
                        cid_from: cid_from,
                        cid_to: cid_to,
                        date_source: timespan_source,
                        date_target: timespan_target,
                        unitID: $('#ddlUnit').val(),
                        sectionID: $('#ddlSection').val(),
                    };
                    $('#rootPageLoader').show().addClass('transparent');
                    $.ajax({
                        url: urlConfig.schedule.monthSwitchSchedule,
                        async: true,
                        data: JSON.stringify(datum),
                        success: function (response) {
                            $('#rootPageLoader').hide().removeClass('transparent');
                            if (response) {
                                var result = JSON.parse(response);
                                if (result) {
                                    if (result.hasSuccess) {
                                        dialogModule.showDialog(result.successResult);
                                        switch_nodes(e_source, e_target);
                                    } else if (result.hasQuestion) {
                                        var answerCode = null;
                                        if (result.genericMessage != null) {
                                            answerCode = result.genericMessage;
                                        }
                                        dialogModule.showYesOrNoDialog(result.questionResult, switchScheduleCallback, {
                                            event: event,
                                            answerCode: answerCode,
                                            datum: datum,
                                        }, e_source, e_target);
                                    } else {
                                        dialogModule.showDialog(result.errorResult);
                                    }
                                }
                                // } else {
                                //     // Retorna a mensagem de erro
                                //     dialogModule.createDialog(0, _globalResources.getResource().ErrorTitle, _globalResources.getResource().CommunicationError);
                            }
                        },
                        error: function () {
                            $('#rootPageLoader').hide().removeClass('transparent');
                        },
                    });
                }
            })
        }
    }

    function onViewChangeCallbackExtended(newMode, newDate) {
        // console.info("MONTH TIMELINE: on view change")
        scheduleBaseTimelineModule.getDefaultEventHandlers().onViewChangeCallback(newMode, newDate);

        registerClickDay(clickDayCallback);
        applyStyles();
        applySwitchSchedule();
    }

    function toggleMonthView(showMonthView) {
        if (showMonthView) {
            $(_containerDiv + ' #monthly_timeline').show();
            $(_containerDiv + ' #monthDataError').hide();
            $(_containerDiv + ' #divButtonsArea').show();
            scheduleModule.setSizeContainer(_containerDiv + ' #monthly_timeline', 7);
            //scheduleModule.setSizeNoFooter(_containerDiv);

        } else {
            $(_containerDiv + ' #monthly_timeline').hide();
            $(_containerDiv + ' #monthDataError').show();
            $(_containerDiv + ' #divButtonsArea').hide();
            scheduleModule.setSizeContainer(_containerDiv + ' #monthScheduler', 67);
            //scheduleModule.setSizeNoFooter(_containerDiv);
        }
    }

    function handleError(response) {
        toggleMonthView(false);
        $(_containerDiv + ' #monthDataError').empty().html(response.errorResult);
    }

    function resetGlobalVars() {
        _monthsLoaded = [];
        _chartData = [];
        _eventsHash = {};
        _outPolyvalents = { objPaths: [] };
    }

    function showApproveOptions(ev) {
        var data = { showModal: true, divID: $(_containerDiv), clickEv: ev };
        $('#divSchedule').trigger('scheduleModule.showApproveOptions', data);
    }

    function showReprocessOptions(ev) {
        var data = { showModal: true, divID: $(_containerDiv), clickEv: ev };
        $('#divSchedule').trigger('scheduleModule.showReprocessOptions', data);
    }

    function showReportOptions(ev) {
        var data = { showModal: false, divID: $(_containerDiv), clickEv: ev };
        $('#divSchedule').trigger('scheduleModule.showReportOptions', data);
    }

    function registerEvents() {
        // register buttons clicks
        if (_operations) {
            if (_operations.CanApprove) {
                $(_containerDiv).find("#btnApprove").off('click').on('click', showApproveOptions);
            }
            if (_operations.CanProcess) {
                $(_containerDiv).find("#btnReprocess").off('click').on('click', showReprocessOptions);
            }
        } $(_containerDiv).find("#btnPrint").off('click').on('click', showReportOptions);
        applySwitchSchedule();
    }

    function init(successResult) {
        _isFirstTime = true;
        registerEvents();
        toggleMonthView(true);
        scheduleEventsModule.resetScheduler();
        if (successResult.EventsTree) {
            scheduleEventsModule.initDateTypes(successResult.EventTypes);
            var resHandler = scheduleEventsModule.handleCollaboratorsTree(successResult.EventsTree, handleDate, { allCollabs: false, shortenNames: true });
            _chartData = handleChartDataDates(successResult.ChartData) || [];
            _dhtmlxSchedulerSettings.properties.timelineConfigs.y_unit = resHandler.groups;

            _dhtmlxSchedulerSettings.properties.allCollaborators = resHandler.collabs;
            scheduleBaseTimelineModule.init(_dhtmlxSchedulerSettings);
            _eventsHash = organizeEvents(resHandler.events, _outPolyvalents, {});
            handlePolyvalentEvents();
            scheduleBaseTimelineModule.addData(resHandler.events);
            scheduleBaseTimelineModule.getEventHandlers().onViewChangeCallback();
        } else {
            dialogModule.createDialog(0, _globalResources.getResource().ErrorTitle,
                _globalResources.getResource().CommunicationError);
        }
    }

    function popup_datePickerChangeDate(e) {
        console.log(e);
        $('.datepicker').hide();
    }
    var popup_rootID = '#divDialog ';
    popupData = null; // Global Variable
    function initPopupSwitchSchedule(model) {
        // Datepickers - No form
        customControlsModule.applyDatePickerControl(['txtSourceDate'], true, false, null, null, false);
        $('#txtSourceDate').datepicker('option', 'disabled', true);
        $('#txtSourceDate').datepicker('option', 'defaultDate', $('#txtSourceDate').datepicker('getDate'));
        customControlsModule.applyDatePickerControl(['txtTargetDate'], true, false, null, null, false);
        // Confirm button
        $(popup_rootID + '#btnConfirm').click(function (e) {
            // Fill the "data" to be returned by the event
            var form = '#divDialog';
            popupData = {
                cid_from: $(form).find('#txtFrom').val(),
                cid_to: $(form).find('#txtTo').val(),
                date_source: $(form).find('#txtSourceDate').val().toMSDate(),
                date_target: $(form).find('#txtTargetDate').val().toMSDate(),
            }
            $(popup_rootID + '#btnYes').click();
        });
        // Drag the dialog
        $('#divDialog .content-default').draggable({
            scroll: false,
        });
    }

    return {
        init: init,
        initPopupSwitchSchedule: initPopupSwitchSchedule,
        loadView: loadView,
        closeTimelineView: closeTimelineView,
        getChartData: getChartData,
        getEventsHash: getEventsHash,
        getWorkTypeLabel: getWorkTypeLabel,
        getEventSpecificDataFunctions: getEventSpecificDataFunctions,
    };
}();
