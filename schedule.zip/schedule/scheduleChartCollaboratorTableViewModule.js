var scheduleChartCollaboratorTableViewModule = function () {

    //#region Helpers

    function myName() {
        return "view-chart-collaborator-table-view";
    }

    function getParent() {
        return $('#divViewsArea').parent();
    }

    function getContainer() {
        return $('#divViewChartCollaboratorTable');
    }

    function getScrollContainer() {
        return 'divViewChartCollaboratorTableScroll';
    }

    function getSelectedCollaborators(allOfThem) {
        var listStructureModel = [];
        if (scheduleModule.isCurrentDataTab() && scheduleModule.getSelectedView() == myName()) {

            if (allOfThem) {
                getContainer().find("input[type='checkbox']").not("#chkAll").each(function (index) {
                    listStructureModel.push(new Number(this.value));
                });
            } else {
                getContainer().find("input[type='checkbox']:checked").not("#chkAll").each(function (index) {
                    listStructureModel.push(new Number(this.value));
                });
            }
        }
        return listStructureModel;
    }

    function setVisibleArea() {
        if (scheduleModule.isCurrentDataTab() && scheduleModule.getSelectedView() == myName()) {

            var heightParent = parseInt(getContainer().parent().css('height')),
                height = parseInt(getContainer().find('#tblChartCollaborator').css('height'));

            getContainer().find('#' + getScrollContainer()).css({ 'height': (heightParent - height) + 'px' });
            getContainer().find('#' + getScrollContainer()).scrollTop(0);
            scrollModule.updateScroll(getScrollContainer());
        }
    }

    //#endregion Helpers

    function loadView(date, searchCollaboratorName, searchWorkLoad, sortByName, orderByColumn) {
        if (scheduleModule.isCurrentDataTab() && scheduleModule.getSelectedView() == myName()) {

            scheduleModule.getBottonViewPageLoader().show();

            //Serealiza parametros
            var parameters = JSON.stringify({
                unitID: $("#ddlUnit").val(),
                sectionID: $("#ddlSection").val(),
                workstatitonTypeID: $("#ddlWorkstationType").val(),
                date: date.toMSDate(),
                orderBy: (orderByColumn == null || orderByColumn == undefined ? 'A' : orderByColumn),
                sorting: sortByName,
                searchTermCollaborator: searchCollaboratorName,
                searchTermWorkLoad: searchWorkLoad
            });

            $.ajax({
                url: urlConfig.schedule.chartCollaboratorsTableView,
                data: parameters,
                success: function (response) {
                    if (response) {
                        // Converte o retorno em um objeto JSON
                        var result = JSON.parse(response);
                        if (result) {
                            if (result.hasSuccess) {
                                $("#divViewsArea").height(getParent().height());
                                $("#divViewsArea").empty().html(result.successResult);
                                $("#divViewsArea").find('[data-sort="' + sortByName + '"]').attr('data-order', orderByColumn);
                                if (orderByColumn === 'A' || orderByColumn === undefined) {
                                    $("#divViewsArea").find('[data-sort="' + sortByName + '"]').addClass('ordered');
                                } else {
                                    $("#divViewsArea").find('[data-sort="' + sortByName + '"]').removeClass('ordered');
                                }
                                lcmModule.registerCheckLCMScheduleEvent('divBottomArea', lcmModule.getTypes().CHART_COLLAB_TABLE);
                            } else {
                                $("#divViewsArea").empty().html(result.errorResult);
                            }
                        }
                    } else {
                        // Retorna a mensagem de erro
                        dialogModule.createDialog(0, _globalResources.getResource().ErrorTitle, _globalResources.getResource().CommunicationError);
                    }

                    scheduleModule.getBottonViewPageLoader().hide();
                }
            });
        }
    }

    function clickChangedInfo(e) {
        var enrollment = $(this).data("enrollment"),
            divInfo = getContainer().find(".line-collaborator[data-enrollment='" + enrollment + "']"),
            divMoreInfo = getContainer().find("#divUpdateTime[data-enrollment='" + enrollment + "']");

        if (divMoreInfo.is(":visible")) {
            divInfo.css({ 'border-bottom-style': '' });
            $(this).removeClass("up-arrow");
            $(this).addClass("down-arrow");

        } else {
            divInfo.css({ 'border-bottom-style': 'none' });
            $(this).removeClass("down-arrow");
            $(this).addClass("up-arrow");
        }
        divMoreInfo.toggle();
        e.stopPropagation();
    }

    //#region Register Events

    function registerEvents() {
        getContainer().find('.hasChanged').off('click').on('click', clickChangedInfo)

        //getContainer().find('.line-collaborator .table-column').not('.table-first-column').off('click').on('click', function (e) {
        //    scheduleEditCollaboratorTime.openEdit($(this).parent().data("id"), scheduleModule.getSelectedWeekDay());
        //});
    }

    //#endregion Register Events

    function init() {
        registerEvents();
        setVisibleArea();
        scrollModule.createScroll(getScrollContainer());

        getContainer().find('[data-sort]').off('click').on('click', function () {
            var order = $(this).data('order'),
                self = $(this);

            getContainer().find('[data-sort]').removeAttr('data-order');
            if (order === undefined || order === 'D') {
                self.data('order', 'A');
            } else {
                self.data('order', 'D');
            }
            scheduleModule.applySortingAndOrder(null, self.data('sort'), self.data('order'), true);
        });
    }

    return {
        init: init,
        loadView: loadView,
        myName: myName,
        setVisibleArea: setVisibleArea,
        getSelectedCollaborators: getSelectedCollaborators
    }
}();