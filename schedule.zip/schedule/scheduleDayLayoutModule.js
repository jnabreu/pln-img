var scheduleDayLayoutModule = function () {

    var _containerDiv = "day_layout_container",
        _chartContainerId = "dayChart",
        _dhxLayout = null,
        _chartElem = null;

    var _chartCell = null,
        _schedulerCell = null;

    var _layoutConfigs = {
        parent: _containerDiv,
        pattern: "2E",
        //skin: "dhx_web",
    };

    var _schedulerConfigs = {
        tabs: getSchedulerTabsHTML,
        viewName: "day_timeline",
    };

    function getSchedulerTabsHTML(label) {
        return '<div>' +
                   '<div id="validationArea"></div>' +
               '</div>' +
               '<div id="toggleOptionsMenu" class="toggleOptionsMenu">' +
                   '<span class="option-text">' +
                        _globalResources.getResource().schedule.dayView.optMenu.Options +
                  '</span> ' +
                  '<span class="option-gear"></span></div>' +
              '<div class="dhx_cal" id="dayTimelineCloseButton">&times;</div>';
    }

    function loadView(configs, isFirstTime) {
        $('#dayDataContet').show();
        $('#tabMonthData').show();
        scheduleModule.setSizeNoFooter('#' + _containerDiv);
        if (!_dhxLayout) {
            isFirstTime = true;
        }
        init(configs, isFirstTime);
    }

    function setChartDivSize(elem) {
        elem.width(_chartCell.getWidth());
        elem.height(_chartCell.getHeight() - _chartCell._getHdrHeight());
    }

    function attachLayoutEvents() {
        _dhxLayout.attachEvent("onPanelResizeFinish", onPanelResizeFinishCallback);
        _dhxLayout.attachEvent("onCollapse", onCollapseCallback);
        _dhxLayout.attachEvent("onExpand", onExpandCallback);
    }

    function updateChartSize() {
        var chartWidth = _chartCell.getWidth();
        chartHeight = _chartCell.getHeight() - _chartCell._getHdrHeight();

        setChartDivSize(_chartElem);
        _chartElem.highcharts().setSize(chartWidth, chartHeight);
        $('#dayChart').trigger('schedule.day.updateChartSize', {
            chartWidth: chartWidth,
            chartHeight: chartHeight
        });
    }

    function onPanelResizeFinishCallback(cellsArray) {
        updateChartSize();
        scheduleDayTimelineModule.applyStyles();
    }

    function onCollapseCallback(cellName) {
        if (cellName === "a") {
            updateChartSize();
            scheduleDayTimelineModule.applyStyles();
        }
    }

    function onExpandCallback(cellName) {
        if (cellName === "a") {
            updateChartSize();
            scheduleDayTimelineModule.applyStyles();
        }
    }

    function setLayoutConfigs() {
        _schedulerCell = _dhxLayout.cells("a");
        _chartCell = _dhxLayout.cells("b");

        var layoutHeight = _dhxLayout.base.clientHeight;
        var sepHeight = _dhxLayout.sep.sep.clientHeight;

        if (layoutHeight > 550) {
            var schedulerHeight = (layoutHeight * 0.6) - sepHeight
            var chartHeight = layoutHeight * 0.4;
            _schedulerCell.setHeight(schedulerHeight);
            _chartCell.setHeight(chartHeight);
        }

        _schedulerCell.setMinHeight(200);
        _schedulerCell.setText("");
        _chartCell.setMinHeight(230)
        _chartCell.setText("");
    }

    function initScheduler(configs, isFirstTime) {
        var date = configs.date;
        configs.viewName = _schedulerConfigs.viewName;

        scheduleDayTimelineModule.init(configs, isFirstTime);

        if (!isFirstTime) {
            _schedulerCell.detachObject(true);
        }
        _schedulerCell.attachScheduler(configs.date, configs.viewName,
            _schedulerConfigs.tabs(_globalResources.getResource().schedule.dayView.ToggleRests));
        scheduleDayTimelineModule.registerEvents();
    }

    function initChart(chartContainerId, configs, isFirstTime) {
        if (isFirstTime) {
            _chartCell.attachHTMLString("<div id='" + chartContainerId + "'></div>");
            _chartElem = $("#" + chartContainerId);

            setChartDivSize(_chartElem);
        }

        var events = scheduleDayTimelineModule.filterByDay(scheduler.getEvents(), configs.date);
        if (configs.chartData.length === 0) return;
        var extraChartData = scheduleMonthTimelineModule.getChartData(configs.date, "day");
        var data = scheduleDayTimelineModule.getCollaboratorsChartData(events, extraChartData, configs.granularity);
        
        scheduleDayChartModule.updateChart(_chartElem, data, true);
    }

    function init(configs, isFirstTime) {
        if (isFirstTime) {
            if (_dhxLayout) {
                $('#' + _containerDiv).find('.dhxlayout_cont').remove();
            }
            _dhxLayout = new dhtmlXLayoutObject(_layoutConfigs);
            setLayoutConfigs();
        }

        initScheduler(configs, isFirstTime);
        initChart(_chartContainerId, configs, isFirstTime);

        if (isFirstTime) {
            attachLayoutEvents();
        }
    }

    function getDhxLayout() {
        return _dhxLayout;
    }

    return {
        init: init,
        loadView: loadView,
        getDhxLayout: getDhxLayout,
    }
}();