var scheduleChangePeriodModalModule = function () {

    //#region Attributes
    var processSettings = null;
    var startDateSelected = null;
    var endDateSelected = null;
    //#endregion

    //#region Functions
    function getUnits() {
        var units = [];

        if (processSettings.units != null) {
            units.push({ ID: processSettings.units });
        }

        return units;
    }

    function getSections() {
        var sections = [];

        if (processSettings.sections != null) {
            sections.push({ ID: processSettings.sections });
        }

        return sections;
    }

    function getCollaborators() {
        var collaborators = [],
            selectedCollaborators = processSettings.collaborators;

        if (selectedCollaborators != '') {
            for (var i = 0; i < selectedCollaborators.length; i++) {
                collaborators.push({ Id: parseInt(selectedCollaborators[i]) });
            }
        }

        return collaborators;
    }
    //#endregion

    //#region Actions
    function clickCancel(e) {
        $('#change-period-modal').fadeOut();
    }

    function startDateChange() {
        startDateSelected = $('#customParameterStartDate').val();
        endDateSelected = $('#customParameterEndDate').val();
    }

    function endDateChange() {
        endDateSelected = $('#customParameterEndDate').val();
        startDateSelected = $('#customParameterStartDate').val();
    }

    function changeDates(ev) {
        $('#startDate').datepicker('setDate', startDateSelected);
        $('#endDate').datepicker('setDate', endDateSelected);
        processSettings.callback();
        $('#change-period-modal').fadeOut();
    }

    function settings(settings) {
        processSettings = settings;

        if (processSettings.startDate != undefined) {
            $('#change-period-modal #customParameterStartDate').datepicker('setDate', moment.utc(processSettings.startDate.toMSDate()).format(globalAttributes.dateInfo.dateFormat));
        }

        if (processSettings.endDate != undefined) {
            $('#change-period-modal #customParameterEndDate').datepicker('setDate', moment.utc(processSettings.endDate.toMSDate()).format(globalAttributes.dateInfo.dateFormat));
        }
 
        startDateChange();
    }
    //#endregion

    //#region Register Events
    function registerEvents() {
        customControlsModule.applyDatePickerControl(['customParameterStartDate', 'customParameterEndDate'], true, false, startDateChange, endDateChange);

        $('#divChangePeriodModal #btnProcess').off('click').on('click', changeDates);
        $('#divChangePeriodModal #btnCancel').off('click').on('click', clickCancel);
    }
    //#endregion

    //#region Init
    function init() {
        registerEvents();
    }
    //endregion

    return {
        settings: settings,
        init: init
    };
}();