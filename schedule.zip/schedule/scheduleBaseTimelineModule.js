var scheduleBaseTimelineModule = function () {
    dateNow = new Date().toUTCString();
    var _eventNames = {};

    var DEFAULT_PROPERTIES = {
        viewName: null,
        labelName: null,
        openDate: null,
        dhxContainer: null,
        linkTitle: "coisas",
        allCollaborators: [],
        schedulerConfigs: {
            xml_date: "%Y-%m-%d %h:%i",
            readonly: true,
            show_loading: true,
            check_limits: false,
            delay_render: 50,
            time_step: 5,
            xy: {
                nav_height: 60,
            }
        },
        timelineConfigs: {
            name: null,
            x_unit: "day",
            x_date: "%D",
            x_step: 1,
            x_size: 31,
            section_autoheight: false,
            y_property: "section_id",
            render: "tree",
            folder_dy: 20,
            dy: 25,
            dx: 350,
            y_unit: ['not defined'],
            round_position: true,
            second_scale: {
                x_unit: "day",
                x_date: "%d",
            },
        }
    };

    var DEFAULT_EVENT_HANDLERS = {
        onBeforeViewChangeCallback: onBeforeViewChangeCallback,
        onViewChangeCallback: onViewChangeCallback,
        updateMonthDays: updateMonthDaysDefault,
    };

    var DEFAULT_TEMPLATE_HANDLERS = {
        adjustStep: adjustStep,
        monthStart: scheduler.date.month_start,
        defineEventBarText: defineEventBarText,
        defineEventClass: defineEventClass,
        defineTimelineScaleLabelClosure: defineTimelineScaleLabelClosure,
        defineTimelineScaleDateClosure: defineTimelineScaleDateClosure,
        defineTimelineScaleSecondDateClosure: defineTimelineScaleSecondDateClosure,
        defineEventFilter: defineEventFilter,
        defineTooltipText: defineTooltipText,
    };

    var _eventHandlers = {};
    var _templatesHandlers = {};
    var _properties = {
        name: null,
        viewName: null,
        labelName: null,
        divId: null,
        openDate: null,
        allCollaborators: [],
        dhxContainer: null,
        schedulerConfigs: {},
        timelineConfigs: {},
    };

    var _selectedCollaborators = [],
        _allCollaborators = [],
        _allCollabs = [];

    var _currentContextIDs = {
        unitID: null,
        sectionID: null,
        workstationTypeID: null,
        year: null,
    };

    var _currentViewDate = null;
    var _isFirstTime = true;

    var _eventNames = {};

    function updateMonthDaysDefault(oldMode, oldDate, mode, date) {
        var year = date.getFullYear();
        var month = (date.getMonth() + 1);
        var d = new Date(year, month, 0);
        var days = d.getDate(); // numbers of day in month
        scheduler.matrix[_properties.timelineConfigs.name].x_size = days;
        return true;
    }

    function getStartAndEndDate(dateNow) {
        //var startDate = customControlsModule.getMomentDateTime([dateNow.getFullYear(), dateNow.getMonth(), 1]),
        //    endDate = customControlsModule.getMomentDateTime([dateNow.getFullYear(), dateNow.getMonth(), new Date(dateNow.getFullYear(), dateNow.getMonth() + 1, 0).getDate()]);

        var startDate = scheduleBaseTimelineModule.partsToDate(1, dateNow.getMonth(), dateNow.getFullYear());
            endDate = scheduleBaseTimelineModule.partsToDate(new Date(dateNow.getFullYear(), dateNow.getMonth() + 1, 0).getDate(), dateNow.getMonth(), dateNow.getFullYear());
            
        startDate = new Date(+startDate + Math.abs((startDate.getTimezoneOffset() * 60000)));
        endDate = new Date(+endDate + Math.abs((endDate.getTimezoneOffset() * 60000)));
            
        return {
            startDate: startDate,
            endDate: endDate,
        };
    }

    function adjustStep(date, step) {
        if (step > 0) {
            step = 1;
        } else if (step < 0) {
            step = -1;
        }
        return scheduler.date.add(date, step, "month");
    }

    function defineTooltipText(start, end, event) {
        return event.text;
    }

    function defineEventBarText(start, end, event) {
        return event.text;
    }

    function defineEventClass(start, end, event) {
        return event.type ? event.type : "";
    }

    function defineEventFilter(id, event) {
        return true;
    }

    function trimString(string, charCount, addDots) {
        var original = string;
        var cut = string.substring(0, charCount);
        var wasCut = original != cut;
        return (addDots && wasCut) ? cut + '..' : original;
    }

    function defineTimelineScaleLabelClosure(linkTitle) {
        return function (key, label, section) {
            var result = label;
            var prefix = key.substring(0, 4);
            var collabID = key.substring(4); // take id from the key;
            if (!section.open && prefix === 'COL_') {
                return '<input data-collabid="' +
                    collabID + '" type="checkbox"></input> ' +
                    '<a href="#" title="' + linkTitle + '">' + trimString(label, 38, true) + '</a>';
            }
            return result;
        };
    }

    function defineTimelineScaleDateClosure(timelineName) {
        var timeline = scheduler.matrix[timelineName];
        return function (date) {
            var func = scheduler.date.date_to_str(timeline.x_date || scheduler.config.hour_date);
            if ($.inArray(date.getDay(), [0, 6]) > -1) {
                return '<span data-timespan="' + date.getTime() + '" class="dateWeekend">' + func(date) + '</span>';
            } else {
                return '<span data-timespan="' + date.getTime() + '">' + func(date) + '</span>';
            }
            return func(date);
        }
    }

    function defineTimelineScaleSecondDateClosure(timelineName) {
        var timeline = scheduler.matrix[timelineName];
        return function (date) {
            var func = scheduler.date.date_to_str(
                (timeline.second_scale && timeline.second_scale.x_date) ?
                timeline.second_scale.x_date : scheduler.config.hour_date
            );

            // if day is sunday or saturday
            if ($.inArray(date.getDay(), [0, 6]) > -1) {
                return '<span data-timespan="' + date.getTime() + '" class="secondDateWeekend">' + func(date) + '</span>';
            } else {
                return '<span data-timespan="' + date.getTime() + '">' + func(date) + '</span>';
            }
            return func(date);
        }
    }

    function registerEvents() {
        registerClickApprovePredictedRestDays();
    }

    function checkAllClick(ev) {
        var checkboxes = $('#' + _properties.dhxContainer + ' input[type=checkbox]').not('#checkAll');
        if ($(ev.target).is(':checked')) {
            _selectedCollaborators = _allCollaborators.slice();
            checkboxes.prop('checked', true);
            $('body').trigger(_properties.dhxContainer + '.change_selected_collabs', { selectedCollabs: _selectedCollaborators });
            console.log("gSelected", _selectedCollaborators);
        } else {
            _selectedCollaborators = [];
            $('body').trigger(_properties.dhxContainer + '.change_selected_collabs', { selectedCollabs: _selectedCollaborators });
            checkboxes.prop('checked', false);
        }
    }

    function testAndApplyCheckAll(event, checkAllElem, wasChecked) {
        if (wasChecked) { // if a checkbox was checked
            var isSameLength = _selectedCollaborators.length === _allCollaborators.length;
            if (checkAllElem.is(':unchecked') && isSameLength) {
                checkAllElem.off('change');
                checkAllElem.prop('checked', true);
                checkAllElem.on('change', checkAllClick);
            }
        } else { // if a checkbox was unchecked
            if (checkAllElem.is(':checked')) {
                checkAllElem.off('change');
                checkAllElem.prop('checked', false);
                checkAllElem.on('change', checkAllClick);
            }
        }
    }

    function registerSelectCheckboxes() {
        var checkAllElem = $('#' + _properties.dhxContainer + ' #checkAll');
        if (checkAllElem.length > 0) {
            checkAllElem.off('change').on('change', checkAllClick);
        }

        var otherChecks = $('#' + _properties.dhxContainer + ' input[type=checkbox]').not('#checkAll');
        if (otherChecks.length > 0) {
            otherChecks.off('change').on('change', function (ev) {
                if ($(this).is(':checked')) {
                    var collabID = $(this).data('collabid').toString();
                    addToSelectedCollaborators(collabID);
                    testAndApplyCheckAll(ev, checkAllElem, true);
                } else if ($(this).is(':unchecked')) {
                    var collabID = $(this).data('collabid').toString();
                    removeFromSelectedCollaborators(collabID);
                    testAndApplyCheckAll(ev, checkAllElem, false);
                } else {
                    console.error("Couldn't perform select operation");
                }
                $('body').trigger(_properties.dhxContainer + '.change_selected_collabs', { selectedCollabs: _selectedCollaborators });
                console.log("gSelected", _selectedCollaborators);
            });
        }
    }

    function addToSelectedCollaborators(collabID) {
        if ($.inArray(collabID, _selectedCollaborators) === -1) {
            _selectedCollaborators.push(collabID);
            return true;
        } else {
            return false;
        }
    }

    function removeFromSelectedCollaborators(collabID) {
        if ((index = $.inArray(collabID, _selectedCollaborators)) > -1) {
            _selectedCollaborators.splice(index, 1);
            return true;
        } else {
            return false;
        }
    }

    function existsOnSelectedCollaborators(collabID) {
        if ($.inArray(collabID, _selectedCollaborators) > -1) {
            return true;
        } else {
            return false;
        }
    }

    function registerClickCollaborator(clickCallback) {
        var selector = $('#' + _properties.dhxContainer + ' input[type=checkbox]').not('#checkAll').next();
        selector.off('click').on('click', clickCallback);
    }

    function fromYearToTimeline() {
        $('#restYearContent').hide().height('0');
        $('#tabRest #divRestButtonsArea #divMarkApprove').hide();
        $('#tabRest #divRestButtonsArea #btnApproveRest').show();
        setSize('#restTimelineContent');
        $('#restTimelineContent').show();
        scheduleModule.showDropdowns(true, true, true, false, false, false);
        scheduleModule.enableDropdowns(true, true, false, false, false, false);
    }

    function closeButtonCallback() {
        fromYearToTimeline();
        init(null, false, _currentViewDate);
        scheduler.updateView();
        onViewChangeCallback();
    }

    function gotoTimelineCallback(event) {
        var openDate = new Date($(this).data('gototimeline'));
        fromYearToTimeline();
        init(null, false, openDate);
        scheduler.updateView();
        onViewChangeCallback();
    }

    function openCollaboratorYearlyView(event) {
        setSize('#restYearContent');
        $('#restTimelineContent').hide().height(0);
        scheduleModule.getMainPageLoader().show();
        $('#tabRest #divRestButtonsArea #btnApproveRest').hide();
        $('#tabRest #divRestButtonsArea #divMarkApprove').show();
        var collabID = $(this).prev().data('collabid');
        var year = new Date().getFullYear();
        var filteredList = $.grep(_allCollabs, function (elem) {
            if (parseInt(elem.id) === collabID) {
                return true;
            }
        });
        var name = filteredList[0].name;
        var collab = { id: collabID, name: name };
        scheduleRestDaysYearModule.loadSchedule(collab, year);
    }

    function setSizeNoFooter(divId) {
        var calcHeight = $('#divRestButtonsArea').offset().top -
            ($('#scheduleHeader').offset().top + $('#scheduleHeader').height());
        $(divId).height(calcHeight + 'px');
    }

    function refreshTimelineView() {
        var ctx = _currentContextIDs;
        loadMainScheduleView(ctx.unitID, ctx.sectionID, ctx.workstationTypeID, ctx.year);
    }

    function registerClickApprovePredictedRestDays() {
        $('#tabRest #divRestButtonsArea #btnApproveRest').off('click').on('click', function (ev) {
            scheduleEventsModule.approveCollaboratorsRest(_selectedCollaborators, refreshTimelineView);
        });
    }

    function applyCheckboxes() {
        $.map(_selectedCollaborators, function (elem, index) {
            var checkbox = $('#' + _properties.dhxContainer + ' input[type=checkbox][data-collabid="' + elem + '"]');
            checkbox.prop('checked', true);
        });

        if (_selectedCollaborators.length > 0 &&
            _selectedCollaborators.length === _allCollaborators.length) {
            $('#' + _properties.dhxContainer + ' input[type=checkbox]#checkAll').prop('checked', true);
        }
    }

    function appendSelectAllDiv() {
        var selectAllLabel = _globalResources.getResource().schedule.SelectAll;
        $('#' + _properties.dhxContainer + ' .dhx_cal_header #selectAll').remove();
        $('#' + _properties.dhxContainer + ' .dhx_cal_header')
            .prepend('<div id="selectAll"><input id="checkAll" type="checkbox" /> <label for="checkAll">' +
                selectAllLabel + '</label></div>');
    }

    function applyStylesToWeekendsScaleBar(styles) {
        $('#' + _properties.dhxContainer + ' .dateWeekend').parent().css(styles);
        $('#' + _properties.dhxContainer + ' .secondDateWeekend').parent().css(styles);
    }

    function applyStylesToWeekendsColumns(styles) {
        var weekendIndexes = [];
        $('#' + _properties.dhxContainer + ' .dhx_scale_bar.dhx_second_scale_bar').filter(function (index, elem) {
            if ($(elem).find('.secondDateWeekend').hasClass('secondDateWeekend')) {
                weekendIndexes.push(index);
            }
        });
        var rows = $('#' + _properties.dhxContainer + ' .dhx_cal_data .dhx_row_item td').not('.dhx_matrix_scell').find('.dhx_data_table tbody tr');
        $.map(rows, function (elem) {
            $(elem).find('td').filter(function (index) {
                return $.inArray(index, weekendIndexes) > -1;
            }).css(styles);
        });
    }

    function applySelectAllStyles() {
        var selectAllStyles = {
            float: "left",
            width: "200px",
            margin: "3px 10px 0",
            position: "relative",
        },
        selectAllInputStyles = {
            "margin-top": "8px",
            "float": "left",
            "width": "20px",
            "vertical-align": "middle",
        },
        scellStyles = {
            "background": "rgba(200, 200, 200, 0.30)",
        };

        $('#' + _properties.dhxContainer + ' #selectAll').css(selectAllStyles);
        $('#' + _properties.dhxContainer + ' #selectAll input[type=checkbox]').css(selectAllInputStyles);
        $('#' + _properties.dhxContainer + ' .dhx_scell_name').css('color', '#333');
        $('#' + _properties.dhxContainer + ' .dhx_scell_name a').css('color', 'rgba(31, 31, 31, 0.86');
        $('#' + _properties.dhxContainer + ' .dhx_row_folder .dhx_matrix_scell.folder').css(scellStyles);
        $('#' + _properties.dhxContainer + ' .dhx_row_folder .dhx_matrix_cell').css(scellStyles);
    }

    function applyMiscStyles() {
        var matrixCells = $('#' + _properties.dhxContainer + ' .dhx_matrix_cell');
        if (matrixCells.length > 0) {
            var matrixCellWidth = $(matrixCells[0]).width();
        }

        var centerStyles = {
            "width": Math.floor(0.90 * matrixCellWidth) + "px",
            "padding-left": "0",
            "text-align": "center",
            "font-size": "9px",
        }
        
        var sizeStyles = {
            "font-size": "0.8em",
            "line-height": "95%",
            "letter-spacing": "-0.1px",
        };

        $('#' + _properties.dhxContainer + ' .dhx_cal_event_line').css(centerStyles);
        $('#' + _properties.dhxContainer + ' .T_T').css(sizeStyles);
        $('#' + _properties.dhxContainer + ' .T_T_A').css(sizeStyles);
    }

    function applyStylesToWeekends() {
        var scaleBarStyles = { 'background': 'rgb(169,169,169)', 'color': 'white' };
        var columnsStyles = { 'background': 'rgb(169,169,169)' };
        applyStylesToWeekendsScaleBar(scaleBarStyles);
        applyStylesToWeekendsColumns(columnsStyles);
    }

    function applyAllStyles() {
        applySelectAllStyles();
        applyStylesToWeekends();
        applyMiscStyles();
        fixSizes();
    }

    function fixSizes(limit, offset) {
        limit = typeof limit !== 'undefined' ? limit: 40;
        offset = typeof offset !== 'undefined' ? offset : 20;
        
        var container = '#' + _properties.dhxContainer;

        if (scheduler.xy.scale_height >= limit) {
            var divHeader = $('.dhx_cal_header');
            var headerHeight = parseInt(divHeader.css('height'), 10);

            if (headerHeight > limit) {
                $('.dhx_cal_header').css('height', (2* offset) + 'px');
                var scales = $(container + ' #selectAll').siblings();
                $(scales[0]).css('height', offset + 'px');
                var divData = $(container + ' .dhx_cal_data');
                var dataHeight = parseInt(divData.css('height'), 10);
                var dataTop = parseInt(divData.css('top'), 10);

                divData.css({
                  height: (dataHeight + (2 * offset)) + 'px',
                  top: (dataTop - (2 * offset)) + 'px'
                });
            } 
        }
    }

    function onBeforeViewChangeCallback(oldMode, oldDate, mode, date) {
        _eventHandlers.updateMonthDays(oldMode, oldDate, mode, date);
        clearAllCheck();
        return true;
    }
    
    function clearAllCheck() {
        var checkboxes = $('#' + _properties.dhxContainer + ' input[type=checkbox]');
        checkboxes.prop('checked', false);

        checkboxes = $('#' + _properties.dhxContainer + ' input[type=checkbox]').not('#checkAll');
        
        if (checkboxes.length > 0){
            for (var i = 0; i < checkboxes.length; i++) {
                var checkbox = checkboxes[i];
                var collabID = checkbox.getAttribute("data-collabid").toString();
                removeFromSelectedCollaborators(collabID);
            }
        }
    }

    function onViewChangeCallback(newMode, newDate) {
        appendSelectAllDiv();
        registerSelectCheckboxes();
        // registerClickCollaborator();
        applyCheckboxes();
        applyAllStyles();
        console.log("BASE: on view change");
    }

    function setSchedulerConfigs(schedulerConfigs) {
        _properties.schedulerConfigs = _properties.schedulerConfigs || {};

        _properties.schedulerConfigs.xml_date = schedulerConfigs.xml_date || DEFAULT_PROPERTIES.schedulerConfigs.xml_date;
        _properties.schedulerConfigs.readonly = ((schedulerConfigs.readonly != undefined) ? schedulerConfigs.readonly: DEFAULT_PROPERTIES.schedulerConfigs.readonly);
        _properties.schedulerConfigs.show_loading = ((schedulerConfigs.show_loading != undefined) ? schedulerConfigs.show_loading: DEFAULT_PROPERTIES.schedulerConfigs.show_loading);
        _properties.schedulerConfigs.check_limits = ((schedulerConfigs.check_limits != undefined) ? schedulerConfigs.check_limits: DEFAULT_PROPERTIES.schedulerConfigs.check_limits);
        _properties.schedulerConfigs.delay_render = schedulerConfigs.delay_render || DEFAULT_PROPERTIES.schedulerConfigs.delay_render;
        _properties.schedulerConfigs.time_step = schedulerConfigs.time_step || DEFAULT_PROPERTIES.schedulerConfigs.time_step;
        _properties.schedulerConfigs.xy = schedulerConfigs.xy || DEFAULT_PROPERTIES.schedulerConfigs.xy;
    }

    function setTimelineConfigs(timelineConfigs) {
        var defaultConfigs = DEFAULT_PROPERTIES.timelineConfigs;
        _properties.timelineConfigs = _properties.timelineConfigs || {};
        for (key in defaultConfigs) {
            _properties.timelineConfigs[key] = timelineConfigs[key] || defaultConfigs[key];
        }
    }

    function setProperties(properties) {
        _properties = _properties || {};

        _properties.name = properties.name;
        _properties.viewName = properties.viewName;
        _properties.labelName = properties.labelName;
        _properties.openDate = properties.openDate;
        _properties.allCollaborators = properties.allCollaborators;
        _properties.dhxContainer = properties.dhxContainer;
        _properties.linkTitle = properties.linkTitle;

        properties.schedulerConfigs = properties.schedulerConfigs || {};
        properties.timelineConfigs = properties.timelineConfigs || {};

        setSchedulerConfigs(properties.schedulerConfigs);
        properties.timelineConfigs.name = properties.viewName;
        setTimelineConfigs(properties.timelineConfigs);
    }

    function setDHXProperties() {
        scheduler.config.xml_date = _properties.schedulerConfigs.xml_date;
        scheduler.config.readonly = _properties.schedulerConfigs.readonly;
        scheduler.config.show_loading = _properties.schedulerConfigs.show_loading;

        for (var key in _properties.schedulerConfigs.xy) {
            scheduler.xy[key] = _properties.schedulerConfigs.xy[key];
        }

        scheduler.locale = dhtmlxSchedulerLocale.getDHTMLXLocale();
        scheduler.locale.labels[_properties.viewName + '_tab'] = _properties.viewLabel;
    }

    function setEventHandlers(eventHandlers) {
        _eventHandlers = {};
        _eventHandlers.onBeforeViewChangeCallback = eventHandlers.onBeforeViewChangeCallback || DEFAULT_EVENT_HANDLERS.onBeforeViewChangeCallback;
        _eventHandlers.onViewChangeCallback = eventHandlers.onViewChangeCallback || DEFAULT_EVENT_HANDLERS.onViewChangeCallback;
        _eventHandlers.updateMonthDays = eventHandlers.updateMonthDays || DEFAULT_EVENT_HANDLERS.updateMonthDays;
    }

    function detachEvents() {
        $('#tabMonthData').trigger('detachEvents');
    }

    var _viewChangeEvent = null;
    function attachEvents() {

        $('#tabMonthData')
            .off('detachEvents')
            .on('detachEvents', function (ev) {
                for (key in _eventNames) {
                    scheduler.detachEvent(_eventNames[key]);
                }
            });

        _eventNames.onBeforeViewChangeEv = scheduler.attachEvent("onBeforeViewChange", _eventHandlers.onBeforeViewChangeCallback);
        _eventNames.onViewChangeEv = scheduler.attachEvent("onViewChange", _eventHandlers.onViewChangeCallback);
        _eventNames.onSchedulerResizeEv = scheduler.attachEvent("onSchedulerResize", _eventHandlers.onViewChangeCallback);
    }

    function setTemplatesHandlers(templatesHandlers) {
        _templatesHandlers = {};

        _templatesHandlers.adjustStep = templatesHandlers.adjustStep || DEFAULT_TEMPLATE_HANDLERS.adjustStep;
        _templatesHandlers.monthStart = templatesHandlers.monthStart || DEFAULT_TEMPLATE_HANDLERS.monthStart;
        _templatesHandlers.defineEventBarText = templatesHandlers.defineEventBarText || DEFAULT_TEMPLATE_HANDLERS.defineEventBarText;
        _templatesHandlers.defineEventClass = templatesHandlers.defineEventClass || DEFAULT_TEMPLATE_HANDLERS.defineEventClass;
        _templatesHandlers.defineTimelineScaleLabelClosure = templatesHandlers.defineTimelineScaleLabelClosure || DEFAULT_TEMPLATE_HANDLERS.defineTimelineScaleLabelClosure;
        _templatesHandlers.defineTimelineScaleDateClosure = templatesHandlers.defineTimelineScaleDateClosure || DEFAULT_TEMPLATE_HANDLERS.defineTimelineScaleDateClosure;
        _templatesHandlers.defineTimelineScaleSecondDateClosure = templatesHandlers.defineTimelineScaleSecondDateClosure || DEFAULT_TEMPLATE_HANDLERS.defineTimelineScaleSecondDateClosure;
        _templatesHandlers.defineEventFilter = templatesHandlers.defineEventFilter || DEFAULT_TEMPLATE_HANDLERS.defineEventFilter;
        _templatesHandlers.defineTooltipText = templatesHandlers.defineTooltipText || DEFAULT_TEMPLATE_HANDLERS.defineTooltipText;
    }

    function handleTemplates(viewName, linkTitle) {
        scheduler.date['add_' + viewName] = _templatesHandlers.adjustStep
        scheduler.date[viewName + '_start'] = _templatesHandlers.monthStart;
        // setDhtmlxTooltipConfigs();
        scheduler.templates.tooltip_text = _templatesHandlers.defineTooltipText;
        scheduler.templates.event_bar_text = _templatesHandlers.defineEventBarText;
        scheduler.templates.event_class = _templatesHandlers.defineEventClass;
        scheduler.templates[viewName + '_scale_label'] = _templatesHandlers.defineTimelineScaleLabelClosure(linkTitle);
        scheduler.templates[viewName + '_scale_date'] = _templatesHandlers.defineTimelineScaleDateClosure(viewName);
        scheduler.templates[viewName + '_second_scale_date'] = _templatesHandlers.defineTimelineScaleSecondDateClosure(viewName);
        scheduler['filter_' + viewName] = _templatesHandlers.defineEventFilter;
        //scheduler.showLightbox = function (id) { /* do not show lightbox */ };
    }

    function setSettings(settings) {
        var properties = settings.properties || {},
            methods = settings.methods || {},
            templatesHandlers = settings.templatesHandlers || {},
            eventHandlers = settings.eventHandlers || {},
            schedulerConfigs = settings.properties.schedulerConfigs || {};
        
        setSchedulerConfigs(schedulerConfigs);
        setProperties(properties);
        setEventHandlers(eventHandlers);
        setTemplatesHandlers(templatesHandlers);
    }

    function init(settings) {
        setSettings(settings);

        // TODO: remove _allCollaborators and rename _allCollabs to _allCollaborators
        _allCollabs = _properties.allCollaborators;
        _allCollaborators = $.map(_allCollabs, function (elem) { return elem.id.toString(); });

        setDHXProperties();
        scheduler.createTimelineView(_properties.timelineConfigs);
        detachEvents();
        attachEvents();
        handleTemplates(_properties.viewName, _properties.linkTitle);

        scheduler.init(_properties.dhxContainer, _properties.openDate, _properties.viewName);
    }

    function addData(collabEvents) {
        scheduler.parse(collabEvents, "json");
    }

    function getProperties() {
        return _properties;
    }

    function getEventHandlers() {
        return _eventHandlers;
    }

    function getTemplatesHandlers() {
        return _templatesHandlers;
    }

    function getDefaultProperties() {
        return DEFAULT_PROPERTIES;
    }

    function getDefaultEventHandlers() {
        return DEFAULT_EVENT_HANDLERS;
    }

    function getDefaultTemplatesHandlers() {
        return DEFAULT_TEMPLATE_HANDLERS;
    }

    function getLocalEvents() {
        return _eventNames;
    }

    function partsToDate(_day, _month, _year) {
        var formatedDate = new Date(_year, _month, _day);
        return formatedDate;
    }

    function stringToDate(_date, _format, _delimiter) {
        var formatLowerCase = _format.toLowerCase();
        var formatItems = formatLowerCase.split(_delimiter);
        var dateItems = _date.split(_delimiter);
        var monthIndex = formatItems.indexOf("mm");
        var dayIndex = formatItems.indexOf("dd");
        var yearIndex = formatItems.indexOf("yyyy");
        var month = parseInt(dateItems[monthIndex]);
        month -= 1;
        var formatedDate = new Date(dateItems[yearIndex], month, dateItems[dayIndex]);
        return formatedDate;
    }

    return {
        init: init,
        addData: addData,
        clearAllCheck: clearAllCheck,
        getProperties: getProperties,
        getLocalEvents: getLocalEvents,
        getEventHandlers: getEventHandlers,
        getTemplatesHandlers: getTemplatesHandlers,
        getStartAndEndDate: getStartAndEndDate,
        getDefaultProperties: getDefaultProperties,
        getDefaultEventHandlers: getDefaultEventHandlers,
        getDefaultTemplatesHandlers: getDefaultTemplatesHandlers,
        registerClickCollaborator: registerClickCollaborator,
        partsToDate: partsToDate,
        stringToDate: stringToDate,
    };
}();