var scheduleChartCollaboratorModule = function () {

    var BOTTOM_ADDITIONAL_HEIGHT = 40;

    //#region Helpers
    function getContainer() {
        return $("#divViewsArea");
    }

    function getContainerScroll() {
        return $("#divChartScroll");
    }

    function myName() {
        return "view-chart-collaborator";
    }

    function getSelectedCollaborators(allOfThem) {
        var listStructureModel = [];
        if (scheduleModule.isCurrentDataTab() && scheduleModule.getSelectedView() == myName()) {

            if (allOfThem) {
                getContainer().find("input[type='checkbox']").each(function (index) {
                    listStructureModel.push(new Number(this.value));
                });
            } else {
                getContainer().find("input[type='checkbox']:checked").each(function (index) {
                    listStructureModel.push(new Number(this.value));
                });
            }
        }
        return listStructureModel;
    }
    //#endregion

    //#region Chart Helpers
    function hasProperty(nameProperty) {
        if (typeof nameProperty === "undefined") {
            return false;
        } else {
            return true;
        }
    }

    function getHoursInterval(beginHourInterval, endHourInterval) {
        var formatField = scheduleModule.getSectionParent().find('#hdnMomentFormatTime'),
            begin = beginHourInterval.toDefaultMomentDate(),
            end = endHourInterval.toDefaultMomentDate();

        var diff = end.diff(begin, 'hours', true); //true é necessário para calcular minutos (1.5=1h30, 0.25=15m por exemplo)
        return diff;
    }

    function colorLuminance(hex, lum) {

        // validate hex string
        hex = String(hex).replace(/[^0-9a-f]/gi, '');
        if (hex.length < 6) {
            hex = hex[0] + hex[0] + hex[1] + hex[1] + hex[2] + hex[2];
        }
        lum = lum || 0;

        // convert to decimal and change luminosity
        var rgb = "#", c, i;
        for (i = 0; i < 3; i++) {
            c = parseInt(hex.substr(i * 2, 2), 16);
            c = Math.round(Math.min(Math.max(0, c + (c * lum)), 255)).toString(16);
            rgb += ("00" + c).substr(c.length);
        }

        return rgb;
    }

    function getWorkstationName(item) {
        var name = "";
        if (hasProperty(item.WorkstationTypeName))
            name = item.WorkstationTypeName;

        if (hasProperty(item.WorkstationName))
            name += " - " + item.WorkstationName;

        return name;
    }

    function formatOnlyTime(dateTime) {
        var formatField = scheduleModule.getSectionParent().find('#hdnMomentFormatTime'),
            newDate = dateTime.toDefaultMomentDate().format(formatField.val());

        return newDate;
    }

    function formatWorkHours(itemColab) {
        var culture = globalAttributes.userlanguage;
        var beginWork = formatOnlyTime(itemColab.BeginHourWork);
        var endWork = formatOnlyTime(itemColab.EndHourWork);
        var beginInteval = "";
        var endInterval = "";

        if (typeof itemColab.BeginHourInterval === "undefined") {
            return beginWork + " " + _globalResources.getResource(culture).schedule.chartCollaborators.Until + " " + endWork;
        }
        if (typeof itemColab.EndHourInterval === "undefined") {
            return beginWork + " " + _globalResources.getResource(culture).schedule.chartCollaborators.Until + " " + endWork;
        }

        beginInteval = formatOnlyTime(itemColab.BeginHourInterval);
        endInterval = formatOnlyTime(itemColab.EndHourInterval);

        return beginWork + " " + _globalResources.getResource(culture).schedule.chartCollaborators.Until + " " + beginInteval + " - " + endInterval + " " + _globalResources.getResource(culture).schedule.chartCollaborators.Until + " " + endWork;
    }

    function calculatePositionToolTip(mainArea, toolTipParent, toolTip) {
        var mainAreaTop = mainArea.offset().top,
            mainAreaWidth = mainArea.scrollLeft() + mainArea[0].clientWidth,
            mainAreaLeftLimit = mainArea.scrollLeft(),

            toolTipParentLeft = parseInt(toolTipParent.css('left').replace('px', '')), //  toolTipParent.offset().left,
            toolTipParentTop = toolTipParent.offset().top,
            toolTipParentWidth = toolTipParent.width(),

            toolTipWidth = toolTip.width(),
            toolTipHeight = toolTip.height(),

            bkg_color = toolTip.data('bkgColor'),
            border_color = toolTip.data('borderColor'),
            changedTop = false;

        var cssSettings = {
            top: -75,
            left: 10,
            position: 'absolute'
        };
        var top = -75;

        // Se a altura do Top do pai da tooltip, ou seja, da div no gráfico, menos a altura da tooltip for menor que o top da área destinada ao gráfico, 
        // significa que essa div está no top da área do gráfico e a tooltip não conseguira ser apresentada
        if ((toolTipParentTop - toolTipHeight) < mainAreaTop) {
            changedTop = true;
            cssSettings.top = 30;

            toolTip.find("#tail1").removeClass("arrow-down").addClass("arrow-up").css({ "border-color": "transparent transparent " + border_color });
            toolTip.find("#tail2").removeClass("arrow-down1").addClass("arrow-up1").css({ "border-color": "transparent transparent " + bkg_color });
        }
        else {
            toolTip.find("#tail1").removeClass("arrow-up").addClass("arrow-down").css({ "border-color": border_color + " transparent transparent transparent" });
            toolTip.find("#tail2").removeClass("arrow-up1").addClass("arrow-down1").css({ "border-color": bkg_color + " transparent transparent transparent" });
        }

        //Se a extremidade esquerda está antes do limite esquerdo definido pelo scroll, então temos que ajustar para ficar um pouquinho depois do início da área visível
        if (toolTipParentLeft < mainAreaLeftLimit) {
            cssSettings.left = ((mainAreaLeftLimit - toolTipParentLeft) + 10);

            var tailPosition = 0;
            toolTip.find("#tail1").css({ left: tailPosition });
            toolTip.find("#tail2").css({ left: tailPosition });
        } else {
            var tailPosition = 30;
            if ((toolTipParentLeft + toolTipParentWidth) < (toolTipParentLeft + tailPosition + 20))
                tailPosition = 0;
            toolTip.find("#tail1").css({ left: tailPosition });
            toolTip.find("#tail2").css({ left: tailPosition });
        }

        // Se a largura da ToolTip com a soma da posição Left do pai da mesma, for maior que a largura da área do gráfico com a soma do deslocamento a esquerda,
        // significa que a tooltip ficará fora da área de exibição
        if ((toolTipParentLeft + toolTipWidth) >= (mainAreaWidth)) {
            cssSettings.left = ((toolTipWidth - (mainAreaWidth - toolTipParentLeft)) + 10) * -1;

            var tailPosition = toolTipWidth - (mainAreaWidth - toolTipParentLeft),
                tailWidth = parseInt(toolTip.find("#tail1").css('width'));

            if (tailPosition + 20 + tailWidth <= toolTipWidth) {
                tailPosition += 20;
            }

            toolTip.find("#tail1").css({ left: tailPosition });
            toolTip.find("#tail2").css({ left: tailPosition });

            if (changedTop === false) {
                toolTip.find("#tail1").css({ "border-color": border_color + " transparent transparent transparent" });
                toolTip.find("#tail2").css({ "border-color": bkg_color + " transparent transparent transparent" });
            }
        }

        return cssSettings;
    }
    //#region

    //#region Create Chart
    function createChart(date, collaboratorData, hours) {
        var divContainerScroll = $('<div id="divChartScroll" class="chart-employee-scroll"></div>'),
            width = parseInt(getContainer().parent().width()),
            height = parseInt(getContainer().parent().height());

        // Configura container do scroll
        divContainerScroll.height(getContainer().height());
        divContainerScroll.width(getContainer().width());

        var divHoursBar = createHour(hours, width, height);

        divContainerScroll.empty();
        getContainer().empty().append(divContainerScroll).append(divHoursBar);

        var divInfo = createInfoCollaborator(date, collaboratorData, height);
        divContainerScroll.empty().append(divInfo);

        scrollModule.createScroll('divChartScroll');
        scrollToBottom(divContainerScroll);
    }

    function createHour(hours, width, height) {
        var divHoursBar = $('<div class="hour-area"></div>'),
            ulElement = $("<ul></ul>"),
            topHoursBar = ((getContainer().scrollTop() + getContainer()[0].clientHeight) - (divHoursBar.get(0).offsetHeight)) - $('#divButtonsArea').height();

        if (hours == null || hours.length == 0) {
            return divHoursBar;
        }

        // Preenche a barra de horários com as horas
        $(hours).each(function (index) {
            ulElement.append('<li style="width: ' + Math.round(height / $(hours).length) + 'px">' + this + '</li>');
        });

        divHoursBar.append(ulElement);
        divHoursBar.css('top', topHoursBar + 'px');
        divHoursBar.css('width', width + 'px');

        return divHoursBar;
    }

    function createInfoCollaborator(date, collaboratorData, height) {
        var formatField = scheduleModule.getSectionParent().find('#hdnMomentFormatTime'),
            divInfo = $('<div class="info-area"></div>'),
            arrayIndex = [],
            line = 1,
            lastValueLine = 1,
            maskDefault = 'YYYY/MM/DD HH:mm:ss';

        // Percorre as informações dos colaboradores
        $(collaboratorData).each(function (index) {
            var item = this,
                found = false;
            //console.log('ID: ' + item.CollaboratorID + ' TP: ' + item.IsPolyvalent + ' Sec: ' + item.IsSectionPolyvalent);
            // Percorre o array de posições para determinar qual a linha a ser utilizada
            $(arrayIndex).each(function (index) {
                if (new Date(moment.utc(arrayIndex[index]).format(maskDefault)).getTime() == new Date(moment.utc(item.BeginHourWork).format(maskDefault)).getTime()) {
                    line = index;
                    found = true;
                    return false;
                }
            });

            if (!found) {
                $(arrayIndex).each(function (index) {
                    if (new Date(moment.utc(item.BeginHourWork).format(maskDefault)).getTime() >= new Date(moment.utc(arrayIndex[index]).format(maskDefault)).getTime()) {
                        line = index;
                        found = true;
                        return false;
                    } else {
                        line = lastValueLine;
                    }
                });
            }

            var startPosition;
            if(typeof($('.hour-area').find('li:contains("' + formatOnlyTime(item.BeginHourWork) + '")').position()) == 'undefined')
            {
                startPosition = 0;
            }
            else {
                startPosition = $('.hour-area').find('li:contains("' + formatOnlyTime(item.BeginHourWork) + '")').position().left;
            }

            // Prevents the table view from not loading if a schedule out of range error occurs.
            var endPosTmp1 = $('.hour-area').find('li:contains("' + formatOnlyTime(item.EndHourWork) + '")');
            if (endPosTmp1) {
                endPosTmp2 = endPosTmp1.position();
                if (endPosTmp2) {
                    endPosition = endPosTmp2.left;
                }
                else {
                    endPosition = 2000;
                }
            }

            var workstationTypeColor = "#fff";

            if (hasProperty(item.WorkstationTypeColor)) {
                workstationTypeColor = item.WorkstationTypeColor;
            }

            var divInterval = "";
            if (item.PositionIntervalID > 0) {
                var firstPosition = $('.hour-area').find('li:eq(0)').position().left,
                    startMealPosition = $('.hour-area').find('li:contains("' + formatOnlyTime(item.BeginHourInterval) + '")').position().left - (startPosition - firstPosition),
                    endMealPosition = $('.hour-area').find('li:contains("' + formatOnlyTime(item.EndHourInterval) + '")').position().left - (startPosition - firstPosition);

                divInterval = "<div class='intervalInfo' " +
                                    "style='width:" + (endMealPosition - startMealPosition) + "px; " +
                                           "left: " + startMealPosition + "px;" +
                                           (item.IsSectionPolyvalent || item.IsPolyvalent ? "border-bottom: solid 2px red; border-top: solid 2px red;" : "border-bottom: solid 1px black; border-top: solid 1px black;") +
                                           "background-color: " + colorLuminance(workstationTypeColor, -0.2) + ";'></div>"
            }

            var divSituation = "";
            if (hasProperty(item.Situation)) {
                divSituation = "<div class='statusColab_" + item.Situation + "'></div>";
            }

            var div = "<div id='js-info_" + item.Enrollment + "' " +
                            "class='boxInfo' style='width: " + (endPosition - startPosition) + "px; " +
                                             "left: " + startPosition + "px; " +
                                             "bottom: " + ((line * 20) + BOTTOM_ADDITIONAL_HEIGHT) + "px; " +
                                             (item.IsSectionPolyvalent || item.IsPolyvalent ? "border: solid 2px red;" : "") +
                                             "background-color:" + workstationTypeColor + "; '" +
                                             "name='js-" + item.Enrollment + "' " +
                                             ">" +
                            "<div class='checkbox-area'>" +
                                "<input type='checkbox' " +
                                       "name='" + item.CollaboratorID + "'" +
                                       "value='" + item.CollaboratorID + "'" +
                                "/>" +
                            "</div>" +
                            "<div class='collaboratorInfo' data-id='" + item.CollaboratorID + "'>" + (item.Enrollment ? item.Enrollment + ' - ' : '') +
                            item.CollaboratorName +
                            (!isNaN(item.Adaptability) ? " (<span class='collaboratorAdapt'>" + item.Adaptability + "</span>)" : "") + "</div>" +
                            divInterval +
                            divSituation +

                            "<div id='divMoreInfo' " +
                                "name='js-more" + item.Enrollment + "'" +
                                 "data-bkg-color='" + workstationTypeColor + "' " +
                                 "data-border-color='" + (item.IsSectionPolyvalent || item.IsPolyvalent ? "red" : "black") + "' " +
                                 "style='z-index: 1000; " +
                                      "background-color:" + workstationTypeColor + ";" +
                                       (item.IsSectionPolyvalent || item.IsPolyvalent ? "border: solid 2px red;" : "") +
                                 "'" +
                                 "class='boxToolTip_Hidden'>" +
                                    "<div class='box-tool-tip'>" +
                                        (!isNaN(item.Enrollment) ? "<strong>" + item.Enrollment + "</strong> - " : '') + item.CollaboratorName +
                                        (!isNaN(item.Adaptability) ? " - <strong>Adapt: " + item.Adaptability + "</strong>" : '') +
                                    "</div>" +
                                     divSituation +
                                    "<p>" + formatWorkHours(item) + " - " + formatOnlyTime(item.DailyWorkLoad) + "h/" + item.WeeklyWorkLoad + "h</p>" +
                                    "<p>" + getWorkstationName(item) + "</p>" +
                                    "<div id='tail1' class='arrow-down' style='border-color:" + (item.IsSectionPolyvalent || item.IsPolyvalent ? "red" : "black") + " transparent transparent transparent;'></div>" +
                                    "<div id='tail2' class='arrow-down1' style='border-color:" + workstationTypeColor + " transparent transparent transparent;'></div>" +
                            "</div>" +

                      "</div>";

            arrayIndex[line] = item.EndHourWork;

            if (!found)
                lastValueLine++;

            divInfo.append(div);

        });

        // Hover
        divInfo.find(".boxInfo").each(function (index) {
            $(this).off();
            $(this).hover(function (e) {

                var divMoreInfo = $(this).find('#divMoreInfo');
                // Deixa visivel essa div de mais informações
                divMoreInfo.removeClass("boxToolTip_Hidden").addClass("boxToolTip");
                divMoreInfo.css(calculatePositionToolTip(getContainer(), $(this), divMoreInfo));

                // Hightlights para destacar o objeto 
                $(this).css({ opacity: 1 });

            }, function () {
                // Deixa invisivel a div de mais informações
                $(this).find('#divMoreInfo').removeClass("boxToolTip").addClass("boxToolTip_Hidden");

                // Volta com a opacidade no objeto
                $(this).css({ opacity: 0.7 });
            });
        });

        // Configura largura e altura do container
        var newHeight = arrayIndex.length * 21;
        if (newHeight > height) {
            divInfo.height(newHeight + BOTTOM_ADDITIONAL_HEIGHT);
        }
        else {
            divInfo.css('height', height);
        }

        // Click de edição
        //divInfo.find(".collaboratorInfo").off('click').on('click', function (e) {
        //    scheduleEditCollaboratorTime.openEdit($(this).data("id"), date);
        //    e.stopPropagation();
        //});

        return divInfo;
    }
    //#endregion

    //#region Load Datas
    function loadView(unitID, sectionID, workstationTypeID, date, searchTermCollaborator, searchTermWorkLoad) {
        if (scheduleModule.isCurrentDataTab() && scheduleModule.getSelectedView() == myName()) {

            scheduleModule.getBottonViewPageLoader().show();

            getContainer().height(getContainer().parent().height());
            getContainer().width(getContainer().parent().width());

            var workstationTypeIDsToInt = [];
            if ($("#ddlWorkstationType").val() != null && $("#ddlWorkstationType").val() != "") {
                workstationTypeIDsToInt = $("#ddlWorkstationType").val().map(function (item) {
                    return parseInt(item, 10);
                });
            }

            //Serealiza parametros
            var parameters = JSON.stringify({
                sectionID: sectionID,
                workstationTypeID: workstationTypeIDsToInt,
                date: date.toMSDate(),
                searchTermCollaborator: searchTermCollaborator,
                searchTermWorkLoad: searchTermWorkLoad
            });

            $.ajax({
                url: urlConfig.schedule.chartCollaborators,
                data: parameters,
                success: function (response) {
                    if (response) {
                        // Converte o retorno em um objeto JSON
                        var result = JSON.parse(response);
                        if (result) {
                            if (result.hasSuccess) {
                                createChart(date, result.successResult.collaboratorData, result.successResult.hours);
                                lcmModule.registerCheckLCMScheduleEvent('divBottomArea', lcmModule.getTypes().CHART_COLLAB);
                            } else {
                                getContainer().empty().html(result.errorResult);
                            }
                        }
                    } else {
                        // Retorna a mensagem de erro
                        dialogModule.createDialog(0, _globalResources.getResource().ErrorTitle, _globalResources.getResource().CommunicationError);
                    }
                    scheduleModule.getBottonViewPageLoader().hide();
                }
            });
        }
    }

    function loadView_DISCARDED(unitID, sectionID, workstationTypeID, date, searchTermCollaborator, searchTermWorkLoad) {
        if (scheduleModule.isCurrentDataTab() && scheduleModule.getSelectedView() == myName()) {

            scheduleModule.getBottonViewPageLoader().show();

            getContainer().height(getContainer().parent().height());
            getContainer().width(getContainer().parent().width());

            //var sectionListIDsNew       = $("#ddlSectionMulti").val(),
            var sectionListIDsNew = [$("#ddlSection").val()],
                workstationListIDs      = $("#ddlWorkstationTypeMulti").val() || [],
                _chartCollaboratorData  = [],
                errorRsp;

            getChartCollaboratorValues(sectionListIDsNew, sectionListIDsNew.length, 0, workstationListIDs, workstationListIDs.length, 0, date, _chartCollaboratorData, searchTermCollaborator, searchTermWorkLoad, errorRsp, function (err, chartCollaboratorData) {
                var hours            = [],
                    collaboratorData = [];

                if (chartCollaboratorData.length > 0)
                {
                    hours = chartCollaboratorData[0].hours;

                    for (i = 0; i < chartCollaboratorData.length; i++) {
                        $.merge(collaboratorData, chartCollaboratorData[i].collaboratorData);
                    }

                    //Draw the chart with merged Data
                    createChart(date, collaboratorData, hours);
                    lcmModule.registerCheckLCMScheduleEvent('divBottomArea', lcmModule.getTypes().CHART_COLLAB);

                } else {
                    getContainer().empty().html(err.errorResult);
                }
                scheduleModule.getBottonViewPageLoader().hide();
            });
        }
    }

    function getChartCollaboratorValues(sectionListIDs, sectionListIDsSize, sectionListIDsPosi, workstationListIDs, workstationListIDsSize, workstationListIDsPosi, startDate, chartCollaboratorData, searchTermCollaborator, searchTermWorkLoad, errorRsp, callback) {
        if (sectionListIDsPosi < sectionListIDsSize) {
            //If Multiselection Section
            if (sectionListIDsSize > 1 || workstationListIDsSize <= 1)
            {
                //Serealiza parametros
                var parameters = JSON.stringify({
                    sectionID: sectionListIDs[sectionListIDsPosi],
                    workstationTypeID: workstationListIDs[workstationListIDsPosi] || "",
                    date: startDate.toMSDate(),
                    searchTermCollaborator: searchTermCollaborator,
                    searchTermWorkLoad: searchTermWorkLoad
                });

                requestAjax(parameters, function (err, data) {
                    if (!err) {
                        item = data;
                        chartCollaboratorData.push(data);

                        getChartCollaboratorValues(sectionListIDs, sectionListIDsSize, sectionListIDsPosi + 1, workstationListIDs, workstationListIDsSize, workstationListIDsPosi, startDate, chartCollaboratorData, searchTermCollaborator, searchTermWorkLoad, errorRsp, callback);
                    }
                    else {
                        errorRsp = err;
                        getChartCollaboratorValues(sectionListIDs, sectionListIDsSize, sectionListIDsPosi + 1, workstationListIDs, workstationListIDsSize, workstationListIDsPosi, startDate, chartCollaboratorData, searchTermCollaborator, searchTermWorkLoad, errorRsp, callback);
                    }
                });
            } else {
                //If only one Section is selected
                if (workstationListIDsPosi < workstationListIDsSize) {
                    //Serealiza parametros
                    var parameters = JSON.stringify({
                        sectionID: sectionListIDs[sectionListIDsPosi],
                        workstationTypeID: workstationListIDs[workstationListIDsPosi] || "",
                        date: startDate.toMSDate(),
                        searchTermCollaborator: searchTermCollaborator,
                        searchTermWorkLoad: searchTermWorkLoad
                    });

                    requestAjax(parameters, function (err, data) {
                        if (!err) {
                            chartCollaboratorData.push(data);

                            getChartCollaboratorValues(sectionListIDs, sectionListIDsSize, sectionListIDsPosi, workstationListIDs, workstationListIDsSize, workstationListIDsPosi + 1, startDate, chartCollaboratorData, searchTermCollaborator, searchTermWorkLoad, errorRsp, callback);
                        }
                        else {
                            errorRsp = err;
                            getChartCollaboratorValues(sectionListIDs, sectionListIDsSize, sectionListIDsPosi, workstationListIDs, workstationListIDsSize, workstationListIDsPosi + 1, startDate, chartCollaboratorData, searchTermCollaborator, searchTermWorkLoad, errorRsp, callback);
                        }
                    });
                } else {
                    callback(errorRsp, chartCollaboratorData);
                  }
            }
        }
        else {
            callback(errorRsp, chartCollaboratorData);
        }
    }

    function requestAjax(parameters, callback) {
        $.ajax({
            url: urlConfig.schedule.chartCollaborators,
            data: parameters,
            success: function (response) {
                if (response) {
                    //Parsevar RetVal;
                    var result = JSON.parse(response);

                    if (result) {

                        if (result.hasSuccess) {

                            var chartCollaboratorsDataObj = {
                                collaboratorData: result.successResult.collaboratorData,
                                hours: result.successResult.hours
                            };

                            callback(null, chartCollaboratorsDataObj);
                        } else {
                            callback(result);
                        }
                    }
                }
            },
            error: function (response) {
                callback(response);
            }
        });
    }

    function updateHourArea(divContainer, divHour) {
        var newtop = divContainer.height() - divHour.height();
        divHour.css("top", newtop);
    }

    function scrollToBottom(divContainer) {
        var domContainer = divContainer.get(0);
        domContainer.scrollTop = 0;
        divContainer.animate({ scrollTop: divContainer.get(0).scrollHeight }, 'fast');
    }

    function updateScroll(newHeight, originalHeight) {
        if (scheduleModule.isCurrentDataTab() && scheduleModule.getSelectedView() == myName()) {
            var divContainerScroll = getContainerScroll();

            if (newHeight > originalHeight) {
                divContainerScroll.css("height", newHeight);
            } else {
                divContainerScroll.css("height", originalHeight);
            }
            updateHourArea(divContainerScroll, $("#divViewsArea").find(".hour-area"));
            scrollToBottom(divContainerScroll);
        }
    }
    //#endregion

    return {
        loadView: loadView,
        myName: myName,
        getSelectedCollaborators: getSelectedCollaborators,
        updateScroll: updateScroll
    }

}();