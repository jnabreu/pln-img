var scheduleTooltipHelper = function () {

    function getTooltipText(start, end, event, collabEvents) {
        // TODO: refactor this code to pass to handle intervals has an array!
        var intervals = $.grep(collabEvents, function (el) {
            return el.seqNumber === 2;
        });
        var intervals2 = $.grep(collabEvents, function (el) {
            return el.seqNumber === 4;
        });

        var minMax = customControlsModule.getMinMaxDate(collabEvents, 'start_date', 'end_date');

        var hasInterval = intervals.length > 0;
        var hasInterval2 = intervals2.length > 0;

        var intervalStart = hasInterval ? intervals[0].start_date : null;
        var intervalEnd = hasInterval ? intervals[0].end_date : null;
        var intervalStart2 = hasInterval2 ? intervals2[0].start_date : null;
        var intervalEnd2 = hasInterval2 ? intervals2[0].end_date : null;

        var intervalsForDailyWork = [];
        if (hasInterval) {
            intervalsForDailyWork.push({
                startDate: intervalStart,
                endDate: intervalEnd,
            });
        }


        if (hasInterval2) {
            intervalsForDailyWork.push({
                startDate: intervalStart2,
                endDate: intervalEnd2,
            });
        }


        var data = {
            enrollmentNumber: event.enrollmentNumber,
            collabLabel: event.collabLabel,
            startDate: minMax.minDate,
            endDate: minMax.maxDate,
            hasInterval: hasInterval,
            hasInterval2: hasInterval2,
            intervalStartDate: intervalStart,
            intervalEndDate: intervalEnd,
            intervalStartDate2: intervalStart2,
            intervalEndDate2: intervalEnd2,
            dailyWork: getDailyWork(minMax.minDate, minMax.maxDate, intervalsForDailyWork),
            workstationName: getWorkstationName(event),
        };

        return getTooltipString(data);
    }

    function getTooltipString(data) {
        var tabs = getNBSPs(2);
        var sBuilder = (data.enrollmentNumber ? '<b>' + data.enrollmentNumber + '</b>' + ' - ' : "") + '<b>' + data.collabLabel + '</b>' + '</br>';
        sBuilder += dateModule.formatDate(data.startDate) + ' - ';
        sBuilder = data.hasInterval ? sBuilder + dateModule.formatDate(data.intervalStartDate) : sBuilder + dateModule.formatDate(data.endDate);
        sBuilder += '<span>' + tabs + '|' + tabs + data.dailyWork + '</span>' + '</br>';

        sBuilder = data.hasInterval ? sBuilder + dateModule.formatDate(data.intervalEndDate) : sBuilder + getNBSPs(19);
        sBuilder = data.hasInterval && !data.hasInterval2 ? sBuilder + ' - ' + dateModule.formatDate(data.endDate) : sBuilder;
        sBuilder = data.hasInterval2 ? sBuilder : sBuilder;

        sBuilder = data.hasInterval2 ? (sBuilder + ' - ' + dateModule.formatDate(data.intervalStartDate2)) : sBuilder;
        sBuilder += '<span>' + tabs + '|' + tabs + data.workstationName + '</span>';

        sBuilder = data.hasInterval2 ? sBuilder + '</br>' : sBuilder;
        sBuilder = data.hasInterval2 ? sBuilder + dateModule.formatDate(data.intervalEndDate2) + ' - ' + dateModule.formatDate(data.endDate) : sBuilder;
        sBuilder = data.hasInterval2 ? sBuilder + '<span>' + tabs + '|' + '</span>' : sBuilder;

        return sBuilder;
    }

    function getNBSPs(qty) {
        var sBuilder = '';
        while (qty--) {
            sBuilder += '&nbsp;';
        }
        return sBuilder;
    }

    function getDailyWork(start, end, intervals) {
        var diff = +end - +start;
        var finalDiff = diff;

        for (var i = 0; i < intervals.length; i++) {
            var interval = intervals[i];
            var intervalDiff = +interval.endDate - +interval.startDate;
            finalDiff -= intervalDiff;
        }
        return dateModule.getFormattedDurationDiff(finalDiff);
    }

    function getWorkstationName(event) {
        var name = "";
        if (event.workstationTypeName)
            name = event.workstationTypeName;

        if (event.workstationName)
            name += " - " + event.workstationName;

        return name;
    }

    function getFullDayTooltip(start, end, event) {
        var sBuilder = (event.enrollmentNumber ? '<b>' + event.enrollmentNumber + '</b>' + ' - ' + '<b>' : "") + event.collabLabel + '</b>' + '</br>';
        sBuilder += event.description ? event.description : event.text;
        return sBuilder;
    }

    function getPolyvalentTooltip(start, end, event) {
        var tabs = getNBSPs(2);
        var sBuilder = (event.enrollmentNumber ? '<b>' + event.enrollmentNumber + '</b>' + ' - ' : "") + '<b>' + event.collabLabel + '</b>' + '</br>';
        sBuilder += dateModule.formatDate(start) + ' - ' + dateModule.formatDate(end);
        sBuilder += '<span>' + tabs + '|' + tabs + dateModule.getFormattedDuration(start, end) + '</span>' + '</br>';
        sBuilder += getNBSPs(19);
        sBuilder += '<span>' + tabs + '|' + tabs + getWorkstationName(event) + '</span>';
        return sBuilder;
    }

    return {
        getTooltipText: getTooltipText,
        getFullDayTooltip: getFullDayTooltip,
        getPolyvalentTooltip: getPolyvalentTooltip,
        getTooltipString: getTooltipString,
        getWorkstationName: getWorkstationName,
        getDailyWork: getDailyWork,
    }
}();
