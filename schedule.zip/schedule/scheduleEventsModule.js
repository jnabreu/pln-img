var scheduleEventsModule = function () {

    var DATE_CATEGORIES = {
        REST: "REST",
        ABSENCE: "ABSENCE",
    };

    var DATE_TYPES = {
        REST: "R",      // generic rest
    }

    var REST_STATE = {
        PROCESSED: "P",
        APPROVED: "A",
        WAITING_APPROVAL: "W",
    };

    var PROPERTIES = {
        COLOR: "Color",
        TEXT_COLOR: "TextColor",
        BORDER: "Border",
        NAME: "Name",
        DESCRIPTION: "Description",
    };

    var gSchedulerId = 0;
    var gDateTypes = null;

    var gDefaultColors = {
        color: "rgb(185, 185, 185)",
        textColor: "black",
    };

    var gEvents = {};

    function getConstants() {
        return {
            PROPERTIES: PROPERTIES,
            DATE_CATEGORIES: DATE_CATEGORIES,
            DATE_TYPES: DATE_TYPES,
            REST_STATE: REST_STATE,
        }
    }

    function getPropertiesMethods() {
        return {
            getDetails: getDetails,
            getText: getText,
            getType: getType,
            getColor: getColor,
            getTextColor: getTextColor,
            getBorder: getBorder,
        }
    }

    function getContainer() {
        return $("#divViewsArea");
    }

    function initDateTypes(dateTypesObj) {
        gDateTypes = mapDateTypes(dateTypesObj);
    }

    function resetScheduler() {
        if (scheduler) {
            scheduler._mode = null;
            scheduler._events = {};
        }
    }

    function handleCollaboratorsTree(collaboratorsTree, handleDateCallback, options) {
        var outObj = {
            events: [],
            collabsIds: [],
            collabs: [],
        };
        var options = options || {};
        var allCollabs = typeof options.allCollabs !== 'undefined' ? options.allCollabs : true;
        var shortenNames = typeof options.shortenNames !== 'undefined' ? options.shortenNames : false;
        options.handleDateCallback = handleDateCallback;
        var collaboratorAddGroupParams = [options];
        var opts = { allCollabs: allCollabs, shortenNames: shortenNames };
        var groups = sortGroupsTree(mapCollaboratorTree(collaboratorsTree, outObj, opts, handleCollaboratorAddGroup, collaboratorAddGroupParams));

        return {
            groups: groups,
            events: outObj.events,
            collabsIds: outObj.collabsIds,
            collabs: outObj.collabs,
        };
    }

    function sortByLabel(elemA, elemB) {
        var a = elemA.label.toUpperCase(),
            b = elemB.label.toUpperCase();

        if (a == b) {
            return 0;
        }
        return (a < b) ? -1 : 1;
    }

    function sortGroupsTree(tree) {
        tree.sort(sortByLabel);
        for (var key in tree) {
            var node = tree[key];
            if (node.children && node.children.length > 0) {
                sortGroupsTree(node.children);
            }
        }
        return tree;
    }

    function mapCollaboratorTree(collaboratorsTree, outObj, opts, handleCollaboratorDatesCallback, callbackParams) {
        /// <summary>
        /// recursively maps the incoming collaborators events tree to dhtmlx needed format tree.
        /// also the collaborators list and the collaborators list of events is saved and passed as an out param.
        /// </summary>
        /// <param name="collaboratorsTree"></param>
        /// <param name="outObj"></param>
        /// <param name="handleCollaboratorDatesCallback"></param>
        /// <param name="callbackParams"></param>
        /// <returns type=""></returns>/
        var allCollabs = opts.allCollabs;
        var shortenNames = opts.shortenNames;

        if (collaboratorsTree.length > 0) {
            var mapped = [];
            for (var key in collaboratorsTree) {
                var node = collaboratorsTree[key];
                var dhxNode = {};
                dhxNode.key = node.LevelType + '_' + node.ID;
                dhxNode.label = node.Description;
                dhxNode.open = true;
                dhxNode.children = [];
                if (node.CollaboratorEventsTreeList) {
                    dhxNode.children = mapCollaboratorTree(node.CollaboratorEventsTreeList, outObj, opts,
                        handleCollaboratorDatesCallback, callbackParams);
                }
                if (collabsList = node.CollaboratorEventsModelList) {
                    for (var i = 0, len = collabsList.length; i< len; i++) {
                        var collab = collabsList[i];
                        
                        collabDatesParams = callbackParams ? callbackParams : [];
                        collabDatesParams.unshift(collab);
                        var collabDates = handleCollaboratorDatesCallback.apply(null, collabDatesParams);
                        collabDatesParams.shift();

                        if (!(collabDates.length === 0 && !allCollabs)) {
                            outObj.events = outObj.events.concat(collabDates);
                            outObj.collabsIds = outObj.collabsIds.concat(collab.CollaboratorID); // TODO: remove this and use the obj bellow
                            outObj.collabs = outObj.collabs.concat({ id: collab.CollaboratorID, name: collab.CollaboratorName });

                            dhxNode.children.push({
                                key: 'COL_' + collab.CollaboratorID,
                                label: handleName(collab.CollaboratorName, shortenNames),
                                originalLabel: collab.CollaboratorName,
                            });
                        }
                    }
                }
                // empty elements are not shown
                if (dhxNode.children.length > 0) {
                    mapped.push(dhxNode);
                }
            }
            return mapped;
        } else {
            return [];
        }
    }

    function handleName(name, shortenName) {
        if (shortenName) {
            var namesList = name.split(' ');
            name = namesList[0];
            name = (namesList.length > 1) ? (name + ' ' + namesList[namesList.length - 1]) : name;
        }
        return name;
    }

    function handleCollaboratorAddGroup(collaborator, options) {
        var dateCategoriesToShow = [], // = options.categoriesFilter
            dateTypesToShow = [], // = options.typeFilter
            groupKey = "section_id", // TODO: accept other values
            collabID = "collabID",
            groupValue = 'COL_' + collaborator.CollaboratorID,
            handleDateCallback = options.handleDateCallback;

        var collabDates = handleCollaboratorDates(collaborator.EventsList, handleDateCallback,
            dateCategoriesToShow, dateTypesToShow);

        collabDates = $.map(collabDates, function (elem, index) {
            elem[groupKey] = groupValue;
            elem[collabID] = collaborator.CollaboratorID;
            return elem;
        });

        return collabDates;
    }

    // TODO filter dates by turning them visible/not visible (dhtmlx filters)
    function handleCollaboratorDates(collaboratorDates, handleDateCallback, dateCategoriesToShow, dateTypesToShow) {
        /// <summary>
        /// Processes the rests/absences of a collaborator for 
        /// a given list of types of dates to show
        /// </summary>
        /// <param name="collaboratorDates">the dates of a collaborator</param>
        /// <param name="dateCategoriesToShow">a list of the types of dates to show: rest, absence days</param>
        /// <param name="dateTypesToShow">a list of the types of dates to show: rest, absence days</param>
        /// <returns type="">list of dhtmlx scheduler dates</returns>

        // var filteredDates = filterDates(collaboratorDates, dateCategoriesToShow, dateTypesToShow);
        var filteredDates = collaboratorDates;
        var dates = $.map(filteredDates, function (elem, key) {
            return handleDateCallback(elem);
        });

        return dates;
    }

    function mapDateTypes(dateTypes) {
        /// <summary>
        /// maps the dateTypes object received from the request 
        /// to recursive tree structure. 
        /// Each type can hold subtype and each subtype can hold 
        /// a subsubtype and so on...
        /// </summary>
        /// <param name="dateTypes"></param>
        /// <returns type=""></returns>
        if (dateTypes && dateTypes.length > 0) {
            var mapped = {};
            for (var key in dateTypes) {
                var dateType = dateTypes[key];
                mapped[dateType.ID] = {};
                mapped[dateType.ID].DEFAULT = dateType.Property;
                mapped[dateType.ID].TYPES = mapDateTypes(dateType.Types);
            }
            return mapped;
        } else {
            return {};
        }
    }

    function getProperty(vPath, propertyName) {
        /// <summary>
        /// Gets the value of a given property for a date type.
        /// If a date type doesn't have that specific property defined,
        /// it falls back to a higher level property
        /// </summary>
        /// <param name="vPath"></param>
        /// <param name="propertyName"></param>
        /// <returns type=""></returns> 
        if (!propertyName || !vPath || !gDateTypes) return;
        if (vPath && vPath.lenght < 0) return;

        var currPath = gDateTypes[vPath[0]];
        if (!currPath) return;
        if (typeof currPath === 'undefined') console.log('is undefined', vPath, propertyName)
        var propValue = null;
        for (i = 1; i < vPath.length; i++) {
            propValue = currPath.DEFAULT[propertyName];
            currPath = currPath.TYPES[vPath[i]];
            if (currPath) {
                if (currPath.DEFAULT[propertyName]) {
                    propValue = currPath.DEFAULT[propertyName];
                }
            } else {
                break;
            }
        }
        return (propValue ? propValue : "");
    }

    function filterDates(collaboratorDates, dateCategoriesToShow, dateTypesToShow) {
        /// <summary>
        /// filters the categories/types of dates to show.
        /// a list of categories/types will display dates that belong to that category/type.
        /// empty lists of categories/types will apply no filter and show all catergories/types.
        /// </summary>
        /// <param name="collaboratorDates"></param>
        /// <param name="dateCategoriesToShow"></param>
        /// <param name="dateTypesToShow"></param>
        /// <returns type=""></returns>
        var filteredDates = [];
        var filterByCategories = (dateCategoriesToShow.length > 0);
        var filterByTypes = (dateTypesToShow.length > 0);

        if (filterByCategories) {
            filteredDates = $.grep(collaboratorDates, function (elem, index) {
                if ($.inArray(elem.Category, dateCategoriesToShow) > -1) {
                    return true;
                }
                return false;
            });
        }
        if (filterByCategories && filterByTypes) {
            filteredDates = $.grep(filteredDates, function (elem, index) {
                if ($.inArray(elem.Type, dateTypesToShow) > -1) {
                    return true;
                }
                return false;
            });
        }
        return filterByCategories ? filteredDates : collaboratorDates;
    }


    // DEPRECATED
    function handleDateDefault(collaboratorDate) {
        /// <summary>
        /// Handles a collaborator dates (rest, absence, etc)
        /// </summary>
        /// <param name="collaboratorDate">the collaborator date</param>
        /// <returns type="dhx event type">a dhtmlx event object. 
        /// i.e: {id, start_date, end_date, ... } </returns> 

        gSchedulerId += 1;
        var dhxEvent = {};

        // TODO: change to handle dynamic dhx date formats
        var startDate = new Date(parseInt(collaboratorDate.StartDate.substr(6)));
        var endDate = new Date(parseInt(collaboratorDate.EndDate.substr(6)));

        var formattetStartDate = startDate.getFullYear() + "-" + (startDate.getMonth() + 1) + "-" +
            startDate.getDate() + " " + startDate.getHours() + ":" + startDate.getMinutes();
        // var formattedEndDate = endDate.getFullYear() + "-" + (endDate.getMonth() + 1) + "-" 
        //     +endDate.getDate() + " " + endDate.getHours() + ":" + endDate.getMinutes();
        // TODO: uncomment line above; comment below
        var formattedEndDate = startDate.getFullYear() + "-" + (startDate.getMonth() + 1) + "-"
            + (startDate.getDate() + 1) + " 00:00";


        //var formattetStartDate = date.getFullYear() + "-" + (date.getMonth() + 1) + "-" +
        //    date.getDate() + " " + startDate.getHours() + ":" + startDate.getMinutes();

        //var formattedEndDate = date.getFullYear() + "-" + (date.getMonth() + 1) + "-"
        //    + date.getDate() + " " + endDate.getHours() + ":" + endDate.getMinutes();

        //var formattetStartDate = new Date(date.getFullYear(), date.getMonth() + 1, date.getDate(), startDate.getHours(), startDate.getMinutes(), 0);
        //var formattedEndDate = new Date(date.getFullYear(), date.getMonth() + 1, date.getDate(), endDate.getHours(), endDate.getMinutes(), 0);

        dhxEvent.id = gSchedulerId;
        dhxEvent.start_date = formattetStartDate;
        dhxEvent.end_date = formattedEndDate;
        dhxEvent.details = getDetails(collaboratorDate);
        dhxEvent.text = getText(collaboratorDate);
        dhxEvent.type = type = getType(collaboratorDate);
        dhxEvent.color = getColor(collaboratorDate);
        dhxEvent.textColor = getTextColor(collaboratorDate);

        return dhxEvent;
    }

    function getVPath(collaboratorDate) {
        /// <summary>
        /// Gets an ordered list of the "path" to the date type.
        /// At the moment only gets 2 levels
        /// I.e: ['ABSENCE', 'VACATION']
        /// </summary>
        /// <param name="collaboratorDate"></param>
        /// <returns type=""></returns>


        // return [].concat(collaboratorDate.Category).concat(collaboratorDate.Type);
        // Tmp fix. Works with Rests with the assumption that a rest has a State
        var result = [].concat(collaboratorDate.Category)
                       .concat(collaboratorDate.Type);

        if (collaboratorDate.State) {
            result = result.concat(collaboratorDate.State);
        }

        return result;
    }

    function getVPathFromType(type) {
        /// <summary>
        /// Gets the vPath from an event type
        /// </summary>
        /// <param name="type">event type</param>
        /// <returns type="">An ordered list of the type names. 
        /// I.e ['ABSENCE', 'VACATION']</returns>
        if (!type) {
            return [];
        }
        return type.split("_");
    }

    function getDetails(collaboratorDate) {
        var name = getProperty(getVPath(collaboratorDate), PROPERTIES.NAME);
        var description = getProperty(getVPath(collaboratorDate), PROPERTIES.DESCRIPTION);

        return (name ? name + " - " : "") + (description ? description : "");
    }

    function getText(collaboratorDate) {
        // var description = getProperty(getVPath(collaboratorDate), PROPERTIES.DESCRIPTION);
        return getDetails(collaboratorDate);
    }

    function getType(collaboratorDate) {
        /// <summary>
        /// Get the event type: the concatenation of the date type levels
        /// </summary>
        /// <param name="collaboratorDate"></param>
        /// <returns type="">Event type. I.e: ABSENCE_VACATION</returns>
        var vPath = getVPath(collaboratorDate);
        return vPath.join("_");
    }

    function getColor(collaboratorDate) {
        var color = getProperty(getVPath(collaboratorDate), PROPERTIES.COLOR);
        return color ? color : gDefaultColors.color;
    }
    
    function getBorder(collaboratorDate) {
        var Border = getProperty(getVPath(collaboratorDate), PROPERTIES.BORDER);
        return Border ? Border : "dotted";
    }

    function getTextColor(collaboratorDate) {
        var textColor = getProperty(getVPath(collaboratorDate), PROPERTIES.TEXT_COLOR);
        return textColor ? textColor : gDefaultColors.textColor;
    }

    function defineYearMonth(date) {
        var date_to_str = scheduler.date.date_to_str("%F %Y");
        return date_to_str(date);
    }

    function attachEventToScheduler(eventName, callback, params) {
        // for (key in gEvents) {
        //    scheduler.detachEvent(gEvents[key]);
        // }

        gEvents[eventName] = scheduler.attachEvent(eventName, function () {
            callback(params);
        });
    }

    function approveCollaboratorsRest(collaboratorsIDs, refreshHandler) {
        scheduleModule.getMainPageLoader().show();
        if (collaboratorsIDs == '') {
            dialogModule.showOK(
                _globalResources.getResource().schedule.ApprovedTitle,
                _globalResources.getResource().schedule.ApprovedNothingSelected);
            scheduleModule.getMainPageLoader().hide();
            return;
        }

        collaboratorsIDs = $.map(collaboratorsIDs, function (elem) {
            return parseInt(elem);
        });

        var parameters = {
            collaboratorsIDs: collaboratorsIDs,
        }

        parameters = JSON.stringify(parameters);
        console.log("parameters", parameters);

        $.ajax({
            url: urlConfig.schedule.approveRestDaysCollaborators,
            data: parameters,
            success: function (response) {
                var result = JSON.parse(response);
                if (result) {
                    if (result.hasSuccess) {
                        dialogModule.showDialog(result.successResult);
                        if (typeof (refreshHandler) === 'function') {
                            refreshHandler();
                        }
                    } else {
                        dialogModule.showDialog(result.errorResult);
                        scheduleModule.getMainPageLoader().hide();
                    }
                } else {
                    // Retorna a mensagem de erro
                    dialogModule.createDialog(0, _globalResources.getResource().ErrorTitle,
                        _globalResources.getResource().CommunicationError);
                    scheduleModule.getMainPageLoader().hide();
                }
            },
            error: function (response) {
                dialogModule.createDialog(0, _globalResources.getResource().ErrorTitle,
                    _globalResources.getResource().CommunicationError);
                scheduleModule.getMainPageLoader().hide();
            }
        });
    }

    return {
        getConstants: getConstants,
        getPropertiesMethods: getPropertiesMethods,
        initDateTypes: initDateTypes,
        handleCollaboratorsTree: handleCollaboratorsTree,
        handleCollaboratorDates: handleCollaboratorDates,
        attachEventToScheduler: attachEventToScheduler,
        getVPathFromType: getVPathFromType,
        getProperty: getProperty,
        resetScheduler: resetScheduler,
        approveCollaboratorsRest: approveCollaboratorsRest,
        // updateType: updateType,
    }
}();