var scheduleRestDaysTimelineModule = function () {

    var _containerDiv = '#restTimelineContent';

    var popup_rootID = '#divDialog ';
    popupData = null; // Global Variable

    var _contextData = {};
    var _monthsLoaded = [];
    var _eventsHash = {};
    var _eventsRestPrint = [];
    var _outPolyvalents = { objPaths: [] };
    var _isFirstTime = true;
    var _isDelete;
    var _noWarnings = false;

    var eventObj = {
        id: null,
        collaboratorID: null,
        absenceReasonID: null,
        absenceRuleID: null,
        collaboratorQuotaID: null,
        contingentID: null,
        startDate: null,
        endDate: null,
        startHour: null,
        endHour: null,
        isWorkstation: null,
        isQuota: null,
        isReplaceTime: null,
        MinimumDays: 1,
    };

    var _restDayQuotas = null,
        _listCollaboratorQuotas = null;

    var restViewVariables = {
        unitID: null,
        sectionID: null,
        workstationTypeID: null,
        selectedDate: null,
        endDate: null
    };

    var _CurrentViewDate = null,
        _AllCollaborators = [],
        _SelectedCollaborators = [],
        _ScheduleId = 0;

    var _dhtmlxSchedulerSettings = {
        properties: {
            viewName: 'timeline_month',
            labelName: 'Timeline',
            openDate: new Date(),
            dhxContainer: 'rest_schedule',
            linkTitle: "",
            allCollaborators: [],
            schedulerConfigs: {
                readonly: true,
                time_step: 15,
                xy: {
                    nav_height: 36,
                }
            },
            timelineConfigs: {
                name: "timeline_month",
                dx: 350,
            },
        },
        methods: {},
        eventHandlers: {
            onBeforeViewChangeCallback: onBeforeViewChangeCallbackRestDayExtend,
            onViewChangeCallback: onViewChangeCallbackRestDayExtend,
        },
    };

    function getAllCollaborators() {
        var allCollaborators = _dhtmlxSchedulerSettings.properties.allCollaborators;

        return allCollaborators;
    }

    function onFalseClick(date, ev) {
        return false;
    }

    function getEventsHash() {
        return _eventsHash;
    }

    function setSize(divId) {
        var contentContainer = $('.schedule-container .content');
        var footer = $('.page-footer');
        var width = contentContainer.width();
        var buttonsArea = $('#divRestButtonsArea');
        var newHeight = contentContainer.height() - footer.height() - buttonsArea.height() - 5;
        $(divId).height(newHeight);
    }

    function getRestDayEventsRequest(unitID, sectionID, workstationTypeID) {
        var deferred = $.Deferred();
        var year = new Date().getFullYear();

        var parameters = JSON.stringify({
            unitID: unitID,
            sectionID: sectionID,
            workstationTypeID: workstationTypeID,
            year: year,
        });

        $.ajax({
            url: urlConfig.schedule.unitRest,
            async: true,
            data: parameters,
            success: function (response) {
                if (response != null) {
                    deferred.resolve($.parseJSON(response));
                } else {
                    deferred.reject();
                }
            },
            error: function (response) {
                dialogModule.createDialog(0, _globalResources.getResource().ErrorTitle,
                    _globalResources.getResource().CommunicationError);
                scheduleModule.getMainPageLoader().hide();
            }
        });
        return deferred.promise();
    }

    function getRestDayEvents(unitID, sectionID, workstationTypeID, dateNow, onSuccessCallback, params) {
        scheduleModule.getMainPageLoader().show();

        var dates = scheduleBaseTimelineModule.getStartAndEndDate(dateNow),
            startDate = dates.startDate,
            endDate = dates.endDate;

        _contextData.dateNow = startDate;
        _dhtmlxSchedulerSettings.properties.openDate = startDate;

        getRestDayEventsRequest(unitID, sectionID, workstationTypeID, startDate, endDate)
            .done(function (response) {
                if (response.hasSuccess) {
                    $('#restTimelineContent .dhx_cal_data').empty();
                    _monthsLoaded.push(dateNow);
                    onSuccessCallback(response.successResult, params);
                } else {
                    handleError(response);
                }
            })
            .fail(function (error) {
                dialogModule.createDialog(0, _globalResources.getResource().ErrorTitle,
                    _globalResources.getResource().CommunicationError);
            })
            .always(function () {
                scheduleModule.getMainPageLoader().hide();
            });
    }

    function loadView(unitID, sectionID, workstationTypeID, selectedDate, endDate) {
        $('#restYearContent').hide();

        if (scheduleModule.isCurrentRestTab()) {
            if (_isFirstTime) {
                restViewVariables.unitID = unitID;
                restViewVariables.sectionID = sectionID;
                restViewVariables.workstationTypeID = workstationTypeID;
                restViewVariables.selectedDate = selectedDate;
                restViewVariables.endDate = endDate;
            }
            resetGlobalVars();
            $('#restTimelineContent').show();
            fromYearToTimeline();
            //if not a valid date - return a empty date - create one based on selectedDate
            if (isNaN(dateNow))
                dateNow = scheduleBaseTimelineModule.stringToDate(selectedDate, 'dd/mm/yyyy', '/') 
                || new Date();

            _contextData = {
                unitID: unitID,
                sectionID: sectionID,
                workstationTypeID: workstationTypeID,
                dateNow: dateNow,
            }
            getRestDayEvents(unitID, sectionID, workstationTypeID, dateNow, init);
        }
    }

    function fromYearToTimeline() {
        $('#restYearContent').hide().height('0');
        setSize('#restTimelineContent');
        $('#restTimelineContent').show();
        scheduleModule.showDropdowns(true, true, true, false, false, false);
        scheduleModule.enableDropdowns(true, true, false, false, false, false);
    }

    function attachSchedulerEvents() {
        var _eventNames = scheduleBaseTimelineModule.getLocalEvents();
        for (key in _eventNames) {
            scheduler.detachEvent(_eventNames[key]);
        }

        //Timeline Events
        _eventNames.onBeforeEventChangedEv = scheduler.attachEvent("onBeforeEventChanged", onBeforeEventChangedCallback);
        _eventNames.viewChangeEv = scheduler.attachEvent("onViewChange", onViewChangeCallbackRestDayExtend);
        _eventNames.beforeViewChangeEv = scheduler.attachEvent("onBeforeViewChange", onBeforeViewChangeCallbackRestDayExtend);
    }

    function onBeforeEventChangedCallback(newEv, ev, isNew, originalEv) {
        var collabObj = scheduler.getActionData(ev);
        console.log("Captando Data", newEv, collabObj);
        if (collabObj && collabObj.section) {
            //to not change the original value
            var section = collabObj.section;
            //replace anything that ends with _
            var collabId = section.replace(/.*_/, "");

            newEv.collabID = collabId;
            newEv._count = 1;
            newEv._sorder = 0;
            newEv._inner = false;
            newEv._timed = 0;
            newEv.color = "rgb(50,205,50)";
            newEv.section_id = section;
            newEv.isNew = true;
            newEv.isRest = false;
            scheduler.updateEvent(newEv.id);
        }
        return false;
    }

    function getCollabEvents(events, eventToMatch) {
        if (!events || events.length === 0 || !eventToMatch) return;

        return $.grep(events, function (ev) {
            return ev.collabID == eventToMatch.collabID &&
                   customControlsModule.compareDatesByDay(ev.date, eventToMatch.start_date) &&
                   ev.isDayTimelineEvent;
        });
    }

    function handleDateAusencia(collaboratorData) {
        /// <summary>
        /// Handles a collaborator dates (rest, absence, etc)
        /// </summary>
        /// <param name="collaboratorData">the collaborator date</param>
        /// <returns type="dhx event type">a dhtmlx event object. 
        /// i.e: {id, start_date, end_date, ... } </returns> 
        _ScheduleId = _ScheduleId || 0;
        _ScheduleId += 1;

        var dhxEventAusencia = {};
        var propertiesMethods = scheduleEventsModule.getPropertiesMethods();

        var dhxDates = getDhxDates(collaboratorData);
        var eventSpecificData = getEventSpecificData(collaboratorData, dhxDates.startDate, dhxDates.endDate);

        var monthView = {}, dayView = {};

        dhxEventAusencia.id = _ScheduleId;
        dhxEventAusencia.absenceID = collaboratorData.AbsenceID;
        dhxEventAusencia.absenceReasonID = collaboratorData.AbsenceReasonID;
        dhxEventAusencia.absenceRuleID = collaboratorData.AbsenceRuleID;
        dhxEventAusencia.details = collaboratorData.AbsenceReason;
        dhxEventAusencia.text = collaboratorData.AbsenceReasonAlias;
        dhxEventAusencia.type = type = propertiesMethods.getType(collaboratorData);
        dhxEventAusencia.isWorkstation = (dhxEventAusencia.type.replace(/.*_/, "") == "HORAS") ? true : false;
        dhxEventAusencia.border = propertiesMethods.getBorder(collaboratorData);
        dhxEventAusencia.color = collaboratorData.Color || (propertiesMethods.getColor(collaboratorData));
        dhxEventAusencia.textColor = propertiesMethods.getTextColor(collaboratorData);
        dhxEventAusencia.start_date = monthView.start_date = dhxDates.formattedStartDate;
        dhxEventAusencia.end_date = monthView.end_date = dhxDates.formattedEndDate;
        dhxEventAusencia.isNew = false;
        dhxEventAusencia.isRest = (collaboratorData.AbsenceReasonAlias == null) ? true : false;

        dhxEventAusencia.collabID = collaboratorData.CollaboratorID;
        dhxEventAusencia.contingentID = collaboratorData.ContingentID;
        dhxEventAusencia.date = dhxDates.date;
        dhxEventAusencia.realStartDate = dayView.start_date = dhxDates.startDate;  // the real event start date
        dhxEventAusencia.realEndDate = dayView.end_date = dhxDates.endDate;        // the real event end date
        dhxEventAusencia.fullDayStartDate = dhxDates.fullDayStartDate;             // start date as 00:00
        dhxEventAusencia.fullDayEndDate = dhxDates.fullDayEndDate;                 // start date + 1 as 00:00
        dhxEventAusencia.isFullDayType = eventSpecificData.isFullDayType;
        dhxEventAusencia.dayType = eventSpecificData.dayType;
        dhxEventAusencia.isVisible = eventSpecificData.isVisible;
        dhxEventAusencia.countAsAllocated = eventSpecificData.countAsAllocated;
        dhxEventAusencia.collabLabel = collaboratorData.CollaboratorName;
        dhxEventAusencia.enrollmentNumber = collaboratorData.Enrollment;
        dhxEventAusencia.intervalStart = dhxDates.intervalStart;
        dhxEventAusencia.intervalEnd = dhxDates.intervalEnd;
        dhxEventAusencia.intervalStart2 = dhxDates.intervalStart2;
        dhxEventAusencia.intervalEnd2 = dhxDates.intervalEnd2;
        dhxEventAusencia.workstationType = collaboratorData.WorkstationType;
        dhxEventAusencia.isDayTimelineEvent = false;
        dhxEventAusencia.scheduleID = collaboratorData.ScheduleID;
        dhxEventAusencia.rangeBegin = dhxDates.rangeBegin;
        dhxEventAusencia.rangeEnd = dhxDates.rangeEnd;
        dhxEventAusencia.granularity = collaboratorData.Granularity;
        dhxEventAusencia.sectionID = collaboratorData.SectionID;
        dhxEventAusencia.workstationName = collaboratorData.WorkstationName;
        dhxEventAusencia.workstationTypeName = collaboratorData.WorkstationTypeName;
        dhxEventAusencia.workstationTypeID = collaboratorData.WorkstationTypeID || null;
        dhxEventAusencia.workstationTypeColor = collaboratorData.WorkstationTypeColor;
        dhxEventAusencia.workstationID = collaboratorData.WorkstationID || null;
        dhxEventAusencia.isSectionPolyvalent = collaboratorData.IsSectionPolyvalent;
        dhxEventAusencia.isPolyvalent = collaboratorData.IsPolyvalent;
        dhxEventAusencia.workContractID = collaboratorData.WorkContractID;
        dhxEventAusencia.intervalTypeID = collaboratorData.IntervalTypeID;
        dhxEventAusencia.weeklyWorkLoad = collaboratorData.WeeklyWorkLoad;
        dhxEventAusencia.dailyWorkLoad = collaboratorData.DailyWorkload;
        dhxEventAusencia.hasHalfTurnAbsence = collaboratorData.HasHalfTurnAbsence;
        dhxEventAusencia.situation = collaboratorData.Situation;
        dhxEventAusencia.seqNumber = 0;
        dhxEventAusencia.hasEdit = false;
        dhxEventAusencia.hasDelete = false;
        dhxEventAusencia.belongsToPolyvalent = false;
        dhxEventAusencia.isFill = false;
        dhxEventAusencia.description = eventSpecificData.description ? eventSpecificData.description : null;
        dayView.type = dhxEventAusencia.type + " " + eventSpecificData.type;

        dhxEventAusencia.monthView = monthView;
        dhxEventAusencia.dayView = dayView;
        return dhxEventAusencia;
    }

    function getApprovedClass(collaboratorData) {
        return collaboratorData.Situation === 'A' ? 'approved' : '';
    }

    function getDhxDates(collaboratorDate) {
        var date = scheduleBaseTimelineModule.partsToDate(new Date(parseInt(collaboratorDate.Date.substr(6))).getUTCDate(), 
                                                          new Date(parseInt(collaboratorDate.Date.substr(6))).getUTCMonth(), 
                                                          new Date(parseInt(collaboratorDate.Date.substr(6))).getUTCFullYear());

        var auxEndDate = scheduleBaseTimelineModule.partsToDate(date.getDate(), date.getMonth(), date.getFullYear());

        var parsedStartDate = new Date(new Date(parseInt(collaboratorDate.StartDate.substr(6))).getUTCFullYear(), 
                                       new Date(parseInt(collaboratorDate.StartDate.substr(6))).getUTCMonth(), 
                                       new Date(parseInt(collaboratorDate.StartDate.substr(6))).getUTCDate(), 
                                       new Date(parseInt(collaboratorDate.StartDate.substr(6))).getUTCHours(), 
                                       new Date(parseInt(collaboratorDate.StartDate.substr(6))).getUTCMinutes(), 
                                       new Date(parseInt(collaboratorDate.StartDate.substr(6))).getUTCSeconds());
        
        var parsedEndDate = new Date(new Date(parseInt(collaboratorDate.EndDate.substr(6))).getUTCFullYear(), 
                                     new Date(parseInt(collaboratorDate.EndDate.substr(6))).getUTCMonth(), 
                                     new Date(parseInt(collaboratorDate.EndDate.substr(6))).getUTCDate(), 
                                     new Date(parseInt(collaboratorDate.EndDate.substr(6))).getUTCHours(), 
                                     new Date(parseInt(collaboratorDate.EndDate.substr(6))).getUTCMinutes(), 
                                     new Date(parseInt(collaboratorDate.EndDate.substr(6))).getUTCSeconds());
           
        var parsedIntervalStart = collaboratorDate.IntervalBeginHour ? 
                                  new Date(new Date(parseInt(collaboratorDate.IntervalBeginHour.substr(6))).getUTCFullYear(), 
                                           new Date(parseInt(collaboratorDate.IntervalBeginHour.substr(6))).getUTCMonth(), 
                                           new Date(parseInt(collaboratorDate.IntervalBeginHour.substr(6))).getUTCDate(), 
                                           new Date(parseInt(collaboratorDate.IntervalBeginHour.substr(6))).getUTCHours(), 
                                           new Date(parseInt(collaboratorDate.IntervalBeginHour.substr(6))).getUTCMinutes(), 
                                           new Date(parseInt(collaboratorDate.IntervalBeginHour.substr(6))).getUTCSeconds())
                                  : null;

        var parsedIntervalEnd = collaboratorDate.IntervalEndHour ? 
                                    new Date(new Date(parseInt(collaboratorDate.IntervalEndHour.substr(6))).getUTCFullYear(), 
                                             new Date(parseInt(collaboratorDate.IntervalEndHour.substr(6))).getUTCMonth(), 
                                             new Date(parseInt(collaboratorDate.IntervalEndHour.substr(6))).getUTCDate(), 
                                             new Date(parseInt(collaboratorDate.IntervalEndHour.substr(6))).getUTCHours(), 
                                             new Date(parseInt(collaboratorDate.IntervalEndHour.substr(6))).getUTCMinutes(), 
                                             new Date(parseInt(collaboratorDate.IntervalEndHour.substr(6))).getUTCSeconds())
                                    : null;

        var parsedIntervalStart2 = collaboratorDate.IntervalBeginHour2 ? 
                                    new Date(new Date(parseInt(collaboratorDate.IntervalBeginHour2.substr(6))).getUTCFullYear(), 
                                             new Date(parseInt(collaboratorDate.IntervalBeginHour2.substr(6))).getUTCMonth(), 
                                             new Date(parseInt(collaboratorDate.IntervalBeginHour2.substr(6))).getUTCDate(), 
                                             new Date(parseInt(collaboratorDate.IntervalBeginHour2.substr(6))).getUTCHours(), 
                                             new Date(parseInt(collaboratorDate.IntervalBeginHour2.substr(6))).getUTCMinutes(), 
                                             new Date(parseInt(collaboratorDate.IntervalBeginHour2.substr(6))).getUTCSeconds())
                                    : null;

        var parsedIntervalEnd2 = collaboratorDate.IntervalEndHour2 ? 
                                    new Date(new Date(parseInt(collaboratorDate.IntervalEndHour2.substr(6))).getUTCFullYear(), 
                                             new Date(parseInt(collaboratorDate.IntervalEndHour2.substr(6))).getUTCMonth(), 
                                             new Date(parseInt(collaboratorDate.IntervalEndHour2.substr(6))).getUTCDate(), 
                                             new Date(parseInt(collaboratorDate.IntervalEndHour2.substr(6))).getUTCHours(), 
                                             new Date(parseInt(collaboratorDate.IntervalEndHour2.substr(6))).getUTCMinutes(), 
                                             new Date(parseInt(collaboratorDate.IntervalEndHour2.substr(6))).getUTCSeconds())
                                    : null;

        var parsedRangeBegin = collaboratorDate.RangeBegin ? 
                                new Date(new Date(parseInt(collaboratorDate.RangeBegin.substr(6))).getUTCFullYear(), 
                                         new Date(parseInt(collaboratorDate.RangeBegin.substr(6))).getUTCMonth(), 
                                         new Date(parseInt(collaboratorDate.RangeBegin.substr(6))).getUTCDate(), 
                                         new Date(parseInt(collaboratorDate.RangeBegin.substr(6))).getUTCHours(), 
                                         new Date(parseInt(collaboratorDate.RangeBegin.substr(6))).getUTCMinutes(), 
                                         new Date(parseInt(collaboratorDate.RangeBegin.substr(6))).getUTCSeconds())
                                : null;

        var parsedRangeEnd = collaboratorDate.RangeEnd ? 
                                new Date(new Date(parseInt(collaboratorDate.RangeEnd.substr(6))).getUTCFullYear(), 
                                         new Date(parseInt(collaboratorDate.RangeEnd.substr(6))).getUTCMonth(), 
                                         new Date(parseInt(collaboratorDate.RangeEnd.substr(6))).getUTCDate(), 
                                         new Date(parseInt(collaboratorDate.RangeEnd.substr(6))).getUTCHours(), 
                                         new Date(parseInt(collaboratorDate.RangeEnd.substr(6))).getUTCMinutes(), 
                                         new Date(parseInt(collaboratorDate.RangeEnd.substr(6))).getUTCSeconds())
                                : null;

        var fullDayStartDate = new Date(date.getFullYear(), 
                                date.getMonth(), 
                                date.getDate(), 
                                0, 0);

        var fullDayEndDate = new Date(fullDayStartDate);

        fullDayEndDate.setDate(fullDayStartDate.getDate() + 1);

        var startDate = new Date(date.getFullYear(), 
                        date.getMonth(), 
                        date.getDate(), 
                        parsedStartDate.getHours(), 
                        parsedStartDate.getMinutes());
        
        var formattetStartDate = parsedStartDate.getFullYear() + "-" + (parsedStartDate.getMonth() + 1) + "-" +
            parsedStartDate.getDate() + " " + parsedStartDate.getHours() + ":" + parsedStartDate.getMinutes();

        var formattetEndDate = parsedEndDate.getFullYear() + "-" + (parsedEndDate.getMonth() + 1) + "-" +
            parsedEndDate.getDate() + " " + parsedEndDate.getHours() + ":" + parsedEndDate.getMinutes();

        if (formattetStartDate > formattetEndDate) {
            formattedStartDate = formattetEndDate;
            formattedEndDate = formattetStartDate;
        } else {
            formattedStartDate = formattetStartDate;
            formattedEndDate = formattetEndDate;
        }

        //var startDate = new Date(date.getFullYear(), date.getMonth(), date.getDate(), parsedStartDate.getHours(), parsedStartDate.getMinutes());

        //var auxEndDate = new Date(date);
        if (parsedEndDate.getDate() === 2) { // 02-01-2000 HH:MM or 01-01-2000 HH:MM
            auxEndDate.setDate(date.getDate() + 1);
        }
        var endDate = new Date(auxEndDate.getFullYear(), auxEndDate.getMonth(), auxEndDate.getDate(), parsedEndDate.getHours(), parsedEndDate.getMinutes());

        var intervalStart = null;
        if (parsedIntervalStart) {
            var auxIntervalStart = new Date(date);
            if (parsedIntervalStart.getDate() === 2) {
                auxIntervalStart.setDate(date.getDate() + 1);
            }
            intervalStart = new Date(auxIntervalStart.getFullYear(), auxIntervalStart.getMonth(), auxIntervalStart.getDate(), parsedIntervalStart.getHours(), parsedIntervalStart.getMinutes());
        }

        var intervalEnd = null;
        if (parsedIntervalEnd) {
            var auxIntervalEnd = new Date(date);
            if (parsedIntervalEnd.getDate() === 2) {
                auxIntervalEnd.setDate(date.getDate() + 1);
            }
            intervalEnd = new Date(auxIntervalEnd.getFullYear(), auxIntervalEnd.getMonth(), auxIntervalEnd.getDate(), parsedIntervalEnd.getHours(), parsedIntervalEnd.getMinutes());
        }

        var intervalStart2 = null;
        if (parsedIntervalStart2) {
            var auxIntervalStart2 = new Date(date);
            if (parsedIntervalStart2.getDate() === 2) {
                auxIntervalStart2.setDate(date.getDate() + 1);
            }
            intervalStart2 = new Date(auxIntervalStart2.getFullYear(), auxIntervalStart2.getMonth(), auxIntervalStart2.getDate(), parsedIntervalStart2.getHours(), parsedIntervalStart2.getMinutes());
        }

        var intervalEnd2 = null;
        if (parsedIntervalEnd2) {
            var auxIntervalEnd2 = new Date(date);
            if (parsedIntervalEnd2.getDate() === 2) {
                auxIntervalEnd2.setDate(date.getDate() + 1);
            }
            intervalEnd2 = new Date(auxIntervalEnd2.getFullYear(), auxIntervalEnd2.getMonth(), auxIntervalEnd2.getDate(), parsedIntervalEnd2.getHours(), parsedIntervalEnd2.getMinutes());
        }

        var rangeBegin = null;
        if (parsedRangeBegin) {
            var auxRangeBegin = new Date(date);
            if (parsedRangeBegin.getDate() === 2) {
                auxRangeBegin.setDate(date.getDate() + 1);
            }
            rangeBegin = new Date(auxRangeBegin.getFullYear(), auxRangeBegin.getMonth(), auxRangeBegin.getDate(), parsedRangeBegin.getHours(), parsedRangeBegin.getMinutes());
        }

        var rangeEnd = null;
        if (parsedRangeEnd) {
            var auxRangeEnd = new Date(date);
            if (parsedRangeEnd.getDate() === 2) {
                auxRangeEnd.setDate(date.getDate() + 1);
            }
            rangeEnd = new Date(auxRangeEnd.getFullYear(), auxRangeEnd.getMonth(), auxRangeEnd.getDate(), parsedRangeEnd.getHours(), parsedRangeEnd.getMinutes());
        }

        return {
            date: date,
            startDate: startDate,
            endDate: endDate,
            fullDayStartDate: fullDayStartDate,
            fullDayEndDate: fullDayEndDate,
            intervalStart: intervalStart,
            intervalEnd: intervalEnd,
            intervalStart2: intervalStart2,
            intervalEnd2: intervalEnd2,
            rangeBegin: rangeBegin,
            rangeEnd: rangeEnd,
            formattedStartDate: formattedStartDate,
            formattedEndDate: formattedEndDate,
        }
    }

    function getWorkTypeLabel(startDate, endDate) {
        return "<span>"
               + ('0' + startDate.getHours()).slice(-2) + ":" + ('0' + startDate.getMinutes()).slice(-2)
               + "<br />"
               + ('0' + endDate.getHours()).slice(-2) + ":" + ('0' + endDate.getMinutes()).slice(-2)
               + "</span>";
    }

    function getRestFCData(collaboratorData) {
        return {
            text: "FC",
            isFullDayType: true,
            isVisible: true,
            countAsAllocated: false,
            type: "FC light",
            dayType: "CREST",
        }
    }

    function getRestFOData(collaboratorData) {
        return {
            text: "FO",
            isFullDayType: true,
            isVisible: true,
            countAsAllocated: false,
            type: "FO light",
            dayType: "MREST"
        }
    }

    function getNonWorkingData(collaboratorData) {
        return {
            text: "V",
            isFullDayType: true,
            isVisible: true,
            countAsAllocated: false,
            type: "V light",
            dayType: "N",
        }
    }

    function getHolidayData(collaboratorData) {
        return {
            text: "FER",
            isFullDayType: true,
            isVisible: true,
            countAsAllocated: false,
            type: "FER light",
            dayType: "H",
        }
    }

    function getWorkData(collaboratorData, startDate, endDate) {
        return {
            text: getWorkTypeLabel(startDate, endDate),
            isFullDayType: false,
            isVisible: true,
            countAsAllocated: true,
            dayType: "W",
        }
    }

    function getAbsenceData(collaboratorData) {
        return {
            text: collaboratorData.AbsenceReasonAlias,
            isFullDayType: true,
            isVisible: true,
            countAsAllocated: false,
            type: "ABS light",
            dayType: "A",
            description: collaboratorData.AbsenceReasonDescription,
        }
    }

    function getEventSpecificData(collaboratorData, startDate, endDate) {
        var res = {};
        var dayType = collaboratorData.DayType;

        if (dayType === "F") {  // Rest
            var restType = collaboratorData.RestType;
            switch (restType) {
                case "0": // FO
                    res = getRestFOData();
                    break;
                case "1": // FC
                    res = getRestFCData();
                    break;
            }
        } else if (dayType === "N") { // Non working day
            res = getNonWorkingData(collaboratorData);
        } else if (dayType === "R") { // Holiday
            res = getHolidayData(collaboratorData);
        } else if (dayType === "T") { // Work
            res = getWorkData(collaboratorData, startDate, endDate);
        } else if (dayType === "A") { // Absence
            res = getAbsenceData(collaboratorData);
        }
        return res;
    }

    function getEventSpecificDataFunctions() {
        return {
            getRestFCData: getRestFCData,
            getRestFOData: getRestFOData,
            getNonWorkingData: getNonWorkingData,
            getWorkData: getWorkData,
        };
    }

    function addMonthDataCallback(successResult, params) {
        dateNow = scheduleBaseTimelineModule.partsToDate(params.newDate.getDate(), params.newDate.getMonth(), params.newDate.getFullYear());
        
        scheduler.clearAll();
        var resHandlerAusencia = scheduleEventsModule.handleCollaboratorsTree(successResult.CollaboratorEventsList, handleDateAusencia, { allCollabs: false, shortenNames: true });

        _dhtmlxSchedulerSettings.properties.timelineConfigs.y_unit = resHandlerAusencia.groups;
        _dhtmlxSchedulerSettings.properties.allCollaborators = resHandlerAusencia.collabs;
        scheduleBaseTimelineModule.init(_dhtmlxSchedulerSettings);
        scheduler.setCurrentView();
        _eventsRestPrint = resHandlerAusencia.events;

        scheduleBaseTimelineModule.addData(resHandlerAusencia.events);
        onViewChangeCallbackRestDayExtend(params.newMode, params.newDate);

        var startDate = params.newDate;
        var day = (("0" + startDate.getDate()).charAt(2) == "") ? ("0" + startDate.getDate()) : startDate.getDate();
        var month = (("0" + (startDate.getMonth() + 1)).charAt(2) == "") ? ("0" + (startDate.getMonth() + 1)) : (startDate.getMonth() + 1);
        var endDay = (("0" + (startDate.getDate() + 7)).charAt(2) == "") ? ("0" + (startDate.getDate() + 7)) : (startDate.getDate() + 7);

        restViewVariables.selectedDate = day.toString().concat("/", month, "/", startDate.getFullYear());
        restViewVariables.endDate = endDay.toString().concat("/", month, "/", startDate.getFullYear());
    }

    //Recarrega a Ecrã Mapa de Folgas
    function refreshRestDayView() {
        console.log("REST: refresh view");
        _isFirstTime = true;
        //scheduleBaseTimelineModule.getEventHandlers().onViewChangeCallback();
        //onViewChangeCallbackRestDayExtend();
    }

    //Esconde Ecrã do Ano e Recarrega a Ecrã Mapa de Folgas
    function closeRestDayYearView() {
        fromYearToTimeline();
        loadView(restViewVariables.unitID, restViewVariables.sectionID, restViewVariables.workstationTypeID, restViewVariables.selectedDate, restViewVariables.endDate);
        _isFirstTime = true;
    }

    function onBeforeViewChangeCallbackRestDayExtend(oldMode, oldDate, newMode, newDate) {
        if (newDate != oldDate) {
            console.log("REST: on Before View Change");
            var dateNow = _contextData.dateNow || new Date();
            var newDate = newDate || new Date();

            var year = newDate.getFullYear();
            var month = (newDate.getMonth() + 1);
            var d = new Date(year, month, 0);
            var days = d.getDate(); // numbers of day in month
            scheduler.matrix[_dhtmlxSchedulerSettings.properties.timelineConfigs.name].x_size = days;

            var params = {
                newMode: newMode,
                newDate: newDate,
            };

            if (newMode === _dhtmlxSchedulerSettings.properties.viewName) {
                if (!customControlsModule.compareDatesByMonth(dateNow, newDate)) {
                    getRestDayEvents(_contextData.unitID, _contextData.sectionID, _contextData.workstationTypeID, newDate, addMonthDataCallback, params);
                }
            }
            scheduleBaseTimelineModule.getDefaultEventHandlers().onBeforeViewChangeCallback(oldMode, oldDate, newMode, newDate);
            return true;
        }
    }

    function onViewChangeCallbackRestDayExtend(newMode, newDate) {
        console.log("REST: on View Change");
        scheduleBaseTimelineModule.getDefaultEventHandlers().onViewChangeCallback(newMode, newDate);

        $('#rest_schedule .dhx_cal_header #selectAll').remove();
        $('#tabRest #divRestButtonsArea #divMarkApprove').remove();
        $('#tabRest #divRestButtonsArea #btnApproveRest').remove();

        applyStyles();
        registerClickCollaborator();
        resizeEvents();
        applySwitchSchedule();
    }

    function resizeEvents() {
        var eventsTimeLine = $(_containerDiv + ' .dhx_cal_event_line');

        if (eventsTimeLine.length > 0) {
            for (var i = 0; i < eventsTimeLine.length; i++) {
                eventsTimeLine[i].style.height = "15px"
            }
        }
    }

    function applyStyles() {
        var centerStylesRest = {
            "padding-left": "0",
            "text-align": "center",
            "font-size": "9px",
            "border": "1px Grey solid",
        }

        $(_containerDiv + ' .dhx_cal_event_line').css(centerStylesRest);
    }

    function addToSelectedCollaborators(collabID) {
        if ($.inArray(collabID, _SelectedCollaborators) === -1) {
            _SelectedCollaborators.push(collabID);
            return true;
        } else {
            return false;
        }
    }

    function removeFromSelectedCollaborators(collabID) {
        if ((index = $.inArray(collabID, _SelectedCollaborators)) > -1) {
            _SelectedCollaborators.splice(index, 1);
            return true;
        } else {
            return false;
        }
    }

    function existsOnSelectedCollaborators(collabID) {
        if ($.inArray(collabID, _SelectedCollaborators) > -1) {
            return true;
        } else {
            return false;
        }
    }

    function toggleRestDayView(showRestDayView) {
        if (showRestDayView) {
            setSize('#restTimelineContent');
        } else {
            $('#restTimelineContent').hide();
        }
    }

    function handleError(response) {
        toggleRestDayView(false);
        $(_containerDiv + ' #monthDataError').empty().html(response.errorResult);
    }

    function resetGlobalVars() {
        _monthsLoaded = [];
        _eventsHash = {};
        _outPolyvalents = { objPaths: [] };
    }

    function registerClickCollaborator() {
        var selector = $('#rest_schedule input[type=checkbox]').not('#checkAll').next();
        selector.off('click').on('click', openCollaboratorYearlyView);
    }

    function openCollaboratorYearlyView(event) {
        console.log("REST: on collab click");
        setSize('#restYearContent');
        $('#restTimelineContent').hide().height(0);
        scheduleModule.getMainPageLoader().show();
        $('#tabRest #divRestButtonsArea #btnApproveRest').hide();
        $('#tabRest #divRestButtonsArea #divMarkApprove').show();
        var collabID = $(this).prev().data('collabid');
        var year = new Date().getFullYear();
        var filteredList = $.grep(_dhtmlxSchedulerSettings.properties.allCollaborators, function (elem) {
            if (parseInt(elem.id) === collabID) {
                return true;
            }
        });
        var name = filteredList[0].name;
        var collab = {
            id: collabID, name: name
        };
        scheduleRestDaysYearModule.loadSchedule(collab, year, restViewVariables.selectedDate);
    }

    function registerEvents() {
        //registerClickApprovePredictedRestDays();
        applySwitchSchedule();
    }

    function getAbsenceRules(employeeID, absenceReasonID, selectDateIni) {
        var deferred = $.Deferred();
        var parameters = JSON.stringify({
            collaboratorID: employeeID,
            absenceReasonID: absenceReasonID,
            startDate: selectDateIni
        });

        $.ajax({
            url: urlConfig.schedule.getAbsenceRules,
            async: true,
            data: parameters,
            success: function (response) {
                if (response != null) {
                    return deferred.resolve($.parseJSON(response));
                } else {
                    setTimeout(function () {
                        deferred.reject(_globalResources.getResource().configuration.workstation.ErrorWorkstationTypeID);
                    }, 50);
                }
            }
        });

        return deferred.promise();
    }

    function getContingents(employeeID, absenceReasonID, selectDateIni, selectDataFim) {
        var deferred = $.Deferred();
        //Preenche dados do DropDown de posto de trabalho conforme a disponibilidade do colaborador
        var parameters = JSON.stringify({
            collaboratorID: employeeID,
            absenceReasonID: absenceReasonID,
            startDate: selectDateIni,
            endDate: selectDataFim,
        });

        $.ajax({
            url: urlConfig.schedule.getContingents,
            async: true,
            data: parameters,
            success: function (response) {
                if (response != null) {
                    return deferred.resolve($.parseJSON(response));
                } else {
                    setTimeout(function () {
                        deferred.reject(_globalResources.getResource().configuration.workstation.ErrorWorkstationTypeID);
                    }, 50);
                }
            }
        });

        return deferred.promise();
    }

    function switchScheduleCallback(answer, args, n_from, n_to) {
        if (answer) {
            console.log('Answered yes| Args: ', args);
            var form = '#divDialog';

            var parameters = JSON.stringify({
                id: eventObj.id || 0,
                collaboratorID: eventObj.collaboratorID,
                absenceReasonID: eventObj.absenceReasonID,
                absenceRuleID: eventObj.absenceRuleID,
                contingentID: eventObj.contingentID,
                collaboratorQuotaID: eventObj.collaboratorQuotaID,
                startDate: eventObj.startDate,
                endDate: eventObj.endDate,
                startHour: eventObj.startHour,
                endHour: eventObj.endHour,
                isWorkstation: eventObj.isWorkstation,
            });

            if (_isDelete) {
                $.ajax({
                    url: urlConfig.schedule.delAbsenceRestDayTimeline,
                    async: true,
                    data: parameters,
                    success: function (response) {
                        if (response) {
                            // Converte o retorno em um objeto JSON
                            var result = JSON.parse(response);
                            if (result) {
                                if (result.hasSuccess) {
                                    dialogModule.showDialog(result.successResult);
                                    loadView(restViewVariables.unitID, restViewVariables.sectionID, restViewVariables.workstationTypeID, restViewVariables.selectedDate, restViewVariables.endDate);
                                } else {
                                    dialogModule.showDialog(result.errorResult);
                                }
                            }
                        } else {
                            //Retorna a mensagem de erro
                            dialogModule.createDialog(0, _globalResources.getResource().ErrorTitle, _globalResources.getResource().CommunicationError);
                        }
                    }
                });
            } else {
                $.ajax({
                    url: urlConfig.schedule.saveAbsenceRestDayTimeline,
                    async: true,
                    data: parameters,
                    success: function (response) {
                        if (response) {
                            // Converte o retorno em um objeto JSON
                            var result = JSON.parse(response);
                            if (result) {
                                if (result.hasSuccess) {
                                    dialogModule.showDialog(result.successResult);
                                    loadView(restViewVariables.unitID, restViewVariables.sectionID, restViewVariables.workstationTypeID, restViewVariables.selectedDate, restViewVariables.endDate);
                                } else {
                                    dialogModule.showDialog(result.errorResult);
                                }
                            }
                        } else {
                            //Retorna a mensagem de erro
                            dialogModule.createDialog(0, _globalResources.getResource().ErrorTitle, _globalResources.getResource().CommunicationError);
                        }
                    }
                });
            }
        }
        else {
            console.log('Answered No');;
        }
        _isFirstTime = true;
    }

    function applySwitchSchedule() {
        var nodeSelector = ".dhx_cal_event_line";
        var nodeSelectorCell = ".dhx_matrix_cell";
        var nodes = $(_containerDiv + ' ' + nodeSelector);
        var nodesCell = $(_containerDiv + ' ' + nodeSelectorCell);
        // Double Click
        function dblClick(event) {
            // Source
            var ev = { isRest: false, isWorkstation: false };
            var e_source = $(event.target);

            resetEventObj();

            var collabObj = scheduler.getActionData(event);
            //to not change the original value
            var section = collabObj.section;
            //replace anything that ends with _
            eventObj.collaboratorID = section.replace(/.*_/, "");
            eventObj.startDate = customControlsModule.timestampToUTCHack(collabObj.date);
            eventObj.endDate = customControlsModule.timestampToUTCHack(collabObj.date);

            //get the event id(absenceID)
            var elemntSel = event.currentTarget;
            if (!elemntSel) {
                console.log('Wrong event', elemntSel);
            }
            else {
                var evid = $(elemntSel).attr('event_id');

                if (evid) {
                    ev = scheduler.getEvent(evid);
                    eventObj.startDate = customControlsModule.timestampToUTCHack(ev.start_date);
                    eventObj.endDate = customControlsModule.timestampToUTCHack(ev.end_date);
                    //ev.isWorkstation = (ev.type.replace(/.*_/, "") == "HORAS") ? true : false;
                    eventObj.isWorkstation = ev.isWorkstation;
                }
            }

            if (!ev.isRest) {
                //var cid_from = eventObj.collaboratorID;
                eventObj.id = ev.absenceID || 0;
                var cindex_source = Array.prototype.indexOf.call(e_source[0].parentNode.children, e_source[0]) + 1; //CSS is 1-index
                // Frontend Request
                var datum = {
                    questionPopup: true,
                    collaboratorID: eventObj.collaboratorID,
                    id: eventObj.id,
                    startDate: eventObj.startDate,
                    absenceWK: ev.isWorkstation
                };
                $('#rootPageLoader').show().addClass('transparent');
                if (_isFirstTime) {
                    _isFirstTime = false;
                    $.ajax({
                        url: urlConfig.schedule.getAbsenceReasons,
                        async: true,
                        data: JSON.stringify(datum),
                        success: function (response) {
                            $('#rootPageLoader').hide().removeClass('transparent');
                            if (response) {
                                var result = JSON.parse(response);
                                if (result) {
                                    if (result.hasSuccess) {
                                        //pegar a lista de quotas
                                        dialogModule.showDialog(result.successResult);
                                        scheduleModule.updateSchedule(); // Update a Vista Mensal
                                    } else if (result.hasQuestion) {
                                        if (result.genericMessage != null) {
                                            answerCode = result.genericMessage;
                                        }
                                        dialogModule.showYesOrNoDialog(result.questionResult, switchScheduleCallback, {
                                            event: event,
                                            answerCode: answerCode,
                                        }, function () {
                                            _isFirstTime = true;
                                        });
                                    } else {
                                        dialogModule.showDialog(result.errorResult);
                                    }
                                }
                            }
                            else {
                                // Retorna a mensagem de erro
                                moveCollaboratorsModule.createDialogExtra(0, _globalResources.getResource().ErrorTitle, _globalResources.getResource().CommunicationError);
                            }
                        },
                        error: function () {
                            $('#rootPageLoader').hide().removeClass('transparent');
                        },
                    });
                }
            }
        };
        nodes.dblclick(dblClick);
        nodesCell.dblclick(dblClick);
    }

    function isDate(val) {
        var d = new Date(val);
        return !isNaN(d.valueOf());
    }

    function popup_datePickerChangeDate(e) {
        console.log(e);
        $('.datepicker').hide();
    }

    function initPopupSwitchSchedule(model) {
        var m = JSON.parse(model);
        _restDayQuotas = m.AbsenceReasons;

        if (m.IsEdit) {
            eventObj.absenceReasonID = m.Absence.AbsenceReasonID;
            eventObj.isQuota = (m.Absence.IsQuota == "S") ? true : false;
            eventObj.isReplaceTime = (m.Absence.IsReplaceTime == "S") ? true : false;
            eventObj.MinimumDays = m.Absence.MinimumDays;
            $(popup_rootID + ' #txtMinimumDays').attr('value', eventObj.MinimumDays);
        }

        $(popup_rootID).ready(function () {
            $('[id^=txtPER_Ini]').keypress(validateNumber);
            $('[id^=txtPER_Fim]').keypress(validateNumber);
        });

        // Datepickers - No form
        customControlsModule.applyDatePickerControl(['txtStartDate'], true, false, null, null, false);
        customControlsModule.applyDatePickerControl(['txtEndDate'], true, false, null, null, false);

        // Confirm button
        $(popup_rootID + '#btnConfirm').click(function (e) {
            // Fill the "data" to be returned by the event

            popupData = getPopupData();
            _isDelete = false;

            if (validatePopupFields(popupData).isValidate) {
                $(popup_rootID + '#btnYes').click();
            }
        });

        //Delete button
        $(popup_rootID + '#btnDelete').click(function (e) {
            // Fill the "data" to be returned by the event
            popupData = getPopupData();
            _isDelete = true;

            if (validatePopupFields(popupData).isValidate) {
                $(popup_rootID + '#btnYes').click();
            }
        });

        // Drag the dialog
        $('#divDialog .content-default').draggable({
            scroll: false,
        });

        popup_registerStructureEvents();
    }

    function validateNumber(event) {
        var key = window.event ? event.keyCode : event.which;

        if (event.keyCode === 8 || event.keyCode === 46) {
            return true;
        }
        else if (key < 48 || key > 57) {
            return false;
        }
        else return true;
    };

    function getDays(firstDate, secondDate) {
        var oneDay = 24 * 60 * 60 * 1000; // hours*minutes*seconds*milliseconds

        var diffDays = Math.round(Math.abs((firstDate.getTime() - secondDate.getTime()) / (oneDay)));

        return diffDays;
    }

    //get data of form
    function getPopupData() {
        var form = '#divDialog';
        var beginHour = new Date(dateModule.getDefaultDateTime($(form).find('#txtPER_Ini').val() + ":" + $(form).find('#ddlEndMinutes_ini').val()));
        var endHour = new Date(dateModule.getDefaultDateTime($(form).find('#txtPER_Fim').val() + ":" + $(form).find('#ddlEndMinutes_fim').val()));

        var popupData = {
            id: $(form).find('#hAbsenceID').val(),
            collaboratorID: $(form).find('#hCollabID').val(),
            absenceReasonID: $(form).find('#dllAbsenceRasons').val(),
            absenceRuleID: $(form).find('#dllAbsenceRules').val(),
            contingentID: $(form).find('#hContingentID').val(),
            collaboratorQuotaID: $(form).find('#dllCollaboratorQuotas').val(),
            startDate: $(form).find('#txtStartDate').val().toMSDate(),
            endDate: $(form).find('#txtEndDate').val().toMSDate(),
            startHour: beginHour,
            endHour: endHour,
            isWorkstation: false,
            //chkWarning: $(form).find('#chkWarning')[0].checked,
        }

        eventObj.id = popupData.id;
        eventObj.collaboratorID = popupData.collaboratorID;
        eventObj.absenceReasonID = popupData.absenceReasonID;
        eventObj.absenceRuleID = popupData.absenceRuleID;
        eventObj.contingentID = (popupData.contingentID != null && popupData.contingentID > 0) ? popupData.contingentID : eventObj.contingentID;
        eventObj.collaboratorQuotaID = popupData.collaboratorQuotaID;
        eventObj.startDate = popupData.startDate;
        eventObj.endDate = popupData.endDate;
        eventObj.startHour = popupData.startHour;
        eventObj.endHour = popupData.endHour;
        //_noWarnings = popupData.chkWarning;

        return popupData;
    }

    function bindDropDown(element, list, key) {
        element.clearSelect();

        if (list && list.length > 0) {
            element.fillSelect(list, 'ID', key, true);
            element.removeAttr('disabled');
        }
        else {
            element.fillSelect([], 'ID', key, true);
            element.attr('disabled', 'disabled');
        }

        element.trigger('update');
    }

    function resetEventObj() {
        eventObj = {
            id: null,
            collaboratorID: null,
            absenceReasonID: null,
            absenceRuleID: null,
            contingentID: null,
            startDate: null,
            endDate: null,
            startHour: null,
            endHour: null,
            isWorkstation: null,
            isQuota: null,
            isReplaceTime: null,
            isRest: false,
        };
    }

    function popup_registerStructureEvents() {
        var absenceReason = ' #dllAbsenceRasons',
            absenceRule = ' #dllAbsenceRules',
            collaboratorQuota = ' #dllCollaboratorQuotas';

        var properties = getProperties();

        //Absence Reason
        var absenceReasonDropDown = $(popup_rootID + absenceReason);
        var absenceRuleDropDown = $(popup_rootID + absenceRule);
        var collaboratorQuotaDropDown = $(popup_rootID + collaboratorQuota);
        if (absenceReasonDropDown) {
            absenceReasonDropDown.change(function (event) {
                //Validation of workstantion
                eventObj.absenceReasonID = event.currentTarget.value;
                var contingents = properties.RestDayQuotas;
                for (var key in contingents) {
                    if (eventObj.absenceReasonID == contingents[key].ID) {
                        eventObj.isQuota = (contingents[key].IsQuota == "S") ? true : false;
                        eventObj.isReplaceTime = (contingents[key].IsReplaceTime == "S") ? true : false;
                        eventObj.MinimumDays = contingents[key].MinimumDays;
                        break;
                    }
                }
                $('#divDialog #txtMinimumDays').attr('value', eventObj.MinimumDays);

                //Contingent
                if (collaboratorQuotaDropDown && collaboratorQuotaDropDown.length > 0) {
                    if (eventObj.absenceReasonID == '') {
                        bindDropDown(collaboratorQuotaDropDown);
                    }
                    else {
                        getContingents(eventObj.collaboratorID, eventObj.absenceReasonID, eventObj.startDate, eventObj.endDate).done(function (listCollaboratorQuotas) {
                            bindDropDown(collaboratorQuotaDropDown, listCollaboratorQuotas, 'ContigentName');;
                            _listCollaboratorQuotas = listCollaboratorQuotas;
                            if (_listCollaboratorQuotas.length == 0) {
                                $('#divDialog #txtTotal').attr('disabled', 'disabled');
                                $('#divDialog #txtTotal').attr('value', '');
                                $('#divDialog #txtDeduction').attr('disabled', 'disabled');
                                $('#divDialog #txtDeduction').attr('value', '');
                                $('#divDialog #txtAvailability').attr('disabled', 'disabled');
                                $('#divDialog #txtAvailability').attr('value', '');
                                //$('#divDialog #txtMinimumDays').attr('value', '');
                            } else if (_listCollaboratorQuotas.length == 1) {
                                collaboratorQuotaDropDown.setSelectedValue(listCollaboratorQuotas[0].ID);
                                collaboratorQuotaDropDown.change();
                            }
                        });
                    }
                };

                //AbsenceRule
                if (absenceRuleDropDown && absenceRuleDropDown.length > 0) {
                    if (eventObj.absenceReasonID == '') {
                        bindDropDown(absenceRuleDropDown);
                    }
                    else {
                        getAbsenceRules(eventObj.collaboratorID, eventObj.absenceReasonID, eventObj.startDate).done(function (listAbsenceRules) {
                            bindDropDown(absenceRuleDropDown, listAbsenceRules, 'RuleDescription');;
                            var elemntDisable;
                            if (eventObj.isReplaceTime) {
                                absenceRuleDropDown.attr('disabled', 'disabled');

                                $('#divDialog #txtPER_Ini').attr('disabled', 'disabled');
                                elemntDisable = $('#divDialog #minutes-ini')[0];
                                elemntDisable.getElementsByClassName('customSelect')[0].className = 'customSelect customSelectDisabled';
                                $('#divDialog #txtPER_Fim').attr('disabled', 'disabled');
                                elemntDisable = $('#divDialog #minutes-fim')[0];
                                elemntDisable.getElementsByClassName('customSelect')[0].className = 'customSelect customSelectDisabled';
                            } else {
                                absenceRuleDropDown.removeAttr('disabled');

                                $('#divDialog #txtPER_Ini').removeAttr('disabled');
                                elemntDisable = $('#divDialog #minutes-ini')[0];
                                elemntDisable.getElementsByClassName('customSelect')[0].className = 'customSelect';
                                $('#divDialog #txtPER_Fim').removeAttr('disabled');
                                elemntDisable = $('#divDialog #minutes-fim')[0];
                                elemntDisable.getElementsByClassName('customSelect')[0].className = 'customSelect';
                            }
                        });
                    }
                };
            });
        }

        if (collaboratorQuotaDropDown) {
            collaboratorQuotaDropDown.change(function (event) {
                collaboratorQuotaID = event.currentTarget.value;
                var collaboratorQuotas = getProperties().CollaboratorQuotas;
                for (var key in collaboratorQuotas) {
                    if (collaboratorQuotaID == collaboratorQuotas[key].ID) {
                        eventObj.contingentID = collaboratorQuotas[key].ContingentID;

                        //Preencher os dados no form
                        $('#divDialog #txtTotal').attr("value", collaboratorQuotas[key].TotalAvailability);
                        $('#divDialog #txtDeduction').attr("value", collaboratorQuotas[key].Deduction);
                        $('#divDialog #txtAvailability').attr("value", collaboratorQuotas[key].TotalAvailability - collaboratorQuotas[key].Deduction);

                        $('#divDialog #txtTotal').attr('disabled', 'disabled');
                        $('#divDialog #txtDeduction').attr('disabled', 'disabled');
                        $('#divDialog #txtAvailability').attr('disabled', 'disabled');
                        break;
                    }
                }
            });
        }

        if (absenceRuleDropDown) {
            absenceRuleDropDown.change(function (event) {
                absenceRuleID = event.currentTarget.value;
                var elemntDisable;

                if (absenceRuleID) {
                    $('#divDialog #txtPER_Ini').attr('disabled', 'disabled');
                    elemntDisable = $('#divDialog #minutes-ini')[0];
                    elemntDisable.getElementsByClassName('customSelect')[0].className = 'customSelect customSelectDisabled';
                    $('#divDialog #txtPER_Fim').attr('disabled', 'disabled');
                    elemntDisable = $('#divDialog #minutes-fim')[0];
                    elemntDisable.getElementsByClassName('customSelect')[0].className = 'customSelect customSelectDisabled';
                } else {
                    absenceRuleDropDown.removeAttr('disabled');

                    $('#divDialog #txtPER_Ini').removeAttr('disabled');
                    elemntDisable = $('#divDialog #minutes-ini')[0];
                    elemntDisable.getElementsByClassName('customSelect')[0].className = 'customSelect';
                    $('#divDialog #txtPER_Fim').removeAttr('disabled');
                    elemntDisable = $('#divDialog #minutes-fim')[0];
                    elemntDisable.getElementsByClassName('customSelect')[0].className = 'customSelect';
                }
            });
        }
    }

    function getProperties() {
        var properties = {
            SelectCellDate: eventObj.startDate,
            EmployeeID: eventObj.collaboratorID,
            AbsenceReasonID: eventObj.absenceReasonID,
            ContingentID: eventObj.contingentID,
            AbsenceRulesID: eventObj.absenceRuleID,
            RestDayQuotas: _restDayQuotas,
            CollaboratorQuotas: _listCollaboratorQuotas,
            AbsenceID: eventObj.id
        };
        return properties;
    }

    function validatePopupFields(ev) {
        var beginDate,
        endDate,
        beginHour = null,
        endHour = null,
        isValidate = false;

        if (ev.absenceReasonID != "" && ev.absenceReasonID != null) {
            //Validation of dates
            beginDate = ev.startDate;
            endDate = ev.endDate;
            beginHour = ev.startHour;
            endHour = ev.endHour;

            if (eventObj.isReplaceTime != null) {
                if (eventObj.isReplaceTime) {
                    eventObj.isWorkstation = false;
                } else {
                    eventObj.isWorkstation = true;
                }
            }

            //Validation of absence rule
            if (!eventObj.isReplaceTime) {
                if (eventObj.absenceRuleID == "" || eventObj.absenceRuleID == null) {
                    if (isDate(beginHour) || isDate(endHour)) {
                        if (beginHour.getHours() > 23 || endHour.getHours() > 23) {
                            moveCollaboratorsModule.createDialogExtra(0, _globalResources.getResource().ErrorTitle, _globalResources.getResource().schedule.restDayView.lightbox.messages.IvalidHour);
                        } else if ((beginHour.getHours() == 0 && beginHour.getMinutes() == 0) && (endHour.getHours() == 0 && endHour.getMinutes() == 0)) {
                            moveCollaboratorsModule.createDialogExtra(0, _globalResources.getResource().ErrorTitle, _globalResources.getResource().schedule.restDayView.lightbox.messages.HoursRequired);
                        } else if ((beginDate == "") || (endDate == "")) {
                            moveCollaboratorsModule.createDialogExtra(0, _globalResources.getResource().ErrorTitle, _globalResources.getResource().schedule.restDayView.lightbox.messages.DatesRequired);
                        } else if (beginDate.toDefaultMomentDate()._d > endDate.toDefaultMomentDate()._d) {
                            moveCollaboratorsModule.createDialogExtra(0, _globalResources.getResource().ErrorTitle, _globalResources.getResource().schedule.restDayView.lightbox.messages.BeginDateGreaterThanEnd);
                        } else if (!(_isDelete) && (eventObj.MinimumDays > (getDays(beginDate.toDefaultMomentDate()._d, endDate.toDefaultMomentDate()._d) + 1))) {
                            createDialogWarning(1, _globalResources.getResource().WarningTitle, _globalResources.getResource().schedule.restDayView.lightbox.messages.MinimumDays(eventObj.MinimumDays));
                        } else { isValidate = true; }
                    }
                } else {
                    beginHour = null;
                    endHour = null;
                    isValidate = true; }
            } else {
                if ((beginDate == "") || (endDate == "")) {
                    moveCollaboratorsModule.createDialogExtra(0, _globalResources.getResource().ErrorTitle, _globalResources.getResource().schedule.restDayView.lightbox.messages.DatesRequired);
                } else if (beginDate.toDefaultMomentDate()._d > endDate.toDefaultMomentDate()._d) {
                    moveCollaboratorsModule.createDialogExtra(0, _globalResources.getResource().ErrorTitle, _globalResources.getResource().schedule.restDayView.lightbox.messages.BeginDateGreaterThanEnd);
                } else if (!(_isDelete) && (eventObj.MinimumDays > (getDays(beginDate.toDefaultMomentDate()._d, endDate.toDefaultMomentDate()._d) + 1))) {
                    createDialogWarning(1, _globalResources.getResource().WarningTitle, _globalResources.getResource().schedule.restDayView.lightbox.messages.MinimumDays(eventObj.MinimumDays));
                } else { isValidate = true; }
            }
        } else {
            moveCollaboratorsModule.createDialogExtra(0, _globalResources.getResource().ErrorTitle, _globalResources.getResource().schedule.restDayView.lightbox.messages.AbsenceReasonRequired);
        }

        return {
            beginDate: beginDate,
            endDate: endDate,
            beginHour: beginHour,
            endHour: endHour,
            isValidate: isValidate,
        }
    }

    function createDialogWarning(dialogType, title, message) {
        // Create it if it doesn't exist
        if (!document.getElementById('divDialogWarning')) {
            $('body').append('<div id="divDialogWarning" class="dialog-default" style="display:none"></div>');
        }
        var html = '<div class="overlay" style="display:block"></div> ' +
                        '<div class="content-default"> ' +
                            '<a href="#" id="btnClose" class="ir bt-close-dialog" title="' +
                                _globalResources.getResource().DialogButtonClose + '"> ' +
                            '</a>' +
                        '<div class="content"> ' +
                            '<strong class="tt-title">' + title + '</strong>' +
                            '<hr>' +
                            '<p>' + message + '</p>' +
                            (dialogType == 0 ? '<a id="btnOk" class="btn-dialog bt" href="#" autofocus="autofocus">' +
                                                     _globalResources.getResource().DialogButtonOk +
                                               '</a>' :
                                                '<a id="btnExtraYes" class="btn-dialog bt" href="#" autofocus="autofocus">' +
                                                     _globalResources.getResource().DialogButtonYes +
                                                '</a>' +
                                                '<a id="btnExtraNo" class="btn-dialog bt" href="#">' +
                                                     _globalResources.getResource().DialogButtonNo +
                                                '</a>') +
                        '</div>' +
                    '</div>';

        showDialog(html);
    }

    function showDialog(dialog, callback) {
        $("#divDialogWarning").html(dialog);
        $("#divDialogWarning").fadeIn(200);
        $("#divDialogWarning .content-default").css("top", $("body").height() / 2 - $("#divDialogWarning .content-default .content").height() / 2 - 70 + "px");

        registerEventClose(callback);
        registerEventNo(callback);
        registerEventYes(callback);
    }

    function registerEventClose(callback) {
        customControlsModule.registerKeyUpEsc(function () {
            $("#divDialogWarning #btnClose").trigger('click');
        });
        $("#divDialogWarning #btnClose").off();
        $("#divDialogWarning #btnClose").on('click', function () {
            $("#divDialogWarning").fadeOut(200);
            if (callback != null) {
                callback();
            }
        });
    }

    function registerEventNo(callback) {
        $("#divDialogWarning #btnExtraNo").off();
        $("#divDialogWarning #btnExtraNo").on('click', function () {
            $("#divDialogWarning").fadeOut(200);
            if (callback != null)
                callback();
        });
    }

    function registerEventYes(callback) {
        $("#divDialogWarning #btnExtraYes").off();
        $("#divDialogWarning #btnExtraYes").on('click', function () {
            $(popup_rootID + '#btnYes').click();
            $("#divDialogWarning").fadeOut(200);
            if (callback != null)
                callback();
        });
    }

    function init(successResult) {
        _isFirstTime = true;
        toggleRestDayView(true);
        registerEvents();
        scheduleEventsModule.resetScheduler();
        attachSchedulerEvents();
        if (successResult.CollaboratorEventsList) {
            scheduleEventsModule.initDateTypes(successResult.EventTypePropertiesList);
            var resHandlerAusencia = scheduleEventsModule.handleCollaboratorsTree(successResult.CollaboratorEventsList, handleDateAusencia, { allCollabs: false, shortenNames: true });

            _dhtmlxSchedulerSettings.properties.timelineConfigs.y_unit = resHandlerAusencia.groups;
            _dhtmlxSchedulerSettings.properties.allCollaborators = resHandlerAusencia.collabs;
            _AllCollaborators = resHandlerAusencia.collabsIds;
            _eventsRestPrint = resHandlerAusencia.events;
            scheduleBaseTimelineModule.init(_dhtmlxSchedulerSettings);

            scheduleBaseTimelineModule.addData(resHandlerAusencia.events);
            scheduleBaseTimelineModule.getEventHandlers().onViewChangeCallback();
        } else {
            dialogModule.createDialog(0, _globalResources.getResource().ErrorTitle,
                _globalResources.getResource().CommunicationError);
        }
    }

    return {
        init: init,
        loadView: loadView,
        initPopupSwitchSchedule: initPopupSwitchSchedule,
        closeRestDayYearView: closeRestDayYearView,
        refreshRestDayView: refreshRestDayView,
        getEventsHash: getEventsHash,
        getWorkTypeLabel: getWorkTypeLabel,
        addToSelectedCollaborators: addToSelectedCollaborators,
        removeFromSelectedCollaborators: removeFromSelectedCollaborators,
        getEventSpecificDataFunctions: getEventSpecificDataFunctions,
        existsOnSelectedCollaborators: existsOnSelectedCollaborators,
        getAllCollaborators: getAllCollaborators,
        getCollabEvents: getCollabEvents,
        getProperties: getProperties,
        getPopupData: getPopupData,
    };
}();
