﻿var scheduleDailyDetailModule = function () {

    var _unitID, _sectionID, _workstationTypeID, _searchTermCollaborator, _date;

    function setVisibleArea() {
        var heightParent = parseInt($('#divViewDailykDetail').parent().css('height')),
            height = parseInt($('#tblViewDaily').css('height'));

        $('#divViewDailyDetailScroll').css({ 'height': (heightParent - height) + 'px' });
    }

    function myParent() {
        return $("#tabWeek");
    }

    function mySelf() {
        return myParent().find("#daily-detail");
    }

    function loadView(unitID, sectionID, workstationTypeID, date, searchTermCollaborator) {
        if (scheduleModule.isCurrentWeekTab()) {

            scheduleModule.getMainPageLoader().show();

            _unitID = _unitID,
            _sectionID = sectionID,
            _workstationTypeID = workstationTypeID,
            _searchTermCollaborator = searchTermCollaborator,
            _date = date;

            //Serealiza parametros
            var parameters = JSON.stringify({
                unitID: unitID,
                sectionID: sectionID,
                workStationTypeId: workstationTypeID,
                date: date.toMSDate(),
                searchTermCollaborator: searchTermCollaborator
            });

            $.ajax({
                url: urlConfig.schedule.showDailyDetail,
                data: parameters,
                success: function (response) {
                    if (response) {
                        // Converte o retorno em um objeto JSON
                        var result = JSON.parse(response);
                        if (result) {
                            scheduleWeekDetailModule.hide();
                            $("#divTitle").text(_globalResources.getResource().schedule.header.DailyDetailTitle);
                            $("#divSubtitle").empty().hide();
                            if (result.hasSuccess) {
                                mySelf().show().empty().html(result.successResult);
                            } else {
                                mySelf().show().empty().html(result.errorResult);
                                registerEvents();
                            }
                        }
                    } else {
                        // Retorna a mensagem de erro
                        dialogModule.createDialog(0, _globalResources.getResource().ErrorTitle, _globalResources.getResource().CommunicationError);
                    }

                    scheduleModule.getMainPageLoader().hide();
                }
            });
        }
    }

    function printReport() {
        var url = urlConfig.reports.dailyDetailSchedule;

        dailyDetailScheduleReportModule.printReport(url, _unitID, _sectionID, _workstationTypeID, _date, _searchTermCollaborator);
    }

    function close(event) {
        var btnComeBack = myParent().find("#btnWeekBack");

        scheduleModule.getMainPageLoader().show();

        scheduleWeekDetailModule.show();
        mySelf().empty().hide();

        if (event) {
            scheduleModule.getMainPageLoader().hide();
        }
    }

    function registerEvents() {
        var btnComeBack = myParent().find("#btnWeekBack");
        btnComeBack.removeClass("button-disabled");
        btnComeBack.removeProp("disabled");
        btnComeBack.off("click").on("click", close);

        myParent().find('#btnDetailPrint').off('click').on('click', printReport);
    }

    //#region Init
    function init() {
        registerEvents();
        setVisibleArea();
        scrollModule.createScroll('divViewDailyDetailScroll');
    }
    //endregion

    return {
        init: init,
        loadView: loadView,
        close: close
    };

}();