﻿var scheduleDropDownEditTimeModule = function () {

    var sectionParent = null;
    var scheduleID = null;
    var isPolyvalent = false;

    //#region Events - Selects   

    function changeIntervalSelect(e) {
        var self = $(e.target),
            index = self.data('index'),
            oldIntervalID = scheduleEditCollaboratorTime.getRangeSettings()[index].IntervalTypeID;
        // Seta na range o valor do select de tipo de intervalo selecionado
        scheduleEditCollaboratorTime.getRangeSettings()[index].IntervalTypeID = self.val();

        // Se for "Sem Intervalo"
        if (self.val() === 'S') {
            // Aciona o click do botão de exclusão ao lado do select do tipo de intervalo
            sectionParent.find('#btnEditTimeDelete_' + index).trigger('click');
        } else if (oldIntervalID === 'S') { // só irá recalcular se o tipo anterior for "sem intervalo"
            // Para os demais tipos
            // Registra novamente o click do botão de exclusão ao lado do select do tipo de intervalo
            sectionParent.find('#btnEditTimeDelete_' + index).on('click', scheduleEditCollaboratorTime.deleteEditTime).removeClass('button-disabled');
            // Remove o desabilitado dos horários conforme o tipo de visualização
            scheduleManualEditCollaboratorTime.enabledInterval(index);
            scheduleVisualEditCollaboratorTime.enabledInterval(index);
        }
    }

    function changeSectionSelect(e) {
        var self = $(e.target),
            rangeSettings = scheduleEditCollaboratorTime.getRangeSettings(),
            index = self.data("index"),
            ddlWorkstationType = sectionParent.find("#ddlWorkstationType_" + index),
            ddlWorkstation = sectionParent.find("#ddlWorkstation_" + index);

        rangeSettings[index].SectionID = self.val();
        // Indica que houve alguma alteração nos ranges de valores
        rangeSettings[index].HasEdit = true;

        if (self.val() == '' || self.val() == null) {
            ddlWorkstationType.clearSelect(1);
            ddlWorkstationType.trigger("change");
            ddlWorkstation.clearSelect(1);
            ddlWorkstation.trigger("change");
            return;
        }

        workstationTypeModule.getScheduleWorkstationTypes(self.val(), scheduleEditCollaboratorTime.getCollaboratorID())
         .done(function (listWorkStationTypes) {

             ddlWorkstationType.clearSelect();
             ddlWorkstationType.fillSelect(listWorkStationTypes, 'ID', 'Name', true);
             ddlWorkstationType.change(changeWorkstationTypeSelect);
             ddlWorkstationType.setSelectedValue(ddlWorkstationType.data("initial"));
             ddlWorkstationType.trigger("change");
         });
    }

    function changeWorkstationTypeSelect(e) {
        var self = $(e.target),
            rangeSettings = scheduleEditCollaboratorTime.getRangeSettings(),
            index = self.data("index"),
            ddlWorkstation = sectionParent.find("#ddlWorkstation_" + index);

        // Atribui o novo valor do WorkstationType
        rangeSettings[index].WorkstationTypeID = self.val();
        // Indica que houve alguma alteração nos ranges de valores
        rangeSettings[index].HasEdit = true;

        if (self.val() == '' || self.val() == null) {
            self.setSelectedValue('');
            ddlWorkstation.clearSelect(1);
            ddlWorkstation.trigger("change");
            return;
        }

        var parameters = JSON.stringify({
            collaboratorID: sectionParent.data("id"),
            sectionID: rangeSettings[index].SectionID,
            workStationTypeID: self.val(),
            date: scheduleModule.getSelectedWeekDay(),
            beginHour: moment.utc(rangeSettings[index].BeginHourWork).format(_globalResources.getResource().FormatTime),
            endHour: moment.utc(rangeSettings[index].EndHourWork).format(_globalResources.getResource().FormatTime)
        });

        workstationModule.getAvailabilityWorkstations(parameters)
         .done(function (listWorkStations) {

             ddlWorkstation.clearSelect(1);
             ddlWorkstation.fillSelect(listWorkStations, 'ID', 'Name', true);
             ddlWorkstation.setSelectedValue(ddlWorkstation.data("initial"));
             ddlWorkstation.trigger("change");
         });
    }

    function changeWorkstationSelect(e) {
        var self = $(e.target),
            index = self.data("index"),
            rangeSettings = scheduleEditCollaboratorTime.getRangeSettings();

        if (self.val() == '' || self.val() == null) {
            self.setSelectedValue('');
        }

        // Atribui o novo valor do Workstation
        rangeSettings[index].WorkstationID = self.val();
        // Indica que houve alguma alteração nos ranges de valores
        rangeSettings[index].HasEdit = true;
    }

    //#endregion Events - Selects

    function configBehaviors() {
        var rangeSettings = scheduleEditCollaboratorTime.getRangeSettings(),
            sectionParent = scheduleEditCollaboratorTime.getSectionParent();

        $(rangeSettings).each(function (index) {
            // Desabilita o slider caso seja polivalente
            if (rangeSettings[index].IsPolyvalent) {
                scheduleManualEditCollaboratorTime.disabledInterval(index);
            }

            if (rangeSettings[index].IsMainRange) {
                scheduleID = rangeSettings[index].ScheduleID;
            } else if (!rangeSettings[index].IsInterval) {
                isPolyvalent = (isPolyvalent === true ? isPolyvalent : rangeSettings[index].IsPolyvalent);
            }

            // Remove o evento do botão de excluir quando for Intervalo e Sem Intervalo
            if (rangeSettings[index].IsInterval &&
                rangeSettings[index].IsInterval === true &&
                rangeSettings[index].IntervalTypeID === 'S') {

                sectionParent.find('#btnEditTimeDelete_' + index).off('click').on('click', scheduleEditCollaboratorTime.deleteTime);
                sectionParent.find(".js-container-type-edit[data-index='" + index + "']").attr('disabled', 'disabled');
            }
        });
    }

    function registerEvents() {
        // Registra o change dos selects
        sectionParent.find('[name="interval"]').on('change', changeIntervalSelect);
        sectionParent.find('[name="section"]').off('change').on('change', changeSectionSelect);
        sectionParent.find('[name="workstation"]').off('change').on('change', changeWorkstationSelect);
    }

    function init() {
        sectionParent = scheduleEditCollaboratorTime.getSectionParent();
        // Registra os eventos dos selects
        registerEvents();

        configBehaviors();

        sectionParent.find('[name="section"]').each(function (index) {
            $(this).trigger('change');
        });
    }

    return {
        init: init
    }

}();