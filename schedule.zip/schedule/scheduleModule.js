var scheduleModule = function () {

    var sectionParent = null,
        weekDaysCarousel = null,
        initHeightTopArea = 0,
        initHeightBottomArea = 0,
        initHeightPeriodHeader = 0,
        appliedSelectReportModel = false,
        // Constants
        HEADER_PROCESS_TAB = "processTab",
        HEADER_DATA_TAB = "dataTab",
        HEADER_MONTH_DATA_TAB = "monthDataTab",
        HEADER_WEEK_TAB = "weekTab",
        HEADER_REST_TAB = "restTab",
        PROCESS_TAB = "tabProcessContainer",
        DATA_TAB = "tabData",
        MONTH_DATA_TAB = "tabMonthData",
        WEEK_TAB = "tabWeek",
        REST_TAB = "tabRest",
        SELECTED_TAB_CSS = "selected-tab",
        NO_DISPLAY_CSS = "no-display",
        operations = null,
        _pageLoaders = [],
        _selectedCollabs = [],
        _actionMenus = ['#divReportOptions', '#divReprocessOptions', '#divApproveOptions'];

    //#region Tabs Helper
    function getSelectedTab() {
        return $("#divHeaderTabs").find("." + SELECTED_TAB_CSS).attr("id");
    }

    function isCurrentProcessTab() {
        return $("#divSchedule").length > 0 && getSelectedTab() == HEADER_PROCESS_TAB;
    }

    function isCurrentDataTab() {
        return getSelectedTab() == HEADER_DATA_TAB;
    }

    function isCurrentMonthDataTab() {
        return getSelectedTab() == HEADER_MONTH_DATA_TAB;
    }

    function isCurrentWeekTab() {
        return getSelectedTab() == HEADER_WEEK_TAB;
    }

    function isCurrentRestTab() {
        return getSelectedTab() == HEADER_REST_TAB;
    }

    function clickProcessTab() {
        if (sectionParent != null) {
            return sectionParent.find("#ulTabs").find('a#' + HEADER_PROCESS_TAB).trigger('click');
        }
    }
    //#endregion

    //#region Views Helper
    function getSectionParent() {
        return $("#divSchedule");
    }

    function setSectionParent() {
        sectionParent = $("#divSchedule");
    }

    function getSelectedView() {
        return $("#divViewsArea").attr('data-view');
    }

    function getBottonViewPageLoader() {
        return $("#bottonViewPageLoader");
    }

    function getTopViewPageLoader() {
        return $("#topViewPageLoader");
    }

    function getMainPageLoader() {
        return sectionParent.find("#schedulePageLoader");
    }

    function getSaveArea() {
        return sectionParent.find("#divSaveArea");
    }

    function showPageLoader(id) {
        _pageLoaders.push(id);
        getMainPageLoader().show();
    }

    function hidePageLoader(id) {
        var index = -1;
        if ((index = $.inArray(id, _pageLoaders)) > -1) {
            _pageLoaders.splice(index, 1);
        }

        if (_pageLoaders.length === 0) {
            getMainPageLoader().hide();
        }
    }
    //#endregion

    //#region Carousel Functions
    function getWeekDaysCarousel() {
        return weekDaysCarousel;
    }

    function weekDayCallback(selectedDate) {
        updateSchedule(selectedDate);
    }

    function getSelectedWeekDay() {
        return weekDaysCarousel.getSelectedDate();
    }
    //#endregion

    //#region Config Screen
    function setSelectedSettings(unitList, selectedUnitID, sectionList, selectedSectionID, selectedStartDate, selectedEndDate) {
        var sectionListIDs  = [],
            workStationList = [];

        // Configura a div de botões com a largura padrão
        var width = sectionParent.find('.schedule-container').width();
        sectionParent.find("#divButtonsArea").width(width);

        // Configura o page loader
        sectionParent.find('#schedulePageLoader').css({
            'top': initHeightPeriodHeader + 'px',
            'width': width + 'px'
        });

        sectionParent.find("#ddlSectionMulti").multiselect({
            selectedList: 1,
            open: function () {
                $("#ddlSectionMulti").val() != null ? sectionListIDs = $("#ddlSectionMulti").val() : sectionListIDs = [''];
            },
            close: function () {
                //Close Event control
                if ( $("#ddlSectionMulti").val() != null && sectionListIDs.sort().toString() != $("#ddlSectionMulti").val().sort().toString())
                {
                    //Chama métodos para reload na tela com o parâmetro novo
                    var selectedDate = $('#startDate').val();

                    //It's only possible to select WorkstationTypes where one and only one Section is selected
                    //otherwise, WorkstationTypes must be disabled
                    if ($("#ddlSectionMulti").val().length > 1)
                    {
                        $("#ddlWorkstationType").multiselect('disable');
                    }
                    else
                    {
                        $("#ddlWorkstationType").multiselect('enable');
                    }

                    //Load Workstation types
                    if ($("#ddlSectionMulti").val().length > 1) {
                        $("#ddlWorkstationType").clearSelect();
                        $("#ddlWorkstationType").fillSelect([], 'ID', 'Name', true);
                        $("#ddlWorkstationType").find('option').first().remove();
                        $("#ddlWorkstationType").multiselect('refresh');
                    } else {
                        workstationTypeModule.getWorkstationTypes($("#ddlSectionMulti").val()[0])
                            .done(function (workstationTypes) {
                                //Carrega dados nos tipos de posto
                                $("#ddlWorkstationType").clearSelect();
                                $("#ddlWorkstationType").fillSelect(workstationTypes, 'ID', 'Name', true);
                                $("#ddlWorkstationType").find('option').first().remove();
                                $("#ddlWorkstationType").multiselect('refresh');
                            });
                    }

                    //Update Chart and CollaboratorsView
                    scheduleChartModule.updateChart($("#divChartArea"), selectedDate, false);
                    scheduleChartCollaboratorModule.loadView($("#ddlUnit").val(), $("#ddlSection").val(), null, selectedDate, null, null);
                }
            },
        }).multiselectfilter();

        sectionParent.find("#ddlWorkstationType").multiselect({
            selectedList: 1,
            open: function () {
                $("#ddlWorkstationType").val() != null ? workStationList = $("#ddlWorkstationType").val() : workStationList = [''];
            },
            close: function () {
                //Close event control
                if ($("#ddlSection").val() != null) {
                    var selectedDate = weekDaysCarousel.getSelectedDate(),
                        startDate = $('#startDate').val(),
                        endDate = $("#endDate").val();

                    //Events to handle Update Charts functions only when necessary
                    //The goal is to not Update Chart if the user doesn't change his selection
                    if ($("#ddlWorkstationType").val() != null && workStationList.sort().toString() != $("#ddlWorkstationType").val().sort().toString()) {
                        //Carrega dados na lista de Workstation types
                        if ($("#ddlSection").length > 1) {
                            $("#ddlWorkstationType").clearSelect;
                            $("#ddlWorkstationType").multiselect('refresh');

                        } else {
                            //Update Chart and CollaboratorsView
                            scheduleChartModule.updateChart($("#divChartArea"), selectedDate, false);
                            scheduleChartCollaboratorModule.loadView($("#ddlUnit").val(), $("#ddlSection").val(), null, selectedDate, null, null);
                            scheduleChartCollaboratorTableViewModule.loadView(selectedDate, null, null, null, null);
                            scheduleWeekDetailModule.loadView($("#ddlUnit").val(), $("#ddlSection").val(), $("#ddlWorkstationType").val(), startDate, endDate);
                            scheduleAbsenceModule.loadView(selectedDate);
                        }

                    }
                    else {
                        $("#ddlWorkstationType").clearSelect;
                        $("#ddlWorkstationType").multiselect('refresh');
                        if (!$("#ddlWorkstationType").val() && workStationList != "")
                        {
                            //Update Chart and CollaboratorsView
                            scheduleChartModule.updateChart($("#divChartArea"), selectedDate, false);
                            scheduleChartCollaboratorModule.loadView($("#ddlUnit").val(), $("#ddlSection").val(), null, selectedDate, null, null);
                            scheduleChartCollaboratorTableViewModule.loadView(selectedDate, null, null, null, null);
                            scheduleWeekDetailModule.loadView($("#ddlUnit").val(), $("#ddlSection").val(), $("#ddlWorkstationType").val(), startDate, endDate);
                            scheduleAbsenceModule.loadView(selectedDate);
                        }
                    }
                }
            },
        }).multiselectfilter();

        // Configura qual a view inicial
        //sectionParent.find("#divViewsArea").attr("data-view", scheduleChartCollaboratorModule.myName());
        sectionParent.find("#divViewsArea").attr("data-view", scheduleChartCollaboratorTableViewModule.myName());

        //Popula DropDown Unist
        sectionParent.find("#ddlUnit").clearSelect();
        sectionParent.find("#ddlUnit").fillSelect(unitList, 'ID', 'Name');

        //Popula DropDown Sections
        sectionParent.find("#ddlSection").clearSelect();
        sectionParent.find("#ddlSection").fillSelect(sectionList, 'ID', 'Name', true);

        //sectionParent.find("#ddlSectionMulti").fillSelect(sectionList, 'ID', 'Name', true);
        //sectionParent.find("#ddlSectionMulti").find('option').first().remove();

        // seta os dados que foram selecionados pelo usuario na modal na tela de escalas
        sectionParent.find("#ddlUnit").setSelectedValue(selectedUnitID);
        sectionParent.find("#ddlSection").setSelectedValue(selectedSectionID);
        //sectionParent.find("#ddlSectionMulti").setSelectedValue(selectedSectionID);

        //Carrega dados na lista de Workstation types
        workstationTypeModule.getWorkstationTypes(selectedSectionID)
            .done(function (workstationTypes) {
                //Carrega dados nos tipos de posto
                $("#ddlWorkstationType").clearSelect();
                $("#ddlWorkstationType").fillSelect(workstationTypes, 'ID', 'Name', true);
                $("#ddlWorkstationType").find('option').first().remove();
                $("#ddlWorkstationType").multiselect('refresh');
            });

        // seta as datas na tela de escala
        sectionParent.find("#startDate").datepicker('setDate', selectedStartDate);
        sectionParent.find("#endDate").datepicker('setDate', selectedEndDate);

        weekDaysCarousel.loadWeekDays(selectedStartDate, selectedEndDate);

        setTimeout(function () {
            //Chama função da Escala para Carrega informações na tela
            updateSchedule(selectedStartDate, true);
        }, 300);

        sectionParent.find("#schedulePageLoader").fadeOut(300);

        // Refresh MultiSelect List
        //sectionParent.find("#ddlSectionMulti").multiselect('refresh');
    }

    // TODO: move to lcmModule
    function getLCMWeeks(elemId) {
        var adaptVal = parseInt($('#' + elemId).text(), 10);
        return !isNaN(adaptVal) ? adaptVal : 1;
    }

    function adjustEndDate(nWeeks) {
        var startDateVal = $('#startDate').val();
        var endDate = customControlsModule.calcEndDate(startDateVal, nWeeks);
        $('#endDate').datepicker('setDate', endDate);

        var endDateVal = $('#endDate').val();
        weekDaysCarousel.loadWeekDays(startDateVal, endDateVal);
    }
    //#endregion

    //#region Actions
    function updateSchedule(selectedDate, isFirstTime) {

        // Valida se a data inicial é uma segunda-feira
        if (!customControlsModule.isInValidDayOfWeek($("#startDate").val(), 1))
            return;

        // Valida se a data final é um domingo
        if (!customControlsModule.isInValidDayOfWeek($("#endDate").val(), 0))
            return;

        // Remove qualquer estilo de erro que possa ter sido inserido em passos anteriores
        validateModule.removeStyleError("#startDate");
        validateModule.removeStyleError("#endDate");

        if (!selectedDate)
            selectedDate = getSelectedWeekDay();

        if (selectedDate != undefined) {
            var unitID = $("#ddlUnit").val(),
                sectionID = $("#ddlSection").val(),
                workstationTypeID = parseInt($("#ddlWorkstationType").val()),
                endDate = $("#endDate").val();

            setTimeout(function () {
                // Fecha o filtro
                sectionParent.find('#btnFilter').trigger('dblclick');
                scheduleEditCollaboratorTime.closeEdit();
                updateLCM(sectionID, workstationTypeID);
                scheduleViewModule.loadView(unitID, sectionID, workstationTypeID, selectedDate, isFirstTime, false);
                scheduleMonthTimelineModule.loadView(unitID, sectionID, workstationTypeID, operations, selectedDate, endDate);
                scheduleWeekDetailModule.loadView(unitID, sectionID, workstationTypeID, selectedDate, endDate);
                scheduleProcessModule.getStatusProcess();
                scheduleProcessModule.registerTimer();
                scheduleRestDaysTimelineModule.loadView(unitID, sectionID, workstationTypeID, selectedDate, endDate);
            }, 300);
        }
    }

    function updateLCM(sectionID, workstationTypeID) {
        // TODO: get the ids from the same source: here and lcmModule
        var lcmValSchedule = 'lcmValSchedule',
            lcmContainerSchedule = 'lcmContainerSchedule',
            lcmDivContainerSchedule = 'lcmDivContainerSchedule';

        $('#' + lcmDivContainerSchedule).hide();

        if (workstationTypeID) {
            loadWorkstationTypeLCM(workstationTypeID, lcmDivContainerSchedule, lcmContainerSchedule, lcmValSchedule);
        }
        else {
            loadSectionLCM(sectionID, lcmDivContainerSchedule, lcmContainerSchedule, lcmValSchedule);
        }
    }

    function loadSectionLCM(sectionId, lcmDivContainerSchedule, lcmContainerSchedule, lcmValSchedule) {
        sectionModule.loadSectionDetail(sectionId)
            .done(function (obj) {
                setAndDisplayLCM(lcmDivContainerSchedule, lcmContainerSchedule, lcmValSchedule, obj);
            });
    }

    function loadWorkstationTypeLCM(workstationId, lcmDivContainerSchedule, lcmContainerSchedule, lcmValSchedule, isLCMHidden) {
        workstationTypeModule.loadWorkstationTypeDetail(workstationId)
            .done(function (obj) {
                setAndDisplayLCM(lcmDivContainerSchedule, lcmContainerSchedule, lcmValSchedule, obj);
            });
    }

    function setAndDisplayLCM(lcmDivContainerSchedule, lcmContainerSchedule, lcmValSchedule, obj) {
        lcmModule.setDefaultLCMSchedule(obj.Adaptability);
        lcmModule.applyLCMValSchedule(lcmDivContainerSchedule, lcmContainerSchedule, lcmValSchedule, obj.Adaptability);
    }

    function applyFilter(event, sortByName, orderBy) {
        var divFilter = sectionParent.find("#divFilter"),
            collaboratorName = divFilter.find('#txtFilterCollaborator').val(),
            workLoad = divFilter.find('#txtFilterWorkLoad').val();

        var unitID = $("#ddlUnit").val(),
               sectionID = $("#ddlSection").val(),
               //workstationTypeID = parseInt($("#ddlWorkstationType").val()),
               endDate = $("#endDate").val(),
               selectedDate = getSelectedWeekDay();

        if (divFilter.is(':visible') || orderBy) {

            var workstationTypeIDsToInt = [];
            if ($("#ddlWorkstationType").val() != null && $("#ddlWorkstationType").val() != "") {
                workstationTypeIDsToInt = $("#ddlWorkstationType").val().map(function (item) {
                    return parseInt(item, 10);
                });
            }
            scheduleViewModule.loadView(unitID, sectionID, workstationTypeIDsToInt, selectedDate, false, true, collaboratorName, workLoad, sortByName, orderBy);
            scheduleWeekDetailModule.loadView(unitID, sectionID, workstationTypeIDsToInt, selectedDate, endDate, collaboratorName);
        }
    }

    function showViewArea(e) {
        var self = $(e.target);

        // Configura qual a view atual
        // Limpa qualquer style customizado para uma view
        getBottonViewPageLoader().show();
        sectionParent.find("#divViewsArea").removeAttr('style');
        sectionParent.find("#divViewsArea").attr('data-view', self.data("name"));
        updateSchedule();
    }

    function showFilter(e) {
        var divFilter = sectionParent.find("#divFilter"),
            action = e.data.action;

        divFilter.find('#txtFilterCollaborator').val('')
        divFilter.find('#txtFilterWorkLoad').val('');
        divFilter.find('#btnFilterSubmit').off('click');

        if (action == 'close') {
            setTimeout(function () {
                divFilter.hide();
            }, 300);
            applyFilter();
            return;
        }

        if (isCurrentWeekTab()) {
            divFilter.find('[data-type="workload"]').hide();
        } else {
            divFilter.find('[data-type="workload"]').show();
        }

        if (divFilter.is(":visible")) {
            openCloseFilter(-700, 0);
            setTimeout(function () {
                divFilter.hide();
            }, 300);
        } else {
            divFilter.find('#btnFilterSubmit').on('click', applyFilter);
            openCloseFilter(0, 1);
            divFilter.show();
            divFilter.find('#txtFilterCollaborator').focus();
        }
    }

    function openCloseFilter(left, opacity) {
        sectionParent.find("#divFilter").stop(true).animate({ 'left': left, opacity: opacity }, { queue: false, duration: 300 });
    }

    function hideMenus(keepOpen, container) {
        var otherMenus = $.grep(_actionMenus, function (el) {
            return el != keepOpen;
        });
        $.each(otherMenus, function (index, elem) {
            container.find(elem).fadeOut();
        });
    }
    //#endregion

    //#region Print
    function showReport(e) {
        var menuOption = sectionParent.find('#divReportOptions'),
            reportID = $(e.target).data('id'),
            reportModal = $("#report-modal"),
            reportSettings = {
                units: sectionParent.find("#ddlUnit").val(),
                sections: sectionParent.find("#ddlSection").val(),
                collaborators: getSelectedCollaborators(),
                reportID: reportID,
                startDate: sectionParent.find("#startDate").val(),
                endDate: sectionParent.find("#endDate").val()
            };

        reportsModalModule.settings(reportSettings);

        if (reportModal.is(":visible")) {
            reportModal.fadeOut();
        } else {
            reportModal.fadeIn('100', function () {
                if (appliedSelectReportModel == false) {
                    customControlsModule.applySelectControl($('#report-modal').find('select:visible').not('.hasCustomSelect'), false);
                    appliedSelectReportModel = true;
                }
            });
        }
        menuOption.fadeOut();
    }

    function showReportOptions(event, data) {
        event.stopPropagation();

        var showModal = false,
            container = $('#tabData');

        if (data) {
            showModal = data.showModal;
            container = data.divID;
            event = data.clickEv;
        }

        var menuOption = container.find('#divReportOptions');

        container.find('#divReportOptions a').off('click').on('click', showReport);

        if (menuOption.is(':visible')) {
            menuOption.fadeOut();
        } else {
            if (container.find('#divReportOptions a').length > 0) {
                var lineHeight = parseInt($(container.find('#divReportOptions a')[0]).css('line-height'));
                var length = container.find('#divReportOptions a').length;
                var menuHeight = lineHeight * length;
                menuOption.css({ 'height': menuHeight + 'px' });
                menuOption.css({ "top": event.target.offsetTop - menuOption.height() - 8, "left": event.target.offsetLeft });
                menuOption.fadeIn();
                container.off('click').on('click', function (e) {
                    if (!$(e.target).is('#btnPrint')) {
                        menuOption.fadeOut();
                    }
                });
                hideMenus('#divReportOptions', container);
            }
        }
    }

    function initReportModal() {
        appliedSelectReportModel = false;

        $.ajax({
            url: urlConfig.reports.reportModal,
            data: JSON.stringify({
                reportType: 'S'
            }),
            success: function (response) {
                if (response != null) {
                    $('#divReportModal').empty().html(response);
                }
            }
        });
    }

    //#endregion

    //#region Approve
    function showApproveOptions(event, data) {
        event.stopPropagation();
        var showModal = false,
            container = $('#tabData');

        if (data) {
            showModal = data.showModal;
            container = data.divID;
            event = data.clickEv;
        }

        var myParent = $(event.target).parent(),
            menuOption = container.find("#divApproveOptions");

        container.find("#divApproveOptions a")
            .off('click')
            .on('click', function (e) {
                $(e.target).parent().fadeOut();
                if (showModal) {
                    showChangePeriodModal(container, false, '#divApproveOptions', function () {
                        approveScheduleCollaborator(e);
                    })
                } else {
                    approveScheduleCollaborator(e);
                }
            });

        if (menuOption.is(":visible")) {
            menuOption.fadeOut();
        } else {
            var lineHeight = parseInt($(container.find('#divApproveOptions a')[0]).css('line-height'));
            var length = container.find('#divApproveOptions a').length;
            var menuHeight = lineHeight * length;
            menuOption.css({ 'height': menuHeight + 'px' });
            menuOption.css({ "top": event.target.offsetTop - menuOption.height() - 8, "left": event.target.offsetLeft });
            menuOption.fadeIn();
            container.off('click').on('click', function (e) {
                if (!$(e.target).is('#btnApprove')) {
                    menuOption.fadeOut();
                }
            });
            hideMenus('#divApproveOptions', container);
        }
    }

    function approveScheduleCollaborator(e) {
        var selectedType = $(e.target).data('type');
        var ids = getSelectedCollaborators(selectedType === 'all');

        $(e.target).parent().fadeOut();

        if (ids == '') {
            dialogModule.showOK(
                _globalResources.getResource().schedule.ApprovedTitle,
                _globalResources.getResource().schedule.ApprovedNothingSelected);
            return;
        }

        var parameters = JSON.stringify({
            unitID: $("#ddlUnit").val(),
            sectionID: $("#ddlSection").val(),
            workstatitonTypeID: $("#ddlWorkstationType").val(),
            startDate: $("#startDate").val(),
            endDate: $("#endDate").val(),
            collaboratorIDs: ids
        });

        $.ajax({
            url: urlConfig.schedule.approveCollaborators,
            data: parameters,
            success: function (response) {
                var result = JSON.parse(response);
                if (result) {
                    if (result.hasSuccess) {
                        dialogModule.showDialog(result.successResult);
                        updateSchedule();
                    } else {
                        dialogModule.showDialog(result.errorResult);
                    }
                } else {
                    // Retorna a mensagem de erro
                    dialogModule.createDialog(0, _globalResources.getResource().ErrorTitle, _globalResources.getResource().CommunicationError);
                }
            }
        });
    }
    // #endregion

    // #region Process
    function reprocessOptionsClickCallback(type, callback) {
        var showModal = false;
        if (isCurrentMonthDataTab()) {
            showModal = true;
        }

        if (showModal) {
            showChangePeriodModal(null, true, '#divReprocessOptions', callback);
        } else {
            callback();
        }
    }

    function showReprocessOptions(event, data) {
        event.stopPropagation();

        var showModal = false,
            container = $('#tabData');

        if (data) {
            showModal = data.showModal;
            container = data.divID;
            event = data.clickEv;
        }

        var myParent = $(event.target).parent(),
            menuOption = container.find("#divReprocessOptions");

        container.find("#divReprocessOptions a")
            .off('click')
            .on('click', function (e) {
                $(e.target).parent().fadeOut();
                var type = $(e.target).data('type');
                if (showModal) {
                    showChangePeriodModal(container, false, '#divReprocessOptions', function () {
                        scheduleProcessModule.confirmExecution(type, reprocessScheduleCollaboratorCallback);
                    });
                } else {
                    scheduleProcessModule.confirmExecution(type, reprocessScheduleCollaboratorCallback);
                }
            });

        if (menuOption.is(":visible")) {
            menuOption.fadeOut();
        } else {
            var lineHeight = parseInt($(container.find('#divReprocessOptions a')[0]).css('line-height'));
            var length = container.find('#divReprocessOptions a').length;
            var menuHeight = lineHeight * length;
            menuOption.css({ 'height': menuHeight + 'px' });
            menuOption.css({ "top": event.target.offsetTop - menuOption.height() - 10, "left": event.target.offsetLeft });
            menuOption.fadeIn();
            container.off('click').on('click', function (e) {
                // console.log(e);
                if (!$(e.target).is('#btnReprocess')) {
                    menuOption.fadeOut();
                }
            });
            hideMenus('#divReprocessOptions', container);
        }
    }

    function processSchedule(event, data) {
        scheduleProcessModule.confirmExecution(data.type, reprocessScheduleCollaboratorCallback);
    }

    function showChangePeriodModal(container, changeLeft, optionsDivID, callback) {
        changeLeft = typeof changeLeft !== 'undefined' ? changeLeft : false;

        var menuOption = null;
        if (container) {
            menuOption = container.find(optionsDivID);
        }

        var changePeriodModal = $('#change-period-modal'),
            processSettings = {
                units: sectionParent.find('#ddlUnit').val(),
                sections: sectionParent.find("#ddlSection").val(),
                collaborators: getSelectedCollaborators(),
                startDate: sectionParent.find("#startDate").val(),
                endDate: sectionParent.find("#endDate").val(),
                callback: callback,
            };

        scheduleChangePeriodModalModule.init();
        scheduleChangePeriodModalModule.settings(processSettings);

        if (changePeriodModal.is(':visible')) {
            changePeriodModal.fadeOut();
        } else {
            changePeriodModal.fadeIn();
            if (changeLeft) {
                var value = parseInt($('#contentBody').css('left'));
                if (value < 0) {
                    changePeriodModal.css('left', Math.abs(value) / 2);
                } 
            } else {
                changePeriodModal.css('left', 0);
            }
            if (container) {
                hideMenus(optionsDivID, container);
            }
        }
        if (menuOption) {
            menuOption.fadeOut();
        }
    }

    function reprocessScheduleCollaboratorCallback(processType, answer, answerCode) {
        answer = (typeof answer == 'undefined') ? false : answer;
        answerCode = typeof answerCode !== 'undefined' ? answerCode : "";

        var ids = getSelectedCollaborators();
        if (ids == '') {
            dialogModule.showOK(
                _globalResources.getResource().schedule.PrcessTitle,
                _globalResources.getResource().schedule.PrcessNothingSelected);
            return;
        }

        $.ajax({
            url: urlConfig.schedule.reprocessScheduleCollaborators,
            data: JSON.stringify({
                unitID: $("#ddlUnit").val(),
                sectionID: $("#ddlSection").val(),
                startDate: $("#startDate").val(),
                endDate: $("#endDate").val(),
                type: processType,
                collaboratorsID: ids,
                answer: answer,
                answerCode: answerCode,
            }),
            success: function (response) {
                var result = JSON.parse(response);
                if (result) {
                    if (result.hasSuccess) {
                        dialogModule.showDialog(result.successResult);
                    } else if (result.hasQuestion) {
                        if (result.genericMessage != null) {
                            answerCode = result.genericMessage;
                        }
                        if (result.genericMessage && result.genericMessage == 'INVALID_LCM_PERIOD') {
                            dialogModule.showYesOrNoDialog(result.questionResult, reprocessScheduleCollaboratorInvalidLCMCallback, [processType, answerCode]);
                        } else {
                            dialogModule.showYesOrNoDialog(result.questionResult, collaboratorScheduleProcessCallback, [processType, answerCode]);
                        }
                       
                    } else {
                        dialogModule.showDialog(result.errorResult);
                    }
                } else {
                    // Retorna a mensagem de erro
                    dialogModule.createDialog(0, _globalResources.getResource().ErrorTitle, _globalResources.getResource().CommunicationError);
                }
            }
        });
    }

    function reprocessScheduleCollaboratorInvalidLCMCallback(yesOrNo, args) {
        if (yesOrNo == true) {
            var nWeeks = scheduleModule.getLCMWeeks('lcmValSchedule');
            adjustEndDate(nWeeks);
             var processType = args[0],
                answerCode = args[1];
            reprocessScheduleCollaboratorCallback(processType, false, answerCode);
        }
    }

    function collaboratorScheduleProcessCallback(yesOrNo, args) {
        if (yesOrNo == true) {
            var processType = args[0],
                answerCode = args[1];
            reprocessScheduleCollaboratorCallback(processType, true, answerCode);
        }
    }

    function getSelectedCollaborators(all) {
        var listCollaborators = [];

        if (_selectedCollabs.length !== 0) {
            listCollaborators = _selectedCollabs;
        } else {
            listCollaborators = listCollaborators.concat(scheduleChartCollaboratorModule.getSelectedCollaborators(all));
            listCollaborators = listCollaborators.concat(scheduleChartCollaboratorTableViewModule.getSelectedCollaborators(all));
            listCollaborators = listCollaborators.concat(scheduleAbsenceModule.getSelectedCollaborators(all));
        }

        return listCollaborators;
    }

    function updateSelected(event, data) {
        _selectedCollabs = data.selectedCollabs;
    }
    //#endregion Process

    //#region Register Events

    function registerEvents() {
        // Atribui o evento de change no dropdown
        sectionParent.find("#ddlUnit").off('change').on('change', unitDropDownChange);
        sectionParent.find("#ddlUnit").setSelectedValue(userUnitID);

        // Atribui o evento de change no dropdown
        sectionParent.find("#ddlSection").off('change').on('change', sectionDropDownChange);

        // Atribui o evento de change no dropdown
        //sectionParent.find("#ddlWorkstationType").off('change').on('change', workstationTypeDropDownChange);

        // Comportamento do click das tabs
        sectionParent.find("#ulTabs").find('a').off('click').on('click', headerTabClick);

        // Configuração dos botões de zoom
        sectionParent.find('#btnZoomUp').off('click').on('click', buttonZoomUpClick);
        sectionParent.find('#btnZoomDown').off('click').on('click', buttonZoomDownClick);

        sectionParent.find('#btnFilter, #btnWeekFilter').off('click').on('click', { action: 'open' }, showFilter);
        sectionParent.find('#btnFilter, #btnWeekFilter').off('dblclick').on('dblclick', { action: 'close' }, showFilter);

        if (operations.CanApprove) {
            sectionParent.find("#btnApprove").off('click').on('click', showApproveOptions);
        }
        if (operations.CanProcess) {
            sectionParent.find("#btnReprocess").off('click').on('click', showReprocessOptions);
        }

        sectionParent.find("#btnPrint").off('click').on('click', showReportOptions);

        // Eventos para mostrar e esconder as visões
        sectionParent.find("#divButtonsArea .right-area a").off('click').on('click', showViewArea);

        registerExternalEvents();
    }

    function registerExternalEvents() {
        $('#divSchedule')
            .off('scheduleModule.showApproveOptions')
            .on('scheduleModule.showApproveOptions', showApproveOptions);

        $('#divSchedule')
            .off('scheduleModule.showReprocessOptions')
            .on('scheduleModule.showReprocessOptions', showReprocessOptions);

        $('#divSchedule')
            .off('scheduleModule.showReportOptions')
            .on('scheduleModule.showReportOptions', showReportOptions);

        $('#divSchedule')
            .off('scheduleModule.processSchedule')
            .on('scheduleModule.processSchedule', processSchedule);

        $('body')
            .off('monthly_timeline.change_selected_collabs')
            .on('monthly_timeline.change_selected_collabs', updateSelected);
    }
    //#endregion

    //#region Header Events
    function unitDropDownChange() {
        sectionModule.getSections($("#ddlUnit").val())
            .done(function (listSections) {
                //Popula DropDown
                $("#ddlSection").clearSelect();
                $("#ddlSection").fillSelect(listSections, 'ID', 'Name', true);
                // Limpa o dropdown de tipos de postos
                $("#ddlWorkstationType").clearSelect();
                // chama a extension para incluir o "Selecione"
                $("#ddlWorkstationType").fillSelect(null, null, null, true);
                $("#ddlWorkstationType").find('option').first().remove();
                $("#ddlWorkstationType").multiselect('refresh');
            });
    }

    function sectionDropDownChange() {
        if (!$("#ddlSection").val()) {
            $("#ddlWorkstationType").clearSelect();
            $("#ddlWorkstationType").fillSelect([], 'ID', 'Name', true);
            $("#ddlWorkstationType").find('option').first().remove();
            $("#ddlWorkstationType").multiselect('refresh');
            return;
        }

        //Clear #ddlWorkstationType data
        $("#ddlWorkstationType").clearSelect();
        $("#ddlWorkstationType").fillSelect([], 'ID', 'Name', true);
        $("#ddlWorkstationType").find('option').first().remove();
        $("#ddlWorkstationType").multiselect('refresh');

        //Carrega dados na lista de Workstation types
        workstationTypeModule.getWorkstationTypes($("#ddlSection").val())
            .done(function (workstationTypes) {
                //Carrea dados nos tipos
                $("#ddlWorkstationType").clearSelect();
                $("#ddlWorkstationType").fillSelect(workstationTypes, 'ID', 'Name', true);
                $("#ddlWorkstationType").find('option').first().remove();
                $("#ddlWorkstationType").multiselect('refresh');

                //Chama métodos para reload na tela com o parâmetro novo
                updateSchedule();
            });
    }

    function workstationTypeDropDownChange() {
        //Chama métodos para reload na tela com o parâmetro novo
        updateSchedule();
    }
    //#endregion

    //#region Tab Events
    function showDropdowns(showUnit, showSection, showWorkstation, showCollaborator, showSectionMulti, showWorkstationMulti) {
        $('#ddlUnit').parent().toggle(showUnit);
        $('#ddlSection').parent().toggle(showSection);
        $('#ddlWorkstationType').parent().toggle(showWorkstation);
        $('#ddlCollaborator').parent().toggle(showCollaborator);
        $('#ddlSectionMulti').parent().toggle(showSectionMulti);
    }

    function enableDropdowns(enableUnit, enableSection, enableWorkstation, enableCollaborator, enableSectionMulti, enableWorkstationTypeMulti) {
        var configs = [
            { selector: '#ddlUnit', isEnabled: enableUnit },
            { selector: '#ddlSection', isEnabled: enableSection },
            //{ selector: '#ddlWorkstationType', isEnabled: enableWorkstation },
            { selector: '#ddlCollaborator', isEnabled: enableCollaborator },
            { selector: '#ddlSectionMulti', isEnabled: enableSectionMulti },
        ];

        for (key in configs) {
            var config = configs[key];
            if (config.isEnabled) {
                $(config.selector).prop("disabled", !config.isEnabled);
                $(config.selector).next('.customSelect').removeClass('customSelectDisabled');
            } else {
                $(config.selector).prop("disabled", config.isEnabled);
                $(config.selector).next('.customSelect').addClass('customSelectDisabled');
            }
        }

        if(enableWorkstation)
        {
            $("#ddlWorkstationType").multiselect('enable');
        } else {
            var workStationSel = $("#ddlWorkstationType option");
            for (i = 0; i < workStationSel.length; i++) {
                if (workStationSel[i].selected) {
                    workStationSel[i].selected = false;
                    //$("#ddlWorkstationType option:selected").removeAttr("selected");
                    $("#ddlWorkstationType").multiselect('refresh');
                    break;
                }
            }
            $("#ddlWorkstationType").multiselect('disable');
        }
    }

    function headerTabClick(e) {
        var id = e.target.id,
            parent = $(e.target).parents("ul"),
            divWeekDaysCarousel = sectionParent.find("#weekDaysCarouselContainer"),
            divSchedulePeriodHeader = sectionParent.find('#schedulePeriodHeader'),
            divTitle = sectionParent.find("#divTitle"),
            divSubtitle = sectionParent.find("#divSubtitle"),
            divCollaboratorSelect = sectionParent.find('#scheduleHeader #collaboratorSelect');

        if (id === parent.find("." + SELECTED_TAB_CSS).attr("id")) {
            return;
        }

        sectionParent.find("#schedulePageLoader").show();
        divWeekDaysCarousel.show();
        divTitle.hide();
        divSubtitle.empty().hide();
        divSchedulePeriodHeader.show();
        showDropdowns(true, true, true, false, false, false);
        enableDropdowns(true, true, true, false, false, false);

        switch (id) {
            case HEADER_PROCESS_TAB:
                headerProcessTabClick(parent, id);
                divWeekDaysCarousel.hide();
                divTitle.html(_globalResources.getResource().schedule.header.Process);
                divTitle.show();
                divCollaboratorSelect.hide();
                showDropdowns(true, true, true, false, false, false);
                enableDropdowns(true, true, false, false, false, false);
                break;
            default:
            case HEADER_DATA_TAB:
                headerDataTabClick(parent, id);
                divCollaboratorSelect.hide();
                showDropdowns(true, true, true, false, false, false);
                enableDropdowns(true, true, true, false, false, false);
                break;
            case HEADER_MONTH_DATA_TAB:
                headerMonthDataTabClick(parent, id);
                divWeekDaysCarousel.hide();
                divSchedulePeriodHeader.hide();
                showDropdowns(true, true, true, false, false, false);
                enableDropdowns(true, true, false, false, false, false);
                break;
            case HEADER_WEEK_TAB:
                headerWeekTabClick(parent, id);
                divWeekDaysCarousel.hide();
                divTitle.html(_globalResources.getResource().schedule.header.WeeklyDetailTitle);
                sectionParent.find("#divSubtitle").html(_globalResources.getResource().schedule.header.WeeklyDetailSubtitle);
                divTitle.show();
                divSubtitle.show();
                divCollaboratorSelect.hide();
                showDropdowns(true, true, true, false, false, false);
                enableDropdowns(true, true, true, false, false, false);
                break;
            case HEADER_REST_TAB:
                headerRestTabClick(parent, id);
                divWeekDaysCarousel.hide();
                divSchedulePeriodHeader.hide();
                divCollaboratorSelect.show();
                showDropdowns(true, true, true, false, false, false);
                enableDropdowns(true, true, false, false, false, false);
                break;
        }

        updateSchedule();
        //Reset Global Variables and Clear Selected Collabs
        scheduleBaseTimelineModule.clearAllCheck();
    }

    function headerDataTabClick(parent) {
        // Remove o display none na tab de data
        sectionParent.find("#" + DATA_TAB).removeClass(NO_DISPLAY_CSS);
        parent.find("#" + HEADER_DATA_TAB).addClass(SELECTED_TAB_CSS);

        // Display none na tab de month data
        sectionParent.find("#" + MONTH_DATA_TAB).addClass(NO_DISPLAY_CSS);
        parent.find("#" + HEADER_MONTH_DATA_TAB).removeClass(SELECTED_TAB_CSS);

        // Display none na tab de process
        sectionParent.find("#" + PROCESS_TAB).addClass(NO_DISPLAY_CSS);
        parent.find("#" + HEADER_PROCESS_TAB).removeClass(SELECTED_TAB_CSS);

        // Display none na tab de week
        sectionParent.find("#" + WEEK_TAB).addClass(NO_DISPLAY_CSS);
        parent.find("#" + HEADER_WEEK_TAB).removeClass(SELECTED_TAB_CSS);

        // Display none na tab de rest
        sectionParent.find("#" + REST_TAB).addClass(NO_DISPLAY_CSS);
        parent.find("#" + HEADER_REST_TAB).removeClass(SELECTED_TAB_CSS);
    }

    function headerMonthDataTabClick(parent) {
        // Display none na tab de month data
        sectionParent.find("#" + DATA_TAB).addClass(NO_DISPLAY_CSS);
        parent.find("#" + HEADER_DATA_TAB).removeClass(SELECTED_TAB_CSS);

        // Remove o display none na tab de data
        sectionParent.find("#" + MONTH_DATA_TAB).removeClass(NO_DISPLAY_CSS);
        parent.find("#" + HEADER_MONTH_DATA_TAB).addClass(SELECTED_TAB_CSS);

        // Display none na tab de process
        sectionParent.find("#" + PROCESS_TAB).addClass(NO_DISPLAY_CSS);
        parent.find("#" + HEADER_PROCESS_TAB).removeClass(SELECTED_TAB_CSS);

        // Display none na tab de week
        sectionParent.find("#" + WEEK_TAB).addClass(NO_DISPLAY_CSS);
        parent.find("#" + HEADER_WEEK_TAB).removeClass(SELECTED_TAB_CSS);

        // Display none na tab de rest
        sectionParent.find("#" + REST_TAB).addClass(NO_DISPLAY_CSS);
        parent.find("#" + HEADER_REST_TAB).removeClass(SELECTED_TAB_CSS);
    }

    function headerProcessTabClick(parent) {
        // Display none na tab de data
        sectionParent.find("#" + DATA_TAB).addClass(NO_DISPLAY_CSS);
        parent.find("#" + HEADER_DATA_TAB).removeClass(SELECTED_TAB_CSS);

        // Display none na tab de month data
        parent.find("#" + HEADER_MONTH_DATA_TAB).removeClass(SELECTED_TAB_CSS);
        sectionParent.find("#" + MONTH_DATA_TAB).addClass(NO_DISPLAY_CSS);

        // Remove o display none na tab de process
        sectionParent.find("#" + PROCESS_TAB).removeClass(NO_DISPLAY_CSS);
        parent.find("#" + HEADER_PROCESS_TAB).addClass(SELECTED_TAB_CSS);

        // Display none na tab de week
        parent.find("#" + HEADER_WEEK_TAB).removeClass(SELECTED_TAB_CSS);
        sectionParent.find("#" + WEEK_TAB).addClass(NO_DISPLAY_CSS);

        // Display none na tab de rest
        parent.find("#" + HEADER_REST_TAB).removeClass(SELECTED_TAB_CSS);
        sectionParent.find("#" + REST_TAB).addClass(NO_DISPLAY_CSS);
    }

    function headerWeekTabClick(parent) {
        // Display none na tab de data
        parent.find("#" + HEADER_DATA_TAB).removeClass(SELECTED_TAB_CSS);
        sectionParent.find("#" + DATA_TAB).addClass(NO_DISPLAY_CSS);

        // Display none na tab de month data
        parent.find("#" + HEADER_MONTH_DATA_TAB).removeClass(SELECTED_TAB_CSS);
        sectionParent.find("#" + MONTH_DATA_TAB).addClass(NO_DISPLAY_CSS);

        // Display none na tab de process
        parent.find("#" + HEADER_PROCESS_TAB).removeClass(SELECTED_TAB_CSS);
        sectionParent.find("#" + PROCESS_TAB).addClass(NO_DISPLAY_CSS);

        // Remove o display none na tab de week
        parent.find("#" + HEADER_WEEK_TAB).addClass(SELECTED_TAB_CSS);
        sectionParent.find("#" + WEEK_TAB).removeClass(NO_DISPLAY_CSS);

        // Display none na tab de rest
        parent.find("#" + HEADER_REST_TAB).removeClass(SELECTED_TAB_CSS);
        sectionParent.find("#" + REST_TAB).addClass(NO_DISPLAY_CSS);
    }

    function headerRestTabClick(parent) {
        // Display none na tab de data
        parent.find("#" + HEADER_DATA_TAB).removeClass(SELECTED_TAB_CSS);
        sectionParent.find("#" + DATA_TAB).addClass(NO_DISPLAY_CSS);

        // Display none na tab de month data
        parent.find("#" + HEADER_MONTH_DATA_TAB).removeClass(SELECTED_TAB_CSS);
        sectionParent.find("#" + MONTH_DATA_TAB).addClass(NO_DISPLAY_CSS);

        // Display none na tab de process
        parent.find("#" + HEADER_PROCESS_TAB).removeClass(SELECTED_TAB_CSS);
        sectionParent.find("#" + PROCESS_TAB).addClass(NO_DISPLAY_CSS);

        // Display none na tab de week
        parent.find("#" + HEADER_WEEK_TAB).removeClass(SELECTED_TAB_CSS);
        sectionParent.find("#" + WEEK_TAB).addClass(NO_DISPLAY_CSS);

        // Remove o display none na tab de rest
        parent.find("#" + HEADER_REST_TAB).addClass(SELECTED_TAB_CSS);
        sectionParent.find("#" + REST_TAB).removeClass(NO_DISPLAY_CSS);
    }
    //#endregion

    //#region Zoom Buttons Functions
    function buttonZoomUpClick(e) {
        var self = $(this);

        sectionParent.find("#bottonViewPageLoader").fadeIn();

        setTimeout(function () {

            var height = 0;

            if (self.hasClass("larged")) { // Reduzindo
                height = initHeightBottomArea;

                self.removeClass("larged");
                sectionParent.find("#divTopArea").removeClass("closed-area");
                sectionParent.find("#divBottomArea").css('height', initHeightBottomArea);
                sectionParent.find("#btnZoomDown").fadeIn(200);
            } else { // Aumentando
                height = initHeightBottomArea + initHeightTopArea;

                self.addClass("larged");
                sectionParent.find("#divTopArea").addClass("closed-area");
                sectionParent.find("#divBottomArea").css('height', height);
                sectionParent.find("#btnZoomDown").fadeOut(200);
            }
            sectionParent.find("#divViewsArea").css('height', height);
            scheduleEditCollaboratorTime.adjustHeight(height);

            sectionParent.find("#bottonViewPageLoader").animate({ height: height });

            if (sectionParent.find('#divViewsArea').attr('data-view') === scheduleChartCollaboratorModule.myName()) {
                sectionParent.find("#divViewsArea").animate({ height: height }, { complete: function () { scheduleChartCollaboratorModule.updateScroll(height, initHeightBottomArea); } });
            } else {
                scheduleViewModule.setVisibleArea();
            }

        }, 410);

        setTimeout(function () {
            sectionParent.find("#bottonViewPageLoader").fadeOut();
        }, 820);
    }

    function buttonZoomDownClick(e) {
        var self = $(this),
            actualHeightTopArea = sectionParent.find("#divTopArea").height();

        sectionParent.find("#topViewPageLoader").fadeIn();

        setTimeout(function () {

            var height = 0;

            if (self.hasClass("larged")) { // Reduzindo
                height = initHeightTopArea;
                sectionParent.find("#topViewPageLoader").animate({ height: height });

                self.removeClass("larged");
                sectionParent.find("#divChartArea").animate({ height: height });
                sectionParent.find("#divBottomArea").removeClass("closed-area");
                sectionParent.find("#divTopArea").css('height', height);
                sectionParent.find("#divChartArea").highcharts().setSize(sectionParent.find("#divTopArea").width(), height);
                sectionParent.find("#btnZoomUp").fadeIn(200);
            } else { // Aumentando
                height = initHeightBottomArea + initHeightTopArea;
                sectionParent.find("#topViewPageLoader").animate({ height: height });

                self.addClass("larged");
                sectionParent.find("#divBottomArea").addClass("closed-area");
                sectionParent.find("#divTopArea").css('height', height);
                sectionParent.find("#divChartArea").css('height', height);
                sectionParent.find("#divChartArea").highcharts().setSize(sectionParent.find("#divTopArea").width(), height);
                sectionParent.find("#btnZoomUp").fadeOut(200);
            }

            sectionParent.find("#divViewsArea").css('height', height);
            scheduleEditCollaboratorTime.adjustHeight(height);

            if (sectionParent.find('#divViewsArea').attr('data-view') === scheduleChartCollaboratorModule.myName()) {
                scheduleChartCollaboratorModule.updateScroll(height, initHeightBottomArea);
            }

        }, 410);

        setTimeout(function () {
            sectionParent.find("#topViewPageLoader").fadeOut();
        }, 820);
    }
    //#endregion

    //#region Datepicker Functions
    function changeDatePicker(e) {
        var selectedStartDate = $("#startDate").val();
        var selectedEndDate = $("#endDate").val();

        // não carrega as informações se a data estiver em branco
        if (selectedEndDate != "") {
            weekDaysCarousel.loadWeekDays(selectedStartDate, selectedEndDate);

            // utiliza o start date pq quando recarregar o slider, a data de start é que estara selecionada
            updateSchedule(selectedStartDate);
        }
    }
    //#endregion

    //#region Button Process
    function clickButtonProcess(e) {
        $("#divButtonProcess").toggle();
    }

    function clickOptionProcess(e) {
        var startDate = sectionParent.find("#startDate").val(),
            endDate = sectionParent.find("#endDate").val();

        $("#divButtonProcess").hide();

        scheduleProcessModule.addTotal();
    }
    //#endregion

    function setSizeNoFooter(divID) {
        var contentContainer = $('.schedule-container .content');
        var footer = $('.page-footer');
        var width = contentContainer.width();
        var height = footer.offset().top - contentContainer.offset().top;
        $(divID).width(width + 'px').height(height + 'px');
    }

    function setSizeContainer(divID, extra) {
        var contentContainer = $('.schedule-container .content');
        var footer = $('.page-footer');
        var width = contentContainer.width();
        var buttonsArea = $('.buttons-area');
        var newHeight = contentContainer.height() - footer.height() - buttonsArea.height() - extra;
        $(divID).width(width).height(newHeight);
    }

    function setSize() {
        var container = sectionParent.find('.content'),
            tabHeight = sectionParent.find("#tabs").height(),
            footPage = $('.page-footer').height(),
            periodHeader,
            totalHeight;

        container.height(container.height() - footPage);
        tabHeight = tabHeight - footPage;

        if (isCurrentDataTab()) {
            periodHeader = sectionParent.find('#schedulePeriodHeader');
            totalHeight = $('.page-footer').offset().top - (periodHeader.offset().top + parseInt(periodHeader.css('height'), 10));
            var height = (totalHeight - (parseInt(sectionParent.find('.zoom').css('height'), 10) + parseInt(sectionParent.find('#divButtonsArea').css('height'), 10))) / 2; //(altura total - (altura da barra de zoom + altura da area de botoes)) /2

            sectionParent.find('#divTopArea').height(height);
            sectionParent.find('#divBottomArea').height(height);

            initHeightTopArea = initHeightBottomArea = height;

        } else if (isCurrentWeekTab()) {
            var weekDetailContanier = sectionParent.find('#week-detail'),
                weekHeight = weekDetailContanier.siblings('.buttons-area').offset().top - weekDetailContanier.offset().top;

            sectionParent.find('#week-detail').height(weekHeight);
            sectionParent.find('#daily-detail').height(weekHeight);
        }
    }

    //#region Init
    function init(operationSchedule) {
        // Atribui a variavel da seção de estimativas
        setSectionParent();
        initReportModal();

        operations = JSON.parse(operationSchedule);

        setSize();

        // Abre os page loaders de ambas as áreas (superior e inferior)
        sectionParent.find("#schedulePageLoader").show();
        sectionParent.find("#topViewPageLoader").fadeIn(300);
        sectionParent.find("#bottonViewPageLoader").fadeIn(300);

        // Inicializa o carrocel
        weekDaysCarousel = weekDaysCarouselModule(weekDayCallback);

        registerEvents();
        maskModule.applyMask('divSchedule');
        customControlsModule.applySelectControl();
        $('#ddlCollaborator').parent().hide();
        $('#ddlSectionMulti').parent().hide();
        $('#ddlWorkstationType_OLD').parent().hide();
        customControlsModule.applyDatePickerControl(['startDate', 'endDate'], true, false, changeDatePicker, changeDatePicker, true);
        customControlsModule.registerKeyUpEnter($('#divFilter'), applyFilter);

        initHeightPeriodHeader = $('#scheduleHeader').height();

        scheduleProcessModule.init();

    }
    //#endregion

    return {
        init: init,
        getSectionParent: getSectionParent,
        getSelectedView: getSelectedView,
        getBottonViewPageLoader: getBottonViewPageLoader,
        getTopViewPageLoader: getTopViewPageLoader,
        setSelectedSettings: setSelectedSettings,
        getSaveArea: getSaveArea,
        isCurrentDataTab: isCurrentDataTab,
        isCurrentMonthDataTab: isCurrentMonthDataTab,
        isCurrentProcessTab: isCurrentProcessTab,
        isCurrentWeekTab: isCurrentWeekTab,
        isCurrentRestTab: isCurrentRestTab,
        getSelectedWeekDay: getSelectedWeekDay,
        getMainPageLoader: getMainPageLoader,
        getWeekDaysCarousel: getWeekDaysCarousel,
        clickProcessTab: clickProcessTab,
        setSize: setSize,
        updateSchedule: updateSchedule,
        applySortingAndOrder: applyFilter,
        adjustEndDate: adjustEndDate,
        getLCMWeeks: getLCMWeeks,
        showDropdowns: showDropdowns,
        enableDropdowns: enableDropdowns,
        setSizeNoFooter: setSizeNoFooter,
        showPageLoader: showPageLoader,
        hidePageLoader: hidePageLoader,
        setSizeContainer: setSizeContainer,
        reprocessOptionsClickCallback: reprocessOptionsClickCallback,
    }

}();
