CREATE OR REPLACE PACKAGE BODY PCK_PREDICTED_REST_DAYS AS

  --Global Vars
  G_DEFAULT_DATE_FORMAT   VARCHAR2(10);
  G_SWITH_DAY_MONTH       DATE;
  G_ADD_NR_MONTHS         NUMBER;
  G_NOTIF_DEST_CODE       NUMBER;

------------------------------------------------------------------------------
--Get Parameter for switch year
------------------------------------------------------------------------------
FUNCTION GET_SWITCH_YEAR(O_ERROR_MESSAGE  IN OUT D_ARRAY_MENSAGEM_ERRO_TP,
                         O_SWITCH_YEAR       OUT DATE,
                         I_SCOPE          IN     VARCHAR2 DEFAULT NULL,
                         I_SCOPE_ID       IN     VARCHAR2 DEFAULT NULL) RETURN BOOLEAN IS

   l_erro      VARCHAR2(4000);
   l_name      VARCHAR2(100) := G_PACKAGE_NAME||'.GET_SWITCH_YEAR';
   l_parameter VARCHAR2(100) := 'PREDICTED_REST_DAYS_SWITCH_YEAR_DATE';

BEGIN

   O_SWITCH_YEAR := PCK_CORE_PARAMETER.GETDATEATTR(l_parameter,I_SCOPE,I_SCOPE_ID);
   --
   IF O_SWITCH_YEAR IS NULL THEN

      O_ERROR_MESSAGE := n_Mensagem.Get(i_lista_erros => O_ERROR_MESSAGE,
                                        i_cod_erro    => 'PARAMETER_NOT_EXISTS',
                                        i_idioma      => PCK_CORE_USER.GET_USER_LANGUAGE(USER),
                                        i_Parametro1  => l_parameter);

      IF G_NOTIF_DEST_CODE IS NOT NULL THEN
         IF NOT n_aviso.create_error_notification (O_ERROR_MESSAGE => O_ERROR_MESSAGE,
                                                   I_processo      => GV_PROCESS_NAME,
                                                   I_level         => GV_LEVEL,
                                                   I_alias         => 'PARAMETRO_NAO_DEFINIDO',
                                                   I_subtipo       => 'PARAMETROS',
                                                   I_para          => G_NOTIF_DEST_CODE,
                                                   I_param1        => l_parameter) THEN
            RETURN FALSE;
         END IF;
      END IF;
      --
      RETURN FALSE;
   END IF;
   --
   RETURN TRUE;
 EXCEPTION
   WHEN OTHERS THEN

      l_erro := Pck_Escala_Debug.Fnc_Monta_Mensagem('PACKAGE_ERROR',SQLERRM,l_name,To_Char(SQLCODE));
      O_ERROR_MESSAGE := n_Mensagem.Get(O_ERROR_MESSAGE, l_erro, PCK_CORE_USER.GET_USER_LANGUAGE(USER));
      --
      RETURN FALSE;
 END GET_SWITCH_YEAR;
------------------------------------------------------------------------------
--Get Parameter for nr Months after switch year
------------------------------------------------------------------------------
FUNCTION GET_REST_DAYS_NR_MONTHS(O_ERROR_MESSAGE  IN OUT D_ARRAY_MENSAGEM_ERRO_TP,
                                 O_NR_MONTHS         OUT NUMBER,
                                 I_SCOPE          IN     VARCHAR2 DEFAULT NULL,
                                 I_SCOPE_ID       IN     VARCHAR2 DEFAULT NULL) RETURN BOOLEAN IS

   l_erro      VARCHAR2(4000);
   l_name      VARCHAR2(100) := G_PACKAGE_NAME||'.GET_REST_DAYS_NR_MONTHS';
   l_parameter VARCHAR2(100) := 'PREDICTED_REST_DAYS_NR_MONTHS';

BEGIN

   O_NR_MONTHS := PCK_CORE_PARAMETER.GETNUMBERATTR(l_parameter,I_SCOPE,I_SCOPE_ID);
   --
   IF O_NR_MONTHS IS NULL OR (O_NR_MONTHS NOT BETWEEN 1 AND 12) THEN

      O_ERROR_MESSAGE := n_Mensagem.Get(i_lista_erros => O_ERROR_MESSAGE,
                                        i_cod_erro    => 'PARAMETER_NOT_EXISTS',
                                        i_idioma      => PCK_CORE_USER.GET_USER_LANGUAGE(USER),
                                        i_Parametro1  => l_parameter);

      IF G_NOTIF_DEST_CODE IS NOT NULL THEN
         IF NOT n_aviso.create_error_notification (O_ERROR_MESSAGE => O_ERROR_MESSAGE,
                                                   I_processo      => GV_PROCESS_NAME,
                                                   I_level         => GV_LEVEL,
                                                   I_alias         => 'PARAMETRO_NAO_DEFINIDO',
                                                   I_subtipo       => 'PARAMETROS',
                                                   I_para          => G_NOTIF_DEST_CODE,
                                                   I_param1        => l_parameter) THEN
            RETURN FALSE;
         END IF;
      END IF;
      --
      RETURN FALSE;
   END IF;
   --
   RETURN TRUE;
 EXCEPTION
   WHEN OTHERS THEN

      l_erro := Pck_Escala_Debug.Fnc_Monta_Mensagem('PACKAGE_ERROR',
                                                     SQLERRM,
                                                     l_name,
                                                     To_Char(SQLCODE));
      O_ERROR_MESSAGE := n_Mensagem.Get(O_ERROR_MESSAGE, l_erro, PCK_CORE_USER.GET_USER_LANGUAGE(USER));
      --
      RETURN FALSE;

END GET_REST_DAYS_NR_MONTHS;
--
--
FUNCTION GET_AUTO_APROVE_IND(O_ERROR_MESSAGE  IN OUT D_ARRAY_MENSAGEM_ERRO_TP,
                             O_IS_AUTO_APRV      OUT VARCHAR2,
                             I_SCOPE          IN     VARCHAR2 DEFAULT NULL,
                             I_SCOPE_ID       IN     VARCHAR2 DEFAULT NULL) RETURN BOOLEAN IS

   l_erro      VARCHAR2(4000);
   l_name      VARCHAR2(100) := G_PACKAGE_NAME||'.GET_AUTO_APROVE_IND';
   l_parameter VARCHAR2(100) := 'REST_DAYS_AUTO_APPROVE';

BEGIN

   O_IS_AUTO_APRV := PCK_CORE_PARAMETER.GETCHARATTR(l_parameter,I_SCOPE,I_SCOPE_ID);
   --
   IF O_IS_AUTO_APRV IS NULL  THEN

      O_ERROR_MESSAGE := n_Mensagem.Get(i_lista_erros => O_ERROR_MESSAGE,
                                        i_cod_erro    => 'PARAMETER_NOT_EXISTS',
                                        i_idioma      => PCK_CORE_USER.GET_USER_LANGUAGE(USER),
                                        i_Parametro1  => l_parameter);

      IF G_NOTIF_DEST_CODE IS NOT NULL THEN
         IF NOT n_aviso.create_error_notification (O_ERROR_MESSAGE => O_ERROR_MESSAGE,
                                                   I_processo      => GV_PROCESS_NAME,
                                                   I_level         => GV_LEVEL,
                                                   I_alias         => 'PARAMETRO_NAO_DEFINIDO',
                                                   I_subtipo       => 'PARAMETROS',
                                                   I_para          => G_NOTIF_DEST_CODE,
                                                   I_param1        => l_parameter) THEN
            RETURN FALSE;
         END IF;
      END IF;
      --
      RETURN FALSE;
   END IF;
   --
   RETURN TRUE;
 EXCEPTION
   WHEN OTHERS THEN

      l_erro := Pck_Escala_Debug.Fnc_Monta_Mensagem('PACKAGE_ERROR',SQLERRM,l_name,To_Char(SQLCODE));
      O_ERROR_MESSAGE := n_Mensagem.Get(O_ERROR_MESSAGE, l_erro, PCK_CORE_USER.GET_USER_LANGUAGE(USER));
      --
      RETURN FALSE;

END GET_AUTO_APROVE_IND;
------------------------------------------------------------------------------
--Get default cicle for employees that dont have fixed rest days in their cicles
------------------------------------------------------------------------------
FUNCTION GET_DEFAULT_REST_DAYS_CICLE(O_ERROR_MESSAGE IN OUT D_ARRAY_MENSAGEM_ERRO_TP,
                                     O_DE_CICLE         OUT ESC_CICLO.CODIGO%TYPE,
                                     I_FK_SECTION    IN     ESC_SECAO.CODIGO%TYPE)
   RETURN BOOLEAN IS

   L_NAME          CONSTANT VARCHAR2(60) := G_PACKAGE_NAME||'.GET_DEFAULT_REST_DAYS_CICLE';
   l_erro          VARCHAR2(4000);


BEGIN

   O_DE_CICLE := PCK_CORE_PARAMETER.GETNUMBERATTR('DEFAULT_REST_DAYS_CICLE',
                                                  'S', --SECTION LEVEL PARAMETER
                                                  I_FK_SECTION);

   IF O_DE_CICLE IS NULL OR O_DE_CICLE = 0 THEN

      O_ERROR_MESSAGE := n_Mensagem.Get(i_lista_erros => O_ERROR_MESSAGE,
                                        i_cod_erro    => 'PARAMETER_NOT_EXISTS',
                                        i_idioma      => PCK_CORE_USER.GET_USER_LANGUAGE(USER),
                                        i_Parametro1  => 'DEFAULT_REST_DAYS_CICLE');

      IF G_NOTIF_DEST_CODE IS NOT NULL THEN
         IF NOT n_aviso.create_error_notification (O_ERROR_MESSAGE => O_ERROR_MESSAGE,
                                                   I_processo      => GV_PROCESS_NAME,
                                                   I_level         => GV_LEVEL,
                                                   I_alias         => 'PARAMETRO_NAO_DEFINIDO',
                                                   I_subtipo       => 'PARAMETROS',
                                                   I_para          => G_NOTIF_DEST_CODE,
                                                   I_param1        => 'DEFAULT_REST_DAYS_CICLE') THEN
            RETURN FALSE;
         END IF;
      END IF;
      --
      RETURN FALSE;
   END IF;

   RETURN TRUE;
EXCEPTION
   WHEN OTHERS THEN

       l_erro := Pck_Escala_Debug.Fnc_Monta_Mensagem('PACKAGE_ERROR',SQLERRM,l_name,To_Char(SQLCODE));
      O_ERROR_MESSAGE := n_Mensagem.Get(O_ERROR_MESSAGE, l_erro, PCK_CORE_USER.GET_USER_LANGUAGE(USER));
      --
      RETURN FALSE;
END GET_DEFAULT_REST_DAYS_CICLE;
--
--
FUNCTION APPLY_EXCHANGE_SCHEDULE (O_ERROR_MESSAGE IN OUT D_ARRAY_MENSAGEM_ERRO_TP,
                                  I_FK_EMPLOYEE_A IN     ESC_COLABORADOR.CODIGO%TYPE,
                                  I_FK_EMPLOYEE_B IN     ESC_COLABORADOR.CODIGO%TYPE,
                                  I_APPLY_DATE_A  IN     DATE,
                                  I_APPLY_DATE_B  IN     DATE,
                                  I_TYPE_A        IN     VARCHAR2,
                                  I_TYPE_B        IN     VARCHAR2) RETURN BOOLEAN IS

  L_NAME  VARCHAR2(60) := G_PACKAGE_NAME||'.APPLY_EXCHANGE_SCHEDULE';
  L_ERRO  VARCHAR2(4000);


  --auxiliar function
  FUNCTION add_records (O_ERROR_MESSAGE IN OUT D_ARRAY_MENSAGEM_ERRO_TP,
                        i_fk_employee   IN     ESC_COLABORADOR.CODIGO%TYPE,
                        i_date          IN     DATE,
                        i_type          IN     VARCHAR2) RETURN BOOLEAN IS

     l_erro VARCHAR2(4000);
     l_contract_id CORE_CONTRACT_LABOR.id%type;

     CURSOR c_get_contract (i_employee ESC_COLABORADOR.CODIGO%TYPE, i_date DATE) IS
        SELECT id
          FROM TABLE(PCK_CORE_EMPLOYEE_CONTRACT.GETCURRENTCONTRACT(i_date, i_employee));
  BEGIN

     OPEN c_get_contract(i_fk_employee,i_date);
     FETCH c_get_contract INTO l_contract_id;
     CLOSE c_get_contract;
     --
     IF l_contract_id IS NOT NULL THEN

        FOR c in (SELECT id
                    FROM predicted_rest_days_map
                   WHERE fk_employee = i_fk_employee
                     AND i_date BETWEEN start_date and end_date
                     AND state NOT IN (C_STATE_CANCELLED,C_STATE_ERROR)) LOOP

           DELETE Predicted_Rest_Days_Map_Dtl
            WHERE fk_pred_rest_days_map = c.id
              AND rest_start_date = i_date
              --nao apagar a folga se envolver a troca com ausencias
              AND i_type <> 'A';

           IF i_type IN ('F','N') THEN
              INSERT INTO Predicted_Rest_Days_Map_Dtl(Change_Type,
                                                      Fk_Pred_Rest_Days_Map,
                                                      Rest_Start_Date,
                                                      Rest_End_Date,
                                                      Rest_Type)
                                              VALUES (GV_CHANGE_BY_EXCHANGE,
                                                      c.id,
                                                      i_date,
                                                      i_date,
                                                      DECODE(i_type,'F',TYPE_REST_DAY,TYPE_EMPTY_DAY));
           END IF;
        END LOOP;
     END IF;
     RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
       l_erro := Pck_Escala_Debug.Fnc_Monta_Mensagem('PACKAGE_ERROR',
                                                     SQLERRM,
                                                     'ADD_RECORDS',
                                                     To_Char(SQLCODE));
      O_ERROR_MESSAGE := n_Mensagem.Get(O_ERROR_MESSAGE, l_erro, PCK_CORE_USER.GET_USER_LANGUAGE(USER));
      --
      RETURN FALSE;
   END;

BEGIN
   --A
   IF  I_FK_EMPLOYEE_A = I_FK_EMPLOYEE_B AND  I_APPLY_DATE_A = I_APPLY_DATE_B THEN
      IF NOT add_records (O_ERROR_MESSAGE,
                          I_FK_EMPLOYEE_A,
                          I_APPLY_DATE_A,
                          I_TYPE_B) THEN
         RETURN FALSE;
      END IF;
   --A
   ELSIF I_APPLY_DATE_A <> I_APPLY_DATE_B THEN
      --First date exchange
      IF NOT add_records (O_ERROR_MESSAGE,
                          I_FK_EMPLOYEE_A,
                          I_APPLY_DATE_A,
                          I_TYPE_B) THEN
         RETURN FALSE;
      END IF;
      --Second date exchange
      IF NOT add_records (O_ERROR_MESSAGE,
                          I_FK_EMPLOYEE_A,
                          I_APPLY_DATE_B,
                          I_TYPE_A) THEN
         RETURN FALSE;
      END IF;
   --T
   ELSIF I_FK_EMPLOYEE_A <> I_FK_EMPLOYEE_B THEN
      --first employee exchange
      IF NOT add_records (O_ERROR_MESSAGE,
                          I_FK_EMPLOYEE_A,
                          I_APPLY_DATE_A,
                          I_TYPE_B) THEN
         RETURN FALSE;
      END IF;
      --second employee exchange
      IF NOT add_records (O_ERROR_MESSAGE,
                          I_FK_EMPLOYEE_B,
                          I_APPLY_DATE_A,
                          I_TYPE_A) THEN
         RETURN FALSE;
      END IF;
   END IF;
   RETURN TRUE;
EXCEPTION
   WHEN OTHERS THEN

      l_erro := Pck_Escala_Debug.Fnc_Monta_Mensagem('PACKAGE_ERROR',
                                                     SQLERRM,
                                                     l_name,
                                                     To_Char(SQLCODE));
      O_ERROR_MESSAGE := n_Mensagem.Get(O_ERROR_MESSAGE, l_erro, PCK_CORE_USER.GET_USER_LANGUAGE(USER));
      --
      RETURN FALSE;
END APPLY_EXCHANGE_SCHEDULE;
--
--
FUNCTION GET_TOTAL_REST_DAYS (O_MENSAGEM_ERRO     IN OUT D_ARRAY_MENSAGEM_ERRO_TP,
                              O_TOTAL_REST_DAYS      OUT NUMBER,
                              I_FK_EMPLOYEE       IN     ESC_COLABORADOR.CODIGO%TYPE,
                              I_START_DATE        IN     DATE,
                              I_END_DATE          IN     DATE)
  RETURN BOOLEAN IS

  l_name CONSTANT VARCHAR2(100) := G_PACKAGE_NAME||'.GET_TOTAL_REST_DAYS';
  l_erro VARCHAR2(4000);

BEGIN

   SELECT COUNT(*)
     INTO O_TOTAL_REST_DAYS
     FROM (SELECT DISTINCT dtl.rest_start_date
             FROM predicted_rest_days_map_dtl dtl,
                  predicted_rest_days_map     dm
            WHERE dm.fk_employee = I_FK_EMPLOYEE
              AND dm.state IN (C_STATE_APPROVED, C_STATE_PROCESSED)
              AND dm.id = dtl.fk_pred_rest_days_map
              AND dtl.rest_type IN (TYPE_REST_DAY,TYPE_CLOSE_HOLIDAY)
              AND dtl.rest_start_date BETWEEN I_START_DATE AND I_END_DATE);

   RETURN TRUE;
EXCEPTION
   WHEN OTHERS THEN
      l_erro := Pck_Escala_Debug.Fnc_Monta_Mensagem('PACKAGE_ERROR',
                                                     SQLERRM,
                                                     l_name,
                                                     To_Char(SQLCODE));
      o_Mensagem_Erro := n_Mensagem.Get(o_Mensagem_Erro, l_erro, PCK_CORE_USER.GET_USER_LANGUAGE(USER));
      RETURN FALSE;
END GET_TOTAL_REST_DAYS;
------------------------------------------------------------------------------
--Get employee rest days map for search year
------------------------------------------------------------------------------
FUNCTION GET_ANUAL_REST_MAP_EMPLOYEE (O_ERROR_MESSAGE     IN OUT D_ARRAY_MENSAGEM_ERRO_TP,
                                      I_FK_UNIT           IN     ESC_UNIDADE.CODIGO%TYPE,
                                      I_FK_EMPLOYEE       IN     ESC_COLABORADOR.CODIGO%TYPE,
                                      I_YEAR              IN     NUMBER DEFAULT TO_NUMBER(TO_CHAR(SYSDATE, 'YYYY')),
                                      I_LANGUAGE          IN     NUMBER,
                                      O_ABS_DAYS          IN OUT SYS_REFCURSOR)
   RETURN NUMBER IS
   --
   L_NAME              CONSTANT VARCHAR2(100) := G_PACKAGE_NAME||'.GET_ANUAL_REST_MAP_EMPLOYEE';
   L_NA_VALUE          VARCHAR2(50)           := N_DOMINIO_DETALHE_TRADUCAO.get('NDVS', 'N.D.', I_LANGUAGE);
   --
   L_ABS_BEGIN_DATE    CORE_PARAMETER.DATEVALUE%TYPE;
   L_ABS_END_DATE      CORE_PARAMETER.DATEVALUE%TYPE;
   --
   l_erro              VARCHAR2(4000);
   --
   l_switch_day_month  DATE;
   l_add_nr_months     NUMBER;

BEGIN

   ---------------------------------------------------------------------
   --Get day and month that will provoke system to switch to next year
   ---------------------------------------------------------------------
   IF NOT GET_SWITCH_YEAR (o_error_message,
                           l_switch_day_month,
                           PCK_CORE_PARAMETER.G_SCOPE_STORE, --store
                           I_FK_UNIT) THEN
      RETURN 0;
   END IF;


   --------------------------------------------------------
   --Get number of months to define the end period date
   --------------------------------------------------------
   IF NOT GET_REST_DAYS_NR_MONTHS(o_error_message,
                                  l_add_nr_months,
                                  PCK_CORE_PARAMETER.G_SCOPE_STORE, --store
                                  I_FK_UNIT) THEN
      RETURN 0;
   END IF;


   --Get range dates for search
   IF NOT CALCULATE_REST_DAY_MAP_RANGE (O_ERROR_MESSAGE,
                                        I_YEAR,
                                        l_switch_day_month,
                                        l_add_nr_months,
                                        L_ABS_BEGIN_DATE,
                                        L_ABS_END_DATE) THEN
      RETURN 0;
   END IF;


   -- cursor for absence days
   OPEN O_ABS_DAYS FOR
      SELECT COL.CODIGO               FK_EMPLOYEE
             ,ABS.CODIGO               CODIGO
             ,ABS.FK_MOTIVO_AUSENCIA   FK_MOTIVO_AUSENCIA
             ,MA.DESCRICAO             DESCR_MOTIVO_AUSENCIA
             ,NVL(MA.ALIAS,L_NA_VALUE) ALIAS_MOTIVO_AUSENCIA
             ,MA.COR                   COR_MOTIVO_AUSENCIA
             ,ABS.CONTINGENTID         CONTINGENTID
             ,C.NAME                   CONTINGENT_DESCR
             ,ABS.CONTINGENT_EMP_ID    CONTINGENT_EMP_ID
             ,ABS.ABS_TYPE             ABS_TYPE
             ,ABS.ABS_S_DATE           ABS_S_DATE
             ,ABS.ABS_E_DATE           ABS_E_DATE
             ,ABS.ABS_RULE_ID          ABS_RULE_ID
             ,R.NAME                   ABS_RULE_DESCR
             ,ABS.ABS_S_HOUR           ABS_S_HOUR
             ,ABS.ABS_E_HOUR           ABS_E_HOUR
        FROM
        (
              SELECT  A.FK_COLABORADOR,
                      A.FK_MOTIVO_AUSENCIA,
                      A.CONTINGENTID,
                      A.CONTINGENT_EMP_ID,
                      A.CODIGO,
                      'DIAS' ABS_TYPE,
                      A.DATA_INI ABS_S_DATE,
                      A.DATA_FIM ABS_E_DATE,
                      NULL ABS_RULE_ID,
                      NULL ABS_S_HOUR,
                      NULL ABS_E_HOUR
                FROM ESC_AUSENCIA A
               WHERE A.DATA_EXCLUSAO IS NULL
                 AND TRUNC(A.DATA_INI) BETWEEN L_ABS_BEGIN_DATE AND L_ABS_END_DATE
                 AND A.FK_COLABORADOR = I_FK_EMPLOYEE
              UNION ALL
              SELECT AP.FK_COLABORADOR,
                     AP.FK_MOTIVO_AUSENCIA,
                     AP.CONTINGENTID,
                     AP.CONTINGENT_EMP_ID,
                     AP.CODIGO,
                     'HORAS' ABS_TYPE,
                     AP.DATA_INI ABS_S_DATE,
                     AP.DATA_FIM ABS_E_DATE,
                     AP.ABS_RULE_ID,
                     AP.HORA_INI ABS_S_HOUR,
                     AP.HORA_FIM ABS_E_HOUR
                FROM ESC_AUSENCIA_POSTO  AP
               WHERE AP.DATA_EXCLUSAO IS NULL
                 AND AP.FK_COLABORADOR = I_FK_EMPLOYEE
                 AND TRUNC(AP.DATA_INI) BETWEEN L_ABS_BEGIN_DATE AND L_ABS_END_DATE
        )ABS
        JOIN ESC_MOTIVO_AUSENCIA      MA  ON  MA.CODIGO         =  ABS.FK_MOTIVO_AUSENCIA
        JOIN ESC_COLABORADOR         COL  ON COL.CODIGO         =  ABS.FK_COLABORADOR
   LEFT JOIN CORE_ABSENCES_RULES       R  ON  (R.ID             =  ABS.ABS_RULE_ID)
   LEFT JOIN CORE_CONTINGENT_ABSENCES  C  ON  (C.ID             =  ABS.CONTINGENTID)
   UNION ALL
   ---rest days
    SELECT  COL.CODIGO          FK_EMPLOYEE
             ,NULL              CODIGO
             ,NULL              FK_MOTIVO_AUSENCIA
             ,NULL              DESCR_MOTIVO_AUSENCIA
             ,NULL              ALIAS_MOTIVO_AUSENCIA
             ,NULL              COR_MOTIVO_AUSENCIA
             ,NULL              CONTINGENTID
             ,NULL              CONTINGENT_DESCR
             ,NULL              CONTINGENT_EMP_ID
             ,MD.REST_TYPE       ABS_TYPE
             ,MD.REST_START_DATE ABS_S_DATE
             ,MD.REST_END_DATE   ABS_E_DATE
             ,NULL               ABS_RULE_ID
             ,NULL               ABS_RULE_DESCR
             ,NULL               ABS_S_HOUR
             ,NULL               ABS_E_HOUR
        FROM PREDICTED_REST_DAYS_MAP_DTL MD
        JOIN PREDICTED_REST_DAYS_MAP M ON M.ID = MD.FK_PRED_REST_DAYS_MAP
        JOIN ESC_COLABORADOR COL ON COL.CODIGO = M.FK_EMPLOYEE
       WHERE M.STATE IN (C_STATE_PROCESSED, C_STATE_APPROVED)
         AND M.CURRENT_YEAR = I_YEAR
         AND M.FK_EMPLOYEE  = I_FK_EMPLOYEE;

   RETURN 1;

 EXCEPTION
   WHEN OTHERS THEN
      l_erro          := Pck_Escala_Debug.Fnc_Monta_Mensagem('PACKAGE_ERROR', SQLERRM, l_name, To_Char(SQLCODE));
      O_ERROR_MESSAGE := n_Mensagem.Get(O_ERROR_MESSAGE, l_erro, PCK_CORE_USER.GET_USER_LANGUAGE(USER));
     RETURN 0;
END GET_ANUAL_REST_MAP_EMPLOYEE;

------------------------------------------------------------------------------
--Get employees rest days map for search month
------------------------------------------------------------------------------ 
FUNCTION GET_MONTH_REST_MAP_EMPLOYEES (O_ERROR_MESSAGE     IN OUT D_ARRAY_MENSAGEM_ERRO_TP,
                                       I_FK_UNIT           IN     ESC_UNIDADE.CODIGO%TYPE,
                                       I_FK_SECTION        IN     ESC_SECAO.CODIGO%TYPE,
                                       I_FK_WORKSTATION_TP IN     ESC_TIPO_POSTO.CODIGO%TYPE,
                                       I_FIRST_DAY_MONTH   IN     DATE,
                                       I_LANGUAGE          IN     NUMBER,
                                       O_ABS_DAYS          IN OUT SYS_REFCURSOR)
   RETURN NUMBER IS
   --
   L_NAME              CONSTANT VARCHAR2(100) := G_PACKAGE_NAME||'.GET_MONTH_REST_MAP_EMPLOYEES';
   L_NA_VALUE          VARCHAR2(50)           := N_DOMINIO_DETALHE_TRADUCAO.get('NDVS', 'N.D.', I_LANGUAGE);

   L_ABS_BEGIN_DATE    CORE_PARAMETER.DATEVALUE%TYPE;
   L_ABS_END_DATE      CORE_PARAMETER.DATEVALUE%TYPE;
   L_CURRENT_YEAR      NUMBER;

   l_erro              VARCHAR2(4000);


BEGIN
   
   --First day of month
   L_ABS_BEGIN_DATE := I_FIRST_DAY_MONTH;
   --Last day of the search month
   L_ABS_END_DATE   := LAST_DAY(trunc(I_FIRST_DAY_MONTH));
   --Current Year
   L_CURRENT_YEAR := TO_NUMBER(TO_CHAR(I_FIRST_DAY_MONTH, 'YYYY'));
 


   -- cursor for absence days
   OPEN O_ABS_DAYS FOR
      SELECT COL.CODIGO               FK_EMPLOYEE
             ,ABS.CODIGO               CODIGO
             ,ABS.FK_MOTIVO_AUSENCIA   FK_MOTIVO_AUSENCIA
             ,MA.DESCRICAO             DESCR_MOTIVO_AUSENCIA
             ,NVL(MA.ALIAS,L_NA_VALUE) ALIAS_MOTIVO_AUSENCIA
             ,MA.COR                   COR_MOTIVO_AUSENCIA
             ,ABS.CONTINGENTID         CONTINGENTID
             ,C.NAME                   CONTINGENT_DESCR
             ,ABS.CONTINGENT_EMP_ID    CONTINGENT_EMP_ID
             ,ABS.ABS_TYPE             ABS_TYPE
             ,ABS.ABS_S_DATE           ABS_S_DATE
             ,ABS.ABS_E_DATE           ABS_E_DATE
             ,ABS.ABS_RULE_ID          ABS_RULE_ID
             ,R.NAME                   ABS_RULE_DESCR
             ,ABS.ABS_S_HOUR           ABS_S_HOUR
             ,ABS.ABS_E_HOUR           ABS_E_HOUR
        FROM
        (
              SELECT  A.FK_COLABORADOR,
                      A.FK_MOTIVO_AUSENCIA,
                      A.CONTINGENTID,
                      A.CONTINGENT_EMP_ID,
                      A.CODIGO,
                      'DIAS' ABS_TYPE,
                      A.DATA_INI ABS_S_DATE,
                      A.DATA_FIM ABS_E_DATE,
                      NULL ABS_RULE_ID,
                      NULL ABS_S_HOUR,
                      NULL ABS_E_HOUR
                FROM ESC_AUSENCIA A
               WHERE A.DATA_EXCLUSAO IS NULL
                 AND TRUNC(A.DATA_INI) BETWEEN L_ABS_BEGIN_DATE AND L_ABS_END_DATE
              UNION ALL
              SELECT AP.FK_COLABORADOR,
                     AP.FK_MOTIVO_AUSENCIA,
                     AP.CONTINGENTID,
                     AP.CONTINGENT_EMP_ID,
                     AP.CODIGO,
                     'HORAS' ABS_TYPE,
                     AP.DATA_INI ABS_S_DATE,
                     AP.DATA_FIM ABS_E_DATE,
                     AP.ABS_RULE_ID,
                     AP.HORA_INI ABS_S_HOUR,
                     AP.HORA_FIM ABS_E_HOUR
                FROM ESC_AUSENCIA_POSTO  AP
               WHERE AP.DATA_EXCLUSAO IS NULL
                 AND TRUNC(AP.DATA_INI) BETWEEN L_ABS_BEGIN_DATE AND L_ABS_END_DATE
        )ABS
        JOIN ESC_MOTIVO_AUSENCIA      MA  ON  MA.CODIGO         =  ABS.FK_MOTIVO_AUSENCIA
        JOIN ESC_COLABORADOR         COL  ON COL.CODIGO         =  ABS.FK_COLABORADOR
        JOIN ESC_GRUPO                 G  ON   G.CODIGO         =  COL.FK_GRUPO
        JOIN ESC_SECAO                 S  ON   S.CODIGO         =    G.FK_SECAO
        JOIN ESC_TIPO_POSTO           TP  ON  TP.FK_SECAO       =    S.CODIGO
        JOIN ESC_COLABORADOR_POSTO    CP  ON  CP.FK_COLABORADOR =  COL.CODIGO  AND  CP.FK_TIPO_POSTO  =   TP.CODIGO  AND  CP.POLIVALENCIA   =    1 --MAIN WORKSTATION TYPE
        JOIN ESC_UNIDADE               U  ON   U.CODIGO         =    S.FK_UNIDADE
   LEFT JOIN CORE_ABSENCES_RULES       R  ON  (R.ID             =  ABS.ABS_RULE_ID)
   LEFT JOIN CORE_CONTINGENT_ABSENCES  C  ON  (C.ID             =  ABS.CONTINGENTID)
       WHERE U.CODIGO    = NVL(I_FK_UNIT,            U.CODIGO)
         AND S.CODIGO    = NVL(I_FK_SECTION,         S.CODIGO)
         AND TP.CODIGO   = NVL(I_FK_WORKSTATION_TP, TP.CODIGO)
   UNION ALL
   ---rest days
    SELECT  COL.CODIGO          FK_EMPLOYEE
             ,NULL              CODIGO
             ,NULL              FK_MOTIVO_AUSENCIA
             ,NULL              DESCR_MOTIVO_AUSENCIA
             ,NULL              ALIAS_MOTIVO_AUSENCIA
             ,NULL              COR_MOTIVO_AUSENCIA
             ,NULL              CONTINGENTID
             ,NULL              CONTINGENT_DESCR
             ,NULL              CONTINGENT_EMP_ID
             ,MD.REST_TYPE       ABS_TYPE
             ,MD.REST_START_DATE ABS_S_DATE
             ,MD.REST_END_DATE   ABS_E_DATE
             ,NULL               ABS_RULE_ID
             ,NULL               ABS_RULE_DESCR
             ,NULL               ABS_S_HOUR
             ,NULL               ABS_E_HOUR
        FROM PREDICTED_REST_DAYS_MAP_DTL MD
        JOIN PREDICTED_REST_DAYS_MAP M ON M.ID = MD.FK_PRED_REST_DAYS_MAP
        JOIN ESC_COLABORADOR COL ON COL.CODIGO = M.FK_EMPLOYEE
        JOIN ESC_GRUPO G ON G.CODIGO = COL.FK_GRUPO
        JOIN ESC_SECAO S ON S.CODIGO = G.FK_SECAO
        JOIN ESC_TIPO_POSTO TP ON TP.FK_SECAO = S.CODIGO
        JOIN ESC_COLABORADOR_POSTO CP ON CP.FK_COLABORADOR = COL.CODIGO
                                        AND CP.FK_TIPO_POSTO = TP.CODIGO
                                        AND CP.POLIVALENCIA = 1 --MAIN WORKSTATION TYPE
        JOIN ESC_UNIDADE U ON U.CODIGO = S.FK_UNIDADE
       WHERE M.STATE IN (C_STATE_PROCESSED, C_STATE_APPROVED)
         AND M.CURRENT_YEAR = L_CURRENT_YEAR
         AND MD.REST_START_DATE BETWEEN L_ABS_BEGIN_DATE AND L_ABS_END_DATE
         AND U.CODIGO       = NVL(I_FK_UNIT, U.CODIGO)
         AND S.CODIGO       = NVL(I_FK_SECTION, S.CODIGO)
         AND TP.CODIGO      = NVL(I_FK_WORKSTATION_TP, TP.CODIGO);

   RETURN 1;

 EXCEPTION
   WHEN OTHERS THEN
      l_erro          := Pck_Escala_Debug.Fnc_Monta_Mensagem('PACKAGE_ERROR', SQLERRM, l_name, To_Char(SQLCODE));
      O_ERROR_MESSAGE := n_Mensagem.Get(O_ERROR_MESSAGE, l_erro, PCK_CORE_USER.GET_USER_LANGUAGE(USER));
     RETURN 0;
END GET_MONTH_REST_MAP_EMPLOYEES;

------------------------------------------------------------------------------
--set close holidays
------------------------------------------------------------------------------
FUNCTION SET_HOLIDAY_CLOSE_DAYS(O_ERROR_MESSAGE  IN OUT D_ARRAY_MENSAGEM_ERRO_TP,
                                I_FK_UNIT        IN     ESC_UNIDADE.CODIGO%TYPE,
                                I_FK_SECTION     IN     ESC_SECAO.CODIGO%TYPE,
                                I_FK_EMPLOYEE    IN     ESC_COLABORADOR.CODIGO%TYPE,
                                I_BEGIN_DATE     IN     DATE,
                                I_END_DATE       IN     DATE,
                                I_CHANGE_TYPE    IN     VARCHAR2) RETURN BOOLEAN IS

   l_erro      VARCHAR2(4000);
   l_name      VARCHAR2(100) := G_PACKAGE_NAME||'.SET_HOLIDAY_CLOSE_DAYS';

   CURSOR c_get_unit_detail IS
      SELECT fk_cidade,
             fk_estado,
             fk_pais
        FROM esc_unidade
       WHERE codigo = i_fk_unit;

   l_row  c_get_unit_detail%ROWTYPE;

BEGIN

   --
   OPEN c_get_unit_detail;
   FETCH c_get_unit_detail INTO l_row;
   CLOSE c_get_unit_detail;
   --
   --
   MERGE INTO predicted_rest_days_map_dtl rdml
      USING (SELECT rdm.id,
                    hol_days.data
               FROM predicted_rest_days_map rdm,
                    (SELECT DISTINCT data
                       FROM (---unit---
                             SELECT TO_DATE(TO_CHAR(DATA, 'DDMM') ||DECODE(FERIADO_FIXO,'S',TO_CHAR(SYSDATE, 'YYYY'),TO_CHAR(DATA, 'YYYY')),'DDMMYYYY') DATA
                               FROM ESC_FERIADO
                              WHERE FK_UNIDADE = i_fk_unit
                                /*AND tipo IN (1, 3)*/
                             ---Country---
                              UNION ALL
                             SELECT TO_DATE(TO_CHAR(DATA, 'DDMM') ||DECODE(FERIADO_FIXO,'S',TO_CHAR(SYSDATE, 'YYYY'),TO_CHAR(DATA, 'YYYY')),'DDMMYYYY') DATA
                               FROM ESC_FERIADO
                              WHERE FK_PAIS = l_row.fk_pais
                              /*  AND tipo IN (1, 3)*/
                             ---State----
                              UNION ALL
                             SELECT TO_DATE(TO_CHAR(DATA, 'DDMM') ||DECODE(FERIADO_FIXO,'S',TO_CHAR(SYSDATE, 'YYYY'),TO_CHAR(DATA, 'YYYY')),'DDMMYYYY') DATA
                               FROM ESC_FERIADO
                              WHERE FK_ESTADO = l_row.fk_estado
                                /*AND tipo IN (1, 3)*/
                             ---City---
                              UNION ALL
                             SELECT TO_DATE(TO_CHAR(DATA, 'DDMM') ||DECODE(FERIADO_FIXO,'S',TO_CHAR(SYSDATE, 'YYYY'),TO_CHAR(DATA, 'YYYY')),'DDMMYYYY') DATA
                               FROM ESC_FERIADO
                              WHERE FK_CIDADE = l_row.fk_cidade
                                /*AND tipo IN (1, 3)*/)
                        WHERE data BETWEEN I_BEGIN_DATE AND I_END_DATE
                        ) hol_days
              WHERE (--employee fulfilled
                    (i_fk_employee IS NOT NULL AND rdm.fk_employee = i_fk_employee)
                    OR
                     --section fulfilled
                    (i_fk_section IS NOT NULL AND rdm.fk_employee IN (SELECT ec.codigo
                                                                        FROM esc_colaborador ec,
                                                                             esc_grupo eg
                                                                       WHERE ec.fk_grupo = eg.fk_grupo
                                                                         AND eg.fk_secao = i_fk_section
                                                                         AND data_admissao <= SYSDATE
                                                                         AND (data_demissao IS NULL OR data_demissao > SYSDATE))))
                AND rdm.state = C_STATE_RUNNING
                AND hol_days.data BETWEEN rdm.start_date AND rdm.end_date
            ) d  ON (rdml.fk_pred_rest_days_map = d.id AND d.data= rdml.rest_start_date)
       WHEN NOT MATCHED THEN
          INSERT (fk_pred_rest_days_map,
                  rest_type,
                  rest_start_date,
                  rest_end_date,
                  change_type)
          VALUES (d.id,
                  TYPE_CLOSE_HOLIDAY,
                  d.data,
                  d.data,
                  I_CHANGE_TYPE)
       WHEN MATCHED THEN
          UPDATE
             SET rest_type   = TYPE_CLOSE_HOLIDAY,
                 change_type = I_CHANGE_TYPE,
                 default_cicle = NULL
                 --If 1, then replace absence for holiday
           WHERE NVL(PCK_CORE_LABOR_LAW.GETATTRNUMBER('TREATLABELHOLIDAY',1),0) = 1;

   RETURN TRUE;
EXCEPTION
   WHEN OTHERS THEN
      l_erro := Pck_Escala_Debug.Fnc_Monta_Mensagem('PACKAGE_ERROR',SQLERRM,l_name,To_Char(SQLCODE));
      O_ERROR_MESSAGE := n_Mensagem.Get(O_ERROR_MESSAGE, l_erro, PCK_CORE_USER.GET_USER_LANGUAGE(USER));
      --
      RETURN FALSE;
 END SET_HOLIDAY_CLOSE_DAYS;
------------------------------------------------------------------------------
--Set Aproved schedules to predicted rest days map
------------------------------------------------------------------------------
FUNCTION SET_APPROVE_SCHEDULE_DAYS(O_ERROR_MESSAGE  IN OUT D_ARRAY_MENSAGEM_ERRO_TP,
                                   I_FK_EMPLOYEE    IN     ESC_COLABORADOR.CODIGO%TYPE,
                                   I_BEGIN_DATE     IN     DATE,
                                   I_END_DATE       IN     DATE,
                                   I_CHANGE_TYPE    IN     VARCHAR2) RETURN BOOLEAN IS
   l_erro      VARCHAR2(4000);
   l_name      VARCHAR2(100) := G_PACKAGE_NAME||'.SET_APPROVE_SCHEDULE_DAYS';

   CURSOR c_get_limits IS
      SELECT TRUNC(MIN(data), 'IW')    min_week,
             TRUNC(MAX(data), 'IW')+ 6 max_week
        FROM esc_horario_colaborador
       WHERE fk_colaborador = I_FK_EMPLOYEE
         AND data BETWEEN I_BEGIN_DATE AND I_END_DATE;

   l_limits C_GET_LIMITS%ROWTYPE;

BEGIN


   OPEN c_get_limits;
   FETCH c_get_limits INTO l_limits.min_week,l_limits.max_week;
   CLOSE c_get_limits;


  --Remove existent predicted rest days for employee schedule weeks aprove
   DELETE predicted_rest_days_map_dtl dtl
    WHERE dtl.rest_start_date BETWEEN l_limits.min_week AND l_limits.max_week
      --Nao remover os dias vazios gerados pelo ciclo de folgas
      AND EXISTS (SELECT 1
                    FROM predicted_rest_days_map dm
                   WHERE dm.fk_employee = I_FK_EMPLOYEE
                     AND dm.state = C_STATE_RUNNING
                     AND dm.id = dtl.fk_pred_rest_days_map)
      AND dtl.rest_type <> 'E'
      --Nao remover as folgas geradas pelo ciclo de folgas em que o algoritmo colocou ausencia no horario
      AND NOT EXISTS ( SELECT 1
                         FROM esc_horario_colaborador ehc
                        WHERE ehc.fk_colaborador = I_FK_EMPLOYEE
                          AND ehc.data = dtl.rest_start_date
                          AND dtl.rest_type = 'R'
                          AND ehc.tipo = 'A');

   --Add Rest days from schedule to predicted map

        INSERT INTO predicted_rest_days_map_dtl(fk_pred_rest_days_map,
                                                 rest_type,
                                                 rest_start_date,
                                                 rest_end_date,
                                                 change_type)
               ---REST DAYS
              SELECT rd.id,
                     TYPE_REST_DAY,
                     eh.data,
                     eh.data,
                     I_CHANGE_TYPE
                FROM esc_horario_colaborador eh,
                     predicted_rest_days_map rd
               WHERE eh.fk_colaborador = I_FK_EMPLOYEE
                 AND eh.tipo = 'F'
                 AND eh.data BETWEEN l_limits.min_week AND l_limits.max_week
                 AND eh.fk_colaborador = rd.fk_employee
                 AND rd.state = C_STATE_RUNNING
                 AND eh.data BETWEEN rd.start_date AND rd.end_date
                 AND NOT EXISTS (SELECT 1
                                   FROM predicted_rest_days_map_dtl rdt
                                  WHERE rdt.fk_pred_rest_days_map = rd.id
                                    AND rdt.rest_start_date = eh.data
                                    AND rdt.rest_type = 'E');
            /*   UNION ALL
                ---EMPTY DAYS
              SELECT rd.id,
                     TYPE_EMPTY_DAY,
                     ecv.dia,
                     ecv.dia,
                     I_CHANGE_TYPE
                FROM esc_calendario_vw ecv,
                     predicted_rest_days_map rd
               WHERE rd.fk_employee = I_FK_EMPLOYEE
                 AND rd.state = C_STATE_RUNNING
                 AND ecv.dia BETWEEN rd.start_date AND rd.end_date
                 AND ecv.dia BETWEEN l_limits.min_week AND l_limits.max_week
                 AND NOT EXISTS (SELECT 1
                                   FROM esc_horario_colaborador ehc
                                  WHERE ehc.fk_colaborador = rd.fk_employee
                                    AND ecv.dia = ehc.data
                                    AND ehc.data BETWEEN l_limits.min_week AND l_limits.max_week);*/



   RETURN TRUE;
EXCEPTION
   WHEN OTHERS THEN
      l_erro := Pck_Escala_Debug.Fnc_Monta_Mensagem('PACKAGE_ERROR',SQLERRM,l_name,To_Char(SQLCODE));
      O_ERROR_MESSAGE := n_Mensagem.Get(O_ERROR_MESSAGE, l_erro, PCK_CORE_USER.GET_USER_LANGUAGE(USER));
      --
      RETURN FALSE;
 END SET_APPROVE_SCHEDULE_DAYS;
------------------------------------------------------------------------------
--Set rest days of employee for a given period
--It considers a default cicle if employee doesn't have fixed rest days in his
--cicle
------------------------------------------------------------------------------
FUNCTION SET_PREDICTED_REST_DAYS(O_ERROR_MESSAGE      IN OUT D_ARRAY_MENSAGEM_ERRO_TP,
                                 I_FK_SECTION         IN     ESC_SECAO.CODIGO%TYPE,
                                 I_FK_EMPLOYEE        IN     ESC_COLABORADOR%ROWTYPE,
                                 I_PERIOD_START_DATE  IN     DATE,
                                 I_PERIOD_END_DATE    IN     DATE,
                                 I_CHANGE_TYPE        IN     VARCHAR2)

   RETURN BOOLEAN IS
   --
   l_name  CONSTANT VARCHAR2(100) := G_PACKAGE_NAME||'.SET_PREDICTED_REST_DAYS';
   l_erro  VARCHAR2(4000);
   l_def_cicle ESC_CICLO.CODIGO%TYPE;
BEGIN

   IF NOT  GET_DEFAULT_REST_DAYS_CICLE(O_ERROR_MESSAGE,
                                       l_def_cicle,
                                       I_FK_SECTION) THEN
      RETURN FALSE;
   END IF;

   INSERT INTO predicted_rest_days_map_dtl(fk_pred_rest_days_map,
                                           rest_type,
                                           rest_start_date,
                                           rest_end_date,
                                           change_type,
                                           default_cicle)
   SELECT rd.id,
          --Empty day or Rest day (F = R / N = E)
          DECODE (SUBSTR(aply_type,1,1),'F',TYPE_REST_DAY,TYPE_EMPTY_DAY),
          all_q.check_day,
          all_q.check_day,
          I_CHANGE_TYPE,
          DECODE(length(aply_type),1,NULL,'Y')
     FROM predicted_rest_days_map rd,
          (SELECT all_days.check_day,
                 CASE
                    --Don't have contract
                    WHEN contract_absence = -1 THEN
                       'N'
                    --employee cicle
                    WHEN tot_rest_days IS NOT NULL AND (7 - contract_absence >= 5 AND contract_absence <= tot_rest_days) THEN
                       emp_cicle.tipo_dia
                    --employee cicle
                    WHEN tot_rest_days IS NOT NULL AND (7 - contract_absence < 5) THEN
                       emp_cicle.tipo_dia
                    --Default
                    ELSE
                       cs.tipo_dia ||'@' --workaround to set notification in case of using default cicle
                  END aply_type
                  --default cicle
             FROM esc_ciclo c,
                  esc_ciclo_semana cs,
                  (SELECT (1 + check_day - TRUNC (check_day, 'IW')) day_of_week,
                          check_day
                     FROM (SELECT I_PERIOD_START_DATE + ROWNUM - 1 AS check_day
                             FROM dual
                             CONNECT BY ROWNUM <= I_PERIOD_END_DATE - I_PERIOD_START_DATE + 1)) all_days,
                  ---employee cicle
                  (SELECT check_day,
                          tipo_dia,
                          tot_rest_days,
                          ---replicate the max rest days in contract retrieved in every first day of the week
                          FIRST_VALUE(cont_max_ab) IGNORE NULLS OVER (PARTITION BY curr_year,curr_week ) AS contract_absence
                     FROM (SELECT main_days.check_day,
                                  main_days.curr_year,
                                  main_days.curr_week,
                                  ehd.tipo_dia,
                                  --for performance reasons only retrieve the rest days in contract in first day of each week
                                  CASE main_days.day_of_week
                                     WHEN 1 THEN
                                        NVL((SELECT ABSENCEPERWEEK FROM TABLE(PCK_CORE_EMPLOYEE_CONTRACT.GETCURRENTCONTRACT(main_days.check_day, I_FK_EMPLOYEE.CODIGO)) WHERE ROWNUM=1),-1)
                                  END cont_max_ab,
                                  --get total rest days in the employee/group cicle
                                  COUNT(CASE WHEN ehd.tipo_dia = 'F' THEN ehd.tipo_dia END) OVER(PARTITION BY main_days.curr_year,main_days.curr_week) tot_rest_days
                             FROM(SELECT all_days.check_day,
                                         (1 + TRUNC(all_days.check_day) - TRUNC(all_days.check_day, 'IW')) day_of_week,
                                         eh.codigo,
                                         eh.data_ini,
                                         eh.data_fim,
                                         eh.nro_semanas,
                                         eh.semana_inicia,
                                         --in each turn over year keep the same year value for all week
                                         DECODE (TO_CHAR(TRUNC(all_days.check_day,'iw')+6,'YYYY'),TO_CHAR(all_days.check_day,'YYYY'),TO_CHAR(all_days.check_day,'YYYY'),trunc(TO_CHAR(all_days.check_day,'YYYY')+1)) as CURR_YEAR,
                                         TO_CHAR(all_days.check_day,'IW') curr_week,
                                         --to check which cicle id to use
                                         ROW_NUMBER() OVER(PARTITION BY all_days.check_day ORDER BY(eh.data_fim - eh.data_ini), eh.fk_colaborador NULLS LAST) AS RN
                                    FROM ESC_HORARIO eh,
                                         --get_all_days
                                         (SELECT I_PERIOD_START_DATE + ROWNUM - 1 AS check_day
                                            FROM dual
                                         CONNECT BY ROWNUM <= I_PERIOD_END_DATE  - I_PERIOD_START_DATE + 1) all_days
                                   WHERE all_days.check_day BETWEEN eh.data_ini AND eh.data_fim
                                     AND (eh.FK_COLABORADOR = I_FK_EMPLOYEE.CODIGO OR eh.FK_GRUPO = I_FK_EMPLOYEE.FK_GRUPO )
                                     AND eh.ATIVO = 'S'
                                   ORDER BY all_days.check_day) main_days,
                                 --
                                 ESC_HORARIO_DETALHE ehd
                           WHERE main_days.codigo = ehd.fk_horario
                             AND ehd.nro_semana = PCK_CORE_UTIL.GET_SEMANAATUAL(main_days.check_day,main_days.data_ini,main_days.nro_semanas,main_days.semana_inicia)
                             AND ehd.dia_semana = main_days.day_of_week
                             AND rn = 1)) emp_cicle
            WHERE c.codigo = cs.fk_ciclo
              AND c.codigo = l_def_cicle
              AND cs.dia_semana = all_days.day_of_week
              AND cs.nro_semana = PCK_CORE_UTIL.GET_SEMANAATUAL(all_days.check_day,I_PERIOD_START_DATE,c.nro_semanas,1)
              AND all_days.check_day = emp_cicle.check_day(+)) all_q
    WHERE rd.fk_employee = I_FK_EMPLOYEE.CODIGO
      AND rd.state = C_STATE_RUNNING
      AND all_q.check_day BETWEEN rd.start_date AND rd.end_date
      AND SUBSTR (all_q.aply_type,1,1) IN ('S','F'); --Folga/Dia sem Trabalho

   RETURN TRUE;
EXCEPTION
    WHEN OTHERS THEN

     l_erro := Pck_Escala_Debug.Fnc_Monta_Mensagem('PACKAGE_ERROR',
                                                     SQLERRM,
                                                     l_name,
                                                     To_Char(SQLCODE));
     O_ERROR_MESSAGE := n_Mensagem.Get(O_ERROR_MESSAGE, l_erro, PCK_CORE_USER.GET_USER_LANGUAGE(USER));
     RETURN FALSE;
END SET_PREDICTED_REST_DAYS;
--
--
FUNCTION CALCULATE_REST_DAY_MAP_RANGE (O_ERROR_MESSAGE    IN OUT D_ARRAY_MENSAGEM_ERRO_TP,
                                       I_YEAR             IN     NUMBER,
                                       I_SWITCH_DAY_MONTH IN     DATE,
                                       I_ADD_NR_MONTHS    IN     NUMBER,
                                       O_BEGIN_DATE          OUT DATE,
                                       O_END_DATE            OUT DATE)
 RETURN BOOLEAN IS

  l_name CONSTANT VARCHAR2(100) := G_PACKAGE_NAME||'.CALCULATE_REST_DAY_MAP_RANGE';
  l_erro VARCHAR2(4000);
  --

BEGIN

   --align the begin date according to switch day/month from variable l_switch_day_month
   O_BEGIN_DATE := TO_DATE(TO_CHAR(I_SWITCH_DAY_MONTH + 1,'DDMM')||TO_CHAR(I_YEAR),'DDMMYYYY');

   --set end date according with calculated begin date and add months
   O_END_DATE   := ADD_MONTHS(ADD_MONTHS(O_BEGIN_DATE-1,12), I_ADD_NR_MONTHS);

   RETURN TRUE;
EXCEPTION
   WHEN OTHERS THEN
       l_erro := Pck_Escala_Debug.Fnc_Monta_Mensagem('PACKAGE_ERROR',
                                                     SQLERRM,
                                                     l_name,
                                                     To_Char(SQLCODE));
      O_ERROR_MESSAGE := n_Mensagem.Get(O_ERROR_MESSAGE, l_erro, PCK_CORE_USER.GET_USER_LANGUAGE(USER));
      RETURN FALSE;
END CALCULATE_REST_DAY_MAP_RANGE;
------------------------------------------------------------------------------
--Save
------------------------------------------------------------------------------
FUNCTION SAVE(I_FK_EMPLOYEE  IN  ESC_COLABORADOR.CODIGO%TYPE,
              I_FK_PROCESS   IN  ESC_PROCESSO.CODIGO%TYPE,
              I_CURRENT_YEAR IN  NUMBER   DEFAULT NULL,
              I_OLD_STATE    IN  VARCHAR2 DEFAULT NULL,
              I_NEW_STATE    IN  VARCHAR2 DEFAULT NULL) RETURN BOOLEAN IS

BEGIN

   UPDATE PREDICTED_REST_DAYS_MAP
      SET FK_PROCESS    = NVL(I_FK_PROCESS, FK_PROCESS),
          STATE         = I_NEW_STATE,
          STATE_DATE    = SYSDATE
    WHERE FK_EMPLOYEE   = I_FK_EMPLOYEE
      AND (I_CURRENT_YEAR IS NULL OR CURRENT_YEAR = I_CURRENT_YEAR)
      AND (I_OLD_STATE IS NULL OR STATE = I_OLD_STATE);

COMMIT;
   RETURN TRUE;
EXCEPTION
  WHEN OTHERS THEN
     RETURN FALSE;
END SAVE;
------------------------------------------------------------------------------
--Get last approved schedule date for process parameters
------------------------------------------------------------------------------
FUNCTION SET_RANGE_DATES(O_ERROR_MESSAGE  IN OUT D_ARRAY_MENSAGEM_ERRO_TP,
                         I_START_DATE     IN     DATE,
                         I_EMPLOYEE_DTL   IN     ESC_COLABORADOR%ROWTYPE,
                         I_FK_PROCESS     IN     ESC_PROCESSO.CODIGO%TYPE,
                         I_UPDATE_STATE   IN     VARCHAR2 DEFAULT 'N',
                         O_MAX_END_DATE      OUT DATE)
   RETURN BOOLEAN IS

   --Local variables
   l_name  VARCHAR2(50) := G_PACKAGE_NAME||'.SET_RANGE_DATES';
   l_erro  VARCHAR2(4000);

   --tmp variables
   l_tmp_year        NUMBER;
   l_exists          BOOLEAN := FALSE;
   l_tmp_start_date  DATE;
   l_tmp_end_date    DATE;
   --
   --
   CURSOR c_get_map (i_year NUMBER) IS
      SELECT start_date,
             end_date
        FROM predicted_rest_days_map
       WHERE fk_employee  = I_EMPLOYEE_DTL.CODIGO
         AND current_year = i_year;

BEGIN

   --------------------------------------------------------------
   --Check if exists record in past current year for current date
   --------------------------------------------------------------
   l_tmp_year := to_number(TO_CHAR(I_START_DATE,'YYYY'))-1;


   ---get range dates in header
   OPEN c_get_map (l_tmp_year);
   FETCH c_get_map INTO l_tmp_start_date,l_tmp_end_date;
   IF c_get_map%FOUND THEN
     l_exists := TRUE;
   END IF;
   CLOSE c_get_map;


   IF l_exists THEN
   --
      IF I_START_DATE BETWEEN l_tmp_start_date AND l_tmp_end_date AND I_UPDATE_STATE = 'Y' THEN
         --
         IF NOT SAVE(I_FK_EMPLOYEE  => I_EMPLOYEE_DTL.CODIGO,
                     I_FK_PROCESS   => I_FK_PROCESS,
                     I_CURRENT_YEAR => l_tmp_year,
                     I_NEW_STATE    => C_STATE_INITIAL) THEN
            RETURN FALSE;
         END IF;
         --
      END IF;
   ELSE
      --
      IF NOT CALCULATE_REST_DAY_MAP_RANGE (O_ERROR_MESSAGE,
                                           l_tmp_year,
                                           G_SWITH_DAY_MONTH,
                                           G_ADD_NR_MONTHS,
                                           l_tmp_start_date,
                                           l_tmp_end_date) THEN
         RETURN FALSE;
      END IF;
      --
      IF I_START_DATE BETWEEN l_tmp_start_date AND l_tmp_end_date THEN

         INSERT INTO predicted_rest_days_map (FK_PROCESS,
                                              FK_EMPLOYEE,
                                              CURRENT_YEAR,
                                              START_DATE,
                                              END_DATE,STATE)
                                      VALUES (I_FK_PROCESS,
                                              I_EMPLOYEE_DTL.CODIGO,
                                              l_tmp_year,
                                              l_tmp_start_date,
                                              l_tmp_end_date,
                                              C_STATE_INITIAL);
         COMMIT;
      END IF;
   END IF;


   --------------------------------------------------------------
   --Check if exists record in current year for current date
   --------------------------------------------------------------
   l_tmp_year := l_tmp_year + 1;
   l_exists := FALSE;


   ---get range dates in header
   OPEN c_get_map (l_tmp_year);
   FETCH c_get_map INTO l_tmp_start_date,l_tmp_end_date;
   IF c_get_map%FOUND THEN
     l_exists := TRUE;
   END IF;
   CLOSE c_get_map;


   IF NOT l_exists  THEN

      --in case of parameter switch_day_month update between years
      IF TO_CHAR(l_tmp_start_date - 1,'DDMM') <>  TO_CHAR(G_SWITH_DAY_MONTH,'DDMM') THEN

         IF NOT CALCULATE_REST_DAY_MAP_RANGE (O_ERROR_MESSAGE,
                                              l_tmp_year,
                                              G_SWITH_DAY_MONTH,
                                              G_ADD_NR_MONTHS,
                                              l_tmp_start_date,
                                              l_tmp_end_date) THEN
            RETURN FALSE;
         END IF;
      ELSE
         l_tmp_start_date :=  ADD_MONTHS(l_tmp_start_date,12);
         l_tmp_end_date   :=  ADD_MONTHS(ADD_MONTHS(l_tmp_start_date-1,12), G_ADD_NR_MONTHS);
      END IF;

      --
      IF I_START_DATE BETWEEN l_tmp_start_date AND l_tmp_end_date THEN

         INSERT INTO predicted_rest_days_map (FK_PROCESS,
                                              FK_EMPLOYEE,
                                              CURRENT_YEAR,
                                              START_DATE,
                                              END_DATE,STATE)
                                      VALUES (I_FK_PROCESS,
                                              I_EMPLOYEE_DTL.CODIGO,
                                              l_tmp_year,
                                              l_tmp_start_date,
                                              l_tmp_end_date,
                                              C_STATE_INITIAL);
         COMMIT;
      END IF;
   ELSE
      IF I_START_DATE BETWEEN l_tmp_start_date AND l_tmp_end_date AND I_UPDATE_STATE = 'Y' THEN
         --
         IF NOT SAVE(I_FK_EMPLOYEE  => I_EMPLOYEE_DTL.CODIGO,
                     I_FK_PROCESS   => I_FK_PROCESS,
                     I_CURRENT_YEAR => l_tmp_year,
                     I_NEW_STATE    => C_STATE_INITIAL) THEN
            RETURN FALSE;
         END IF;
         --
      END IF;
   END IF;
   --define eow day for last day in range
   O_MAX_END_DATE := l_tmp_end_date;


   RETURN TRUE;
EXCEPTION
  WHEN OTHERS THEN
     l_erro := Pck_Escala_Debug.Fnc_Monta_Mensagem('PACKAGE_ERROR',
                                                   SQLERRM,
                                                   l_name,
                                                   To_Char(SQLCODE));
      O_ERROR_MESSAGE := n_Mensagem.Get(O_ERROR_MESSAGE, l_erro, PCK_CORE_USER.GET_USER_LANGUAGE(USER));
      RETURN FALSE;
END SET_RANGE_DATES;
------------------------------------------------------------------------------
--Process predicted rest days for selected employee
------------------------------------------------------------------------------
FUNCTION PROCESS_EMPLOYEE(O_ERROR_MESSAGE    IN OUT D_ARRAY_MENSAGEM_ERRO_TP,
                          O_EXISTS_DEF_CICLE    OUT NUMBER,
                          O_WAS_RUNNING         OUT NUMBER,
                          I_FK_UNIT          IN     ESC_UNIDADE.CODIGO%TYPE,
                          I_FK_SECTION       IN     ESC_SECAO.CODIGO%TYPE,
                          I_EMPLOYEE_DTL     IN     ESC_COLABORADOR%ROWTYPE,
                          I_FK_PROCESS       IN     ESC_PROCESSO.CODIGO%TYPE,
                          I_START_DATE       IN     DATE,
                          I_END_DATE         IN     DATE,
                          I_CHANGE_TYPE      IN     VARCHAR2,
                          I_UPDATE_STATE     IN     VARCHAR2 DEFAULT 'N',
                          I_SCHEDULE_PROCESS IN     VARCHAR2 DEFAULT 'N')
   RETURN BOOLEAN IS

   --Local variables
   l_name  VARCHAR2(50) := G_PACKAGE_NAME||'.PROCESS_EMPLOYEE';
   l_erro  VARCHAR2(4000);
   l_auto_aprove    VARCHAR2(10);

   --to stablish begin date as first day of week and end date as end of week day
   l_trunc_start_date DATE;
   l_trunc_end_date   DATE;


   CURSOR c_exits_rows_to_process (i_fk_employee ESC_COLABORADOR.CODIGO%TYPE,i_fk_process ESC_PROCESSO.CODIGO%TYPE) IS
      SELECT 1
        FROM predicted_rest_days_map
       WHERE fk_employee = i_fk_employee
         AND fk_process  = i_fk_process
         AND state = C_STATE_RUNNING;

   CURSOR c_exists_default (i_fk_employee ESC_COLABORADOR.CODIGO%TYPE,i_fk_process ESC_PROCESSO.CODIGO%TYPE,i_start_date DATE, i_end_date DATE) IS
      SELECT 1
        FROM predicted_rest_days_map dm,
             predicted_rest_days_map_dtl dtl
       WHERE dm.fk_employee = i_fk_employee
         AND dm.fk_process  = i_fk_process
         AND dm.state = C_STATE_RUNNING
         AND dm.id    = dtl.fk_pred_rest_days_map
         AND dtl.default_cicle = 'Y'
         AND dtl.rest_start_date BETWEEN i_start_date AND i_end_date;
BEGIN

   ---Set range dates and header records to process
   IF NOT  SET_RANGE_DATES(O_ERROR_MESSAGE  => O_ERROR_MESSAGE,
                           I_START_DATE     => I_START_DATE,
                           I_EMPLOYEE_DTL   => I_EMPLOYEE_DTL,
                           I_FK_PROCESS     => I_FK_PROCESS,
                           I_UPDATE_STATE   => I_UPDATE_STATE,
                           O_MAX_END_DATE   => l_trunc_end_date) THEN
      IF NOT SAVE(I_FK_EMPLOYEE  => I_EMPLOYEE_DTL.CODIGO,
                  I_FK_PROCESS   => I_FK_PROCESS,
                  I_OLD_STATE    => C_STATE_INITIAL,
                  I_NEW_STATE    => C_STATE_ERROR) THEN
         RETURN FALSE;
      END IF;
      RETURN FALSE;
   END IF;


   ---Update header record(s) ready to (R)unning
   IF NOT SAVE(I_FK_EMPLOYEE  => I_EMPLOYEE_DTL.CODIGO,
               I_FK_PROCESS   => I_FK_PROCESS,
               I_OLD_STATE    => C_STATE_INITIAL,
               I_NEW_STATE    => C_STATE_RUNNING) THEN
      RETURN FALSE;
   END IF;


   --Only for night job purpose, to check if the employee was actually processed.
   IF I_UPDATE_STATE = 'N' AND I_SCHEDULE_PROCESS = 'N' THEN
      OPEN c_exits_rows_to_process(I_EMPLOYEE_DTL.CODIGO,I_FK_PROCESS);
     FETCH c_exits_rows_to_process INTO O_WAS_RUNNING;
     CLOSE c_exits_rows_to_process;
   END IF;

   --
   l_trunc_start_date := TRUNC(I_START_DATE,'IW');
   --
   IF I_START_DATE = I_END_DATE THEN
      --Ends limit is the end_date from open current year
      l_trunc_end_date := TRUNC(l_trunc_end_date,'IW') + 6;
   ELSE
      ---Ends limit is the defined in the screen by user
      l_trunc_end_date := TRUNC(I_END_DATE,'IW') + 6;
   END IF;

   ---Remove existent records in detail for range dates
   IF I_UPDATE_STATE = 'Y' THEN

      DELETE predicted_rest_days_map_dtl dtl
       WHERE dtl.rest_start_date BETWEEN l_trunc_start_date AND l_trunc_end_date
         AND EXISTS (SELECT 1
                       FROM predicted_rest_days_map dm
                      WHERE dm.fk_employee = I_EMPLOYEE_DTL.CODIGO
                        AND dm.state = C_STATE_RUNNING
                        AND dm.id = dtl.fk_pred_rest_days_map);
   END IF;

   --Do the explosion of the employee/group cicle or default cicle throught the records in running
   IF NOT SET_PREDICTED_REST_DAYS(O_ERROR_MESSAGE,
                                  I_FK_SECTION,
                                  I_EMPLOYEE_DTL,
                                  l_trunc_start_date,
                                  l_trunc_end_date,
                                  I_CHANGE_TYPE) THEN

      ROLLBACK;
      IF NOT SAVE(I_FK_EMPLOYEE  => I_EMPLOYEE_DTL.CODIGO,
                  I_FK_PROCESS   => I_FK_PROCESS,
                  I_OLD_STATE    => C_STATE_RUNNING,
                  I_NEW_STATE    => C_STATE_ERROR) THEN
         RETURN FALSE;
      END IF;
      --
      RETURN FALSE;
   END IF;


   --Set Schedule days
   IF I_SCHEDULE_PROCESS = 'N' THEN
      IF NOT SET_APPROVE_SCHEDULE_DAYS(O_ERROR_MESSAGE,
                                       I_EMPLOYEE_DTL.CODIGO,
                                       l_trunc_start_date,
                                       l_trunc_end_date,
                                       I_CHANGE_TYPE) THEN

         ROLLBACK;
         ---Update header record(s) to (E)rror
         IF NOT SAVE(I_FK_EMPLOYEE  => I_EMPLOYEE_DTL.CODIGO,
                     I_FK_PROCESS   => I_FK_PROCESS,
                     I_OLD_STATE    => C_STATE_RUNNING,
                     I_NEW_STATE    => C_STATE_ERROR) THEN
            RETURN FALSE;
         END IF;
         --
         RETURN FALSE;
      END IF;
   END IF;

   --Set Close Days
   IF NOT SET_HOLIDAY_CLOSE_DAYS(O_ERROR_MESSAGE,
                                 I_FK_UNIT,
                                 I_FK_SECTION,
                                 I_EMPLOYEE_DTL.CODIGO,
                                 l_trunc_start_date,
                                 l_trunc_end_date,
                                 I_CHANGE_TYPE) THEN

      ROLLBACK;
      ---Update header record(s) to (E)rror
      IF NOT SAVE(I_FK_EMPLOYEE  => I_EMPLOYEE_DTL.CODIGO,
                  I_FK_PROCESS   => I_FK_PROCESS,
                  I_OLD_STATE    => C_STATE_RUNNING,
                  I_NEW_STATE    => C_STATE_ERROR) THEN
         RETURN FALSE;
      END IF;
      RETURN FALSE;
   END IF;

   --Get parameter to check if auto aprove is ON
   IF NOT GET_AUTO_APROVE_IND(O_ERROR_MESSAGE,
                              l_auto_aprove,
                              PCK_CORE_PARAMETER.G_SCOPE_STORE,
                              I_FK_UNIT) THEN
      ROLLBACK;
      IF NOT SAVE(I_FK_EMPLOYEE  => I_EMPLOYEE_DTL.CODIGO,
                  I_FK_PROCESS   => I_FK_PROCESS,
                  I_OLD_STATE    => C_STATE_RUNNING,
                  I_NEW_STATE    => C_STATE_ERROR) THEN
         RETURN FALSE;
      END IF;
      RETURN FALSE;
   END IF;
   --
   ---To check if was used default cicle to generate employee rest days
   IF I_SCHEDULE_PROCESS = 'N' THEN
      OPEN c_exists_default(I_EMPLOYEE_DTL.CODIGO,I_FK_PROCESS,l_trunc_start_date,l_trunc_end_date);
      FETCH c_exists_default INTO O_EXISTS_DEF_CICLE;
      CLOSE c_exists_default;
   END IF;
   --
   IF NOT SAVE(I_FK_EMPLOYEE  => I_EMPLOYEE_DTL.CODIGO,
               I_FK_PROCESS   => I_FK_PROCESS,
               I_OLD_STATE    => C_STATE_RUNNING,
               I_NEW_STATE    => CASE l_auto_aprove WHEN 'Y' THEN C_STATE_APPROVED ELSE C_STATE_WAIT_APROVE END) THEN
      ROLLBACK;
      RETURN FALSE;
   END IF;
   --
   --Set absence Days
   IF NOT N_AUSENCIA.set_contingentes(O_ERROR_MESSAGE,

                                     l_trunc_start_date,
                                     l_trunc_end_date,
                                     I_EMPLOYEE_DTL.CODIGO,
                                     I_SCHEDULE_PROCESS) THEN

      ROLLBACK;
      IF NOT SAVE(I_FK_EMPLOYEE  => I_EMPLOYEE_DTL.CODIGO,
                  I_FK_PROCESS   => I_FK_PROCESS,
                  I_OLD_STATE    => C_STATE_RUNNING,
                  I_NEW_STATE    => C_STATE_ERROR) THEN

         RETURN FALSE;
      END IF;
      RETURN FALSE;
   END IF;
   COMMIT;
   --
   RETURN TRUE;
EXCEPTION
  WHEN OTHERS THEN
     ROLLBACK;
     --
     IF NOT SAVE(I_FK_EMPLOYEE  => I_EMPLOYEE_DTL.CODIGO,
                 I_FK_PROCESS   => I_FK_PROCESS,
                 I_OLD_STATE    => C_STATE_RUNNING,
                 I_NEW_STATE    => C_STATE_ERROR) THEN
         RETURN FALSE;
     END IF;

     l_erro := Pck_Escala_Debug.Fnc_Monta_Mensagem('PACKAGE_ERROR',
                                                   SQLERRM,
                                                   l_name,
                                                   To_Char(SQLCODE));
     O_ERROR_MESSAGE := n_Mensagem.Get(O_ERROR_MESSAGE, l_erro, PCK_CORE_USER.GET_USER_LANGUAGE(USER));

    RETURN FALSE;
END PROCESS_EMPLOYEE;
------------------------------------------------------------------------------
--Process rest days map
------------------------------------------------------------------------------
FUNCTION PROCESS(O_ERROR_MESSAGE IN OUT D_ARRAY_MENSAGEM_ERRO_TP,
                 I_PROCESS       IN     ESC_PROCESSO%ROWTYPE,
                 I_FK_UNIT       IN     ESC_UNIDADE.CODIGO%TYPE,
                 I_change_type   IN     VARCHAR2,
                 I_update_ind    IN     VARCHAR2)
   RETURN BOOLEAN IS

   --Local variables
   L_NAME             VARCHAR2(50) := G_PACKAGE_NAME||'.PROCESS';
   L_ERRO             VARCHAR2(4000);
   L_EMPLOYEE_DTL     ESC_COLABORADOR%ROWTYPE;
   L_NR_OF_EMPLOYEES  NUMBER := 0;
   --
   l_begin_date       DATE;
   l_end_date         DATE;

   --Cursor to get employee details
   CURSOR C_EMPLOYEE (I_FK_EMPLOYEE ESC_COLABORADOR.CODIGO%TYPE, P_DATA DATE) IS
      SELECT C.*
        FROM ESC_COLABORADOR C
        JOIN TABLE(PCK_CORE_EMPLOYEE_CONTRACT.GETCURRENTCONTRACT(P_DATA, C.CODIGO)) CC
          ON CC.EMPLOYEEID = C.CODIGO --Employee should have an active contract
         AND (C.DATA_DEMISSAO IS NULL OR C.DATA_DEMISSAO > TRUNC(P_DATA))
       WHERE C.CODIGO = I_FK_EMPLOYEE;

   --Cursor to get all employees from a given group and sub-groups
   CURSOR C_GROUP_EMPLOYEE (I_FK_GROUP ESC_GRUPO.CODIGO%TYPE, P_DATA DATE) IS
      SELECT G.NOME GRP_NAME, C.*
        FROM ESC_COLABORADOR C
        JOIN TABLE(PCK_CORE_EMPLOYEE_CONTRACT.GETCURRENTCONTRACT(P_DATA, C.CODIGO)) CC
          ON CC.EMPLOYEEID = C.CODIGO --Employee should have an active contract
        JOIN ESC_GRUPO G ON G.CODIGO = C.FK_GRUPO
       WHERE C.FK_GRUPO IN (SELECT GR.CODIGO
                              FROM ESC_GRUPO GR
                             START WITH GR.CODIGO = I_FK_GROUP
                           CONNECT BY PRIOR GR.CODIGO = GR.FK_GRUPO
                           )
         AND (C.DATA_DEMISSAO IS NULL OR C.DATA_DEMISSAO > TRUNC(P_DATA));

    --Cursor to get all employees from a given section
    CURSOR C_SECTION_EMPLOYEE (I_FK_SECTION ESC_SECAO.CODIGO%TYPE, P_DATA DATE) IS
       SELECT S.NOME SEC_NAME, C.*
         FROM ESC_COLABORADOR C
         JOIN TABLE(PCK_CORE_EMPLOYEE_CONTRACT.GETCURRENTCONTRACT(P_DATA, C.CODIGO)) CC
           ON CC.EMPLOYEEID = C.CODIGO --Employee should have an active contract
         JOIN ESC_GRUPO GR ON GR.CODIGO = C.FK_GRUPO
         JOIN ESC_SECAO S ON S.CODIGO   = GR.FK_SECAO
        WHERE S.CODIGO        = I_FK_SECTION
          AND (C.DATA_DEMISSAO IS NULL OR C.DATA_DEMISSAO > TRUNC(P_DATA));

    --Cursor to get all employees from a given workstation type
    CURSOR C_WORKSTATION_TP_EMPLOYEE (I_FK_WORKSTATION_TP ESC_TIPO_POSTO.CODIGO%TYPE, P_DATA DATE) IS
       SELECT TP.NOME WORKTP_NAME, C.*
         FROM ESC_COLABORADOR C
         JOIN TABLE(PCK_CORE_EMPLOYEE_CONTRACT.GETCURRENTCONTRACT(P_DATA, C.CODIGO)) CC
           ON CC.EMPLOYEEID = C.CODIGO --Employee should have an active contract
         JOIN ESC_GRUPO GR ON GR.CODIGO = C.FK_GRUPO
         JOIN ESC_SECAO S ON S.CODIGO = GR.FK_SECAO
         JOIN ESC_TIPO_POSTO TP ON TP.FK_SECAO        = S.CODIGO
        WHERE TP.CODIGO       = I_FK_WORKSTATION_TP
          AND (C.DATA_DEMISSAO IS NULL OR C.DATA_DEMISSAO    > TRUNC(P_DATA));

    --Cursor rowtypes
    R_EMPLOYEE                C_EMPLOYEE%ROWTYPE;
    R_GROUP_EMPLOYEE          C_GROUP_EMPLOYEE%ROWTYPE;
    R_SECTION_EMPLOYEE        C_SECTION_EMPLOYEE%ROWTYPE;
    R_WORKSTATION_TP_EMPLOYEE C_WORKSTATION_TP_EMPLOYEE%ROWTYPE;

    --Only for notifications purpose
    l_exists_default_cicle   NUMBER(1);
    l_employee_was_processed NUMBER(1);

  BEGIN

     --Begin function debug
     PCK_ESCALA_DEBUG.PRC_INS_DEBUG(PCK_ESCALA_DEBUG.G_FUNCTION_DBG,
                                    L_NAME,
                                    PCK_ESCALA_DEBUG.G_BEGIN_DBG,
                                    I_PROCESS.CODIGO,
                                    I_PROCESS.FK_SECAO,
                                    I_PROCESS.DATA_INI,
                                    I_PROCESS.DATA_FIM);

     --------------------------
     --Save range dates to use
     --------------------------
     l_begin_date := I_PROCESS.DATA_INI;
     l_end_Date   := I_PROCESS.DATA_FIM;


     ---------------------------------------------------------------------
     --Get day and month that will provoke system to switch to next year
     ---------------------------------------------------------------------
     IF NOT GET_SWITCH_YEAR (o_error_message,
                             G_SWITH_DAY_MONTH,
                             PCK_CORE_PARAMETER.G_SCOPE_STORE, --store
                             I_FK_UNIT) THEN
        RETURN FALSE;
     END IF;

     --------------------------------------------------------
     --Get number of months to define the end period date
     --------------------------------------------------------
     IF NOT GET_REST_DAYS_NR_MONTHS(o_error_message,
                                    G_ADD_NR_MONTHS,
                                    PCK_CORE_PARAMETER.G_SCOPE_STORE, --store
                                    I_FK_UNIT) THEN
        RETURN FALSE;
     END IF;

    -------------------------------------------
    --Process for a specific employee
    -------------------------------------------
    IF I_PROCESS.FK_COLABORADOR IS NOT NULL THEN

       OPEN C_EMPLOYEE(I_PROCESS.FK_COLABORADOR, SYSDATE);
      FETCH C_EMPLOYEE INTO R_EMPLOYEE;
      CLOSE C_EMPLOYEE;

      L_EMPLOYEE_DTL.CODIGO   := I_PROCESS.FK_COLABORADOR;
      L_EMPLOYEE_DTL.FK_GRUPO := R_EMPLOYEE.FK_GRUPO;
      l_exists_default_cicle  := NULL;
      l_employee_was_processed := NULL;

      IF NOT PROCESS_EMPLOYEE(O_ERROR_MESSAGE    => O_ERROR_MESSAGE,
                              O_EXISTS_DEF_CICLE => l_exists_default_cicle,
                              O_WAS_RUNNING      => l_employee_was_processed,
                              I_FK_UNIT          => I_FK_UNIT,
                              I_FK_SECTION       => G_NOTIF_DEST_CODE,
                              I_EMPLOYEE_DTL     => L_EMPLOYEE_DTL,
                              I_FK_PROCESS       => I_PROCESS.CODIGO,
                              I_START_DATE       => l_begin_date,
                              I_END_DATE         => l_end_date,
                              I_CHANGE_TYPE      => I_change_type,
                              I_UPDATE_STATE     => I_update_ind) THEN

         PCK_ESCALA_DEBUG.PRC_INS_DEBUG(PCK_ESCALA_DEBUG.G_FUNCTION_DBG,
                                     L_NAME,
                                     PCK_ESCALA_DEBUG.G_END_DBG,
                                     PCK_ESCALA_DEBUG.G_ERROR_DBG,
                                     'Error in process',
                                     'PROCESS='||I_PROCESS.CODIGO,
                                     'EMPLOYEE='||L_EMPLOYEE_DTL.CODIGO,
                                     'MSG='||Pck_Escala_Debug.get_message_str(O_ERROR_MESSAGE));

         IF NOT n_aviso.create_error_notification (O_ERROR_MESSAGE => O_ERROR_MESSAGE,
                                                   I_processo      => GV_PROCESS_NAME,
                                                   I_level         => GV_LEVEL,
                                                   I_alias         => 'MPF_IMPOSSIVEL_GERAR',
                                                   I_subtipo       => GV_SUBTIPO,
                                                   I_para          => G_NOTIF_DEST_CODE,
                                                   I_param1        => R_EMPLOYEE.NOME,
                                                   I_fk_processo   => I_PROCESS.CODIGO) THEN
            RETURN FALSE;
         END IF;

         RETURN FALSE;
      END IF;
      --
      IF I_update_ind = 'Y' OR (I_update_ind='N' AND l_employee_was_processed = 1) THEN
         IF NOT n_aviso.create_info_notification (O_ERROR_MESSAGE => O_ERROR_MESSAGE,
                                                  I_processo      => GV_PROCESS_NAME,
                                                  I_level         => GV_LEVEL,
                                                  I_alias         => CASE l_exists_default_cicle WHEN 1 THEN 'MPF_USING_DEFAULT' ELSE 'MPF_PROCESSA_COLABORADOR' END,
                                                  I_subtipo       => GV_SUBTIPO,
                                                  I_para          => G_NOTIF_DEST_CODE,
                                                  I_param1        => NVL(R_EMPLOYEE.NOME, ' '),
                                                  I_fk_processo   => I_PROCESS.CODIGO) THEN
            RETURN FALSE;
         END IF;
      END IF;

   ------------------------------------
   --Process for a specific group
   ------------------------------------
   ELSIF I_PROCESS.FK_GRUPO IS NOT NULL THEN

      OPEN C_GROUP_EMPLOYEE(I_PROCESS.FK_GRUPO, SYSDATE);
      LOOP
        FETCH C_GROUP_EMPLOYEE INTO R_GROUP_EMPLOYEE;
        EXIT WHEN C_GROUP_EMPLOYEE%NOTFOUND;

        L_EMPLOYEE_DTL.CODIGO    := R_GROUP_EMPLOYEE.CODIGO;
        L_EMPLOYEE_DTL.FK_GRUPO  := R_GROUP_EMPLOYEE.FK_GRUPO;
        l_exists_default_cicle   := NULL;
        l_employee_was_processed := NULL;

        IF NOT PROCESS_EMPLOYEE(O_ERROR_MESSAGE    => O_ERROR_MESSAGE,
                                O_EXISTS_DEF_CICLE => l_exists_default_cicle,
                                O_WAS_RUNNING      => l_employee_was_processed,
                                I_FK_UNIT          => I_FK_UNIT,
                                I_FK_SECTION       => G_NOTIF_DEST_CODE,
                                I_EMPLOYEE_DTL     => L_EMPLOYEE_DTL,
                                I_FK_PROCESS       => I_PROCESS.CODIGO,
                                I_START_DATE       => l_begin_date,
                                I_END_DATE         => l_end_date,
                                I_CHANGE_TYPE      => I_change_type,
                                I_UPDATE_STATE     => I_update_ind) THEN

           PCK_ESCALA_DEBUG.PRC_INS_DEBUG(PCK_ESCALA_DEBUG.G_FUNCTION_DBG,
                                          L_NAME,
                                          PCK_ESCALA_DEBUG.G_END_DBG,
                                          PCK_ESCALA_DEBUG.G_ERROR_DBG,
                                          'Error in process',
                                          'PROCESS='||I_PROCESS.CODIGO,
                                          'EMPLOYEE='||L_EMPLOYEE_DTL.CODIGO,
                                          'MSG='||Pck_Escala_Debug.get_message_str(O_ERROR_MESSAGE));

           IF NOT n_aviso.create_error_notification (O_ERROR_MESSAGE => O_ERROR_MESSAGE,
                                                     I_processo      => GV_PROCESS_NAME,
                                                     I_level         => GV_LEVEL,
                                                     I_alias         => 'MPF_IMPOSSIVEL_GERAR',
                                                     I_subtipo       => GV_SUBTIPO,
                                                     I_para          => G_NOTIF_DEST_CODE,
                                                     I_param1        => R_GROUP_EMPLOYEE.NOME,
                                                     I_fk_processo   => I_PROCESS.CODIGO) THEN
              RETURN FALSE;
           END IF;
           --
           RETURN FALSE;
        END IF;
        --
        IF I_update_ind = 'Y' OR (I_update_ind='N' AND l_employee_was_processed = 1) THEN
           IF NOT n_aviso.create_info_notification (O_ERROR_MESSAGE => O_ERROR_MESSAGE,
                                                    I_processo      => GV_PROCESS_NAME,
                                                    I_level         => GV_LEVEL,
                                                    I_alias         => CASE l_exists_default_cicle WHEN 1 THEN 'MPF_USING_DEFAULT' ELSE 'MPF_PROCESSA_COLABORADOR' END,
                                                    I_subtipo       => GV_SUBTIPO,
                                                    I_para          => G_NOTIF_DEST_CODE,
                                                    I_param1        => R_GROUP_EMPLOYEE.NOME,
                                                    I_fk_processo   => I_PROCESS.CODIGO) THEN
              RETURN FALSE;
           END IF;
           --
           L_NR_OF_EMPLOYEES := L_NR_OF_EMPLOYEES + 1;
        END IF;
        --
      END LOOP;
      CLOSE C_GROUP_EMPLOYEE;
      --
      IF NOT n_aviso.create_info_notification (O_ERROR_MESSAGE => O_ERROR_MESSAGE,
                                               I_processo      => GV_PROCESS_NAME,
                                               I_level         => GV_LEVEL,
                                               I_alias         => 'MPF_PROCESSA_GRUPO',
                                               I_subtipo       => GV_SUBTIPO,
                                               I_para          => G_NOTIF_DEST_CODE,
                                               I_param1        => NVL(R_GROUP_EMPLOYEE.GRP_NAME, ' '),
                                               I_param2        => L_NR_OF_EMPLOYEES,
                                               I_fk_processo   => I_PROCESS.CODIGO) THEN
         RETURN FALSE;
      END IF;
   -------------------------------------------------
   --Process for a specific workstation type
   -------------------------------------------------
   ELSIF I_PROCESS.FK_TIPO_POSTO IS NOT NULL THEN
      OPEN C_WORKSTATION_TP_EMPLOYEE(I_PROCESS.FK_TIPO_POSTO, SYSDATE);
      LOOP
        FETCH C_WORKSTATION_TP_EMPLOYEE INTO R_WORKSTATION_TP_EMPLOYEE;
        EXIT WHEN C_WORKSTATION_TP_EMPLOYEE%NOTFOUND;

        L_EMPLOYEE_DTL.CODIGO    := R_WORKSTATION_TP_EMPLOYEE.CODIGO;
        L_EMPLOYEE_DTL.FK_GRUPO  := R_WORKSTATION_TP_EMPLOYEE.FK_GRUPO;
        l_exists_default_cicle   := NULL;
        l_employee_was_processed := NULL;

        IF NOT PROCESS_EMPLOYEE(O_ERROR_MESSAGE    => O_ERROR_MESSAGE,
                                O_EXISTS_DEF_CICLE => l_exists_default_cicle,
                                O_WAS_RUNNING      => l_employee_was_processed,
                                I_FK_UNIT          => I_FK_UNIT,
                                I_FK_SECTION       => G_NOTIF_DEST_CODE,
                                I_EMPLOYEE_DTL     => L_EMPLOYEE_DTL,
                                I_FK_PROCESS       => I_PROCESS.CODIGO,
                                I_START_DATE       => l_begin_date,
                                I_END_DATE         => l_end_date,
                                I_CHANGE_TYPE      => I_change_type,
                                I_UPDATE_STATE     => I_update_ind) THEN

           --
           PCK_ESCALA_DEBUG.PRC_INS_DEBUG(PCK_ESCALA_DEBUG.G_FUNCTION_DBG,
                                          L_NAME,
                                          PCK_ESCALA_DEBUG.G_END_DBG,
                                          PCK_ESCALA_DEBUG.G_ERROR_DBG,
                                          'Error in process',
                                          'PROCESS='||I_PROCESS.CODIGO,
                                          'EMPLOYEE='||L_EMPLOYEE_DTL.CODIGO,
                                          'MSG='||Pck_Escala_Debug.get_message_str(O_ERROR_MESSAGE));

           IF NOT n_aviso.create_error_notification (O_ERROR_MESSAGE => O_ERROR_MESSAGE,
                                                    I_processo      => GV_PROCESS_NAME,
                                                    I_level         => GV_LEVEL,
                                                    I_alias         => 'MPF_IMPOSSIVEL_GERAR',
                                                    I_subtipo       => GV_SUBTIPO,
                                                    I_para          => G_NOTIF_DEST_CODE,
                                                    I_param1        => R_WORKSTATION_TP_EMPLOYEE.NOME,
                                                    I_fk_processo   => I_PROCESS.CODIGO) THEN
              RETURN FALSE;
           END IF;
           --
           RETURN FALSE;
        END IF;
        --
        IF I_update_ind = 'Y' OR (I_update_ind='N' AND l_employee_was_processed = 1) THEN
           IF NOT n_aviso.create_info_notification (O_ERROR_MESSAGE => O_ERROR_MESSAGE,
                                                    I_processo      => GV_PROCESS_NAME,
                                                    I_level         => GV_LEVEL,
                                                    I_alias         => CASE l_exists_default_cicle WHEN 1 THEN 'MPF_USING_DEFAULT' ELSE 'MPF_PROCESSA_COLABORADOR' END,
                                                    I_subtipo       => GV_SUBTIPO,
                                                    I_para          => G_NOTIF_DEST_CODE,
                                                    I_param1        => R_WORKSTATION_TP_EMPLOYEE.NOME,
                                                    I_fk_processo   => I_PROCESS.CODIGO) THEN
              RETURN FALSE;
           END IF;
           --
           L_NR_OF_EMPLOYEES := L_NR_OF_EMPLOYEES + 1;
        END IF;
        --
      END LOOP;
      CLOSE C_WORKSTATION_TP_EMPLOYEE;
      --
      IF NOT n_aviso.create_info_notification (O_ERROR_MESSAGE => O_ERROR_MESSAGE,
                                               I_processo      => GV_PROCESS_NAME,
                                               I_level         => GV_LEVEL,
                                               I_alias         => 'MPF_PROCESSA_TIPO_POSTO',
                                               I_subtipo       => GV_SUBTIPO,
                                               I_para          => G_NOTIF_DEST_CODE,
                                               I_param1        => NVL(R_WORKSTATION_TP_EMPLOYEE.WORKTP_NAME, ' '),
                                               I_param2        => L_NR_OF_EMPLOYEES,
                                               I_fk_processo   => I_PROCESS.CODIGO) THEN
          RETURN FALSE;
      END IF;
   --------------------------------------
   --Process for a specific section
   --------------------------------------
   ELSIF I_PROCESS.FK_SECAO IS NOT NULL THEN
      OPEN C_SECTION_EMPLOYEE(I_PROCESS.FK_SECAO, SYSDATE);
      LOOP
        FETCH C_SECTION_EMPLOYEE INTO R_SECTION_EMPLOYEE;
        EXIT WHEN C_SECTION_EMPLOYEE%NOTFOUND;

        L_EMPLOYEE_DTL.CODIGO    := R_SECTION_EMPLOYEE.CODIGO;
        L_EMPLOYEE_DTL.FK_GRUPO  := R_SECTION_EMPLOYEE.FK_GRUPO;
        l_exists_default_cicle   := NULL;
        l_employee_was_processed := NULL;


        IF NOT PROCESS_EMPLOYEE(O_ERROR_MESSAGE    => O_ERROR_MESSAGE,
                                O_EXISTS_DEF_CICLE => l_exists_default_cicle,
                                O_WAS_RUNNING      => l_employee_was_processed,
                                I_FK_UNIT          => I_FK_UNIT,
                                I_FK_SECTION       => G_NOTIF_DEST_CODE,
                                I_EMPLOYEE_DTL     => L_EMPLOYEE_DTL,
                                I_FK_PROCESS       => I_PROCESS.CODIGO,
                                I_START_DATE       => l_begin_date,
                                I_END_DATE         => l_end_date,
                                I_CHANGE_TYPE      => I_change_type,
                                I_UPDATE_STATE     => I_update_ind) THEN
           --
           PCK_ESCALA_DEBUG.PRC_INS_DEBUG(PCK_ESCALA_DEBUG.G_FUNCTION_DBG,
                                          L_NAME,
                                          PCK_ESCALA_DEBUG.G_END_DBG,
                                          PCK_ESCALA_DEBUG.G_ERROR_DBG,
                                          'Error in process',
                                          'PROCESS='||I_PROCESS.CODIGO,
                                          'EMPLOYEE='||L_EMPLOYEE_DTL.CODIGO,
                                          'MSG='||Pck_Escala_Debug.get_message_str(O_ERROR_MESSAGE));

           IF NOT n_aviso.create_error_notification (O_ERROR_MESSAGE => O_ERROR_MESSAGE,
                                                    I_processo      => GV_PROCESS_NAME,
                                                    I_level         => GV_LEVEL,
                                                    I_alias         => 'MPF_IMPOSSIVEL_GERAR',
                                                    I_subtipo       => GV_SUBTIPO,
                                                    I_para          => G_NOTIF_DEST_CODE,
                                                    I_param1        => R_SECTION_EMPLOYEE.NOME,
                                                    I_fk_processo   => I_PROCESS.CODIGO) THEN
              RETURN FALSE;
           END IF;
           --
           RETURN FALSE;
        END IF;
        --
        IF I_update_ind = 'Y' OR (I_update_ind='N' AND l_employee_was_processed = 1) THEN
           IF NOT n_aviso.create_info_notification (O_ERROR_MESSAGE => O_ERROR_MESSAGE,
                                                    I_processo      => GV_PROCESS_NAME,
                                                    I_level         => GV_LEVEL,
                                                    I_alias         => CASE l_exists_default_cicle WHEN 1 THEN 'MPF_USING_DEFAULT' ELSE 'MPF_PROCESSA_COLABORADOR' END,
                                                    I_subtipo       => GV_SUBTIPO,
                                                    I_para          => G_NOTIF_DEST_CODE,
                                                    I_param1        => R_SECTION_EMPLOYEE.NOME,
                                                    I_fk_processo   => I_PROCESS.CODIGO) THEN
              RETURN FALSE;
           END IF;
           --
           L_NR_OF_EMPLOYEES := L_NR_OF_EMPLOYEES + 1;
        END IF;
        --
      END LOOP;
      CLOSE C_SECTION_EMPLOYEE;

      IF NOT n_aviso.create_info_notification (O_ERROR_MESSAGE => O_ERROR_MESSAGE,
                                               I_processo      => GV_PROCESS_NAME,
                                               I_level         => GV_LEVEL,
                                               I_alias         => 'MPF_PROCESSA_SECAO',
                                               I_subtipo       => GV_SUBTIPO,
                                               I_para          => G_NOTIF_DEST_CODE,
                                               I_param1        => NVL(R_SECTION_EMPLOYEE.SEC_NAME, ' '),
                                               I_param2        => L_NR_OF_EMPLOYEES,
                                               I_fk_processo   => I_PROCESS.CODIGO) THEN
         RETURN FALSE;
      END IF;
   END IF;
   -------------------end---------------------

   --End function debug
   PCK_ESCALA_DEBUG.PRC_INS_DEBUG(PCK_ESCALA_DEBUG.G_FUNCTION_DBG,
                                  L_NAME,
                                  PCK_ESCALA_DEBUG.G_END_DBG,
                                  'L_NR_OF_EMPLOYEES='||L_NR_OF_EMPLOYEES);
   RETURN TRUE;
EXCEPTION
   WHEN OTHERS THEN

     l_erro := Pck_Escala_Debug.Fnc_Monta_Mensagem('PACKAGE_ERROR',
                                                   SQLERRM,
                                                   l_name,
                                                   To_Char(SQLCODE));
     O_ERROR_MESSAGE := n_Mensagem.Get(O_ERROR_MESSAGE, l_erro, PCK_CORE_USER.GET_USER_LANGUAGE(USER));
     PCK_ESCALA_DEBUG.PRC_INS_DEBUG(PCK_ESCALA_DEBUG.G_FUNCTION_DBG,
                                     L_NAME,
                                     PCK_ESCALA_DEBUG.G_END_DBG,
                                     PCK_ESCALA_DEBUG.G_EXCEPTION_OTHERS_DBG,
                                     PCK_ESCALA_DEBUG.GET_ERROR_STACK,
                                     PCK_ESCALA_DEBUG.GET_ERROR_BACKTRACE);
      RETURN FALSE;
END PROCESS;
------------------------------------------------------------------------------
--Process batch to generate predicted rest days map
------------------------------------------------------------------------------
FUNCTION PROCESS_BATCH  RETURN BOOLEAN IS

   L_ERROR_MESSAGE D_ARRAY_MENSAGEM_ERRO_TP;
   l_erro VARCHAR2(4000);
   l_update_ind VARCHAR2(1) := 'Y';

   --Cursor to get pending processes
   CURSOR C_PROCESS IS
      SELECT U.NOME UND_NAME,
             U.CODIGO cod_uni,
             S.NOME SEC_NAME,
             P.*
        FROM ESC_PROCESSO P
        JOIN ESC_SECAO S ON S.CODIGO = P.FK_SECAO
        JOIN ESC_UNIDADE U ON U.CODIGO = S.FK_UNIDADE
       WHERE P.TIPO   = PCK_CORE_PROCESS.C_TYPE_MPF --MPF
         AND P.SITUACAO = PCK_CORE_PROCESS.C_STATE_PREPARED --(N)
       ORDER BY P.DATA FOR UPDATE;

   R_C_PROCESS C_PROCESS%ROWTYPE;
   R_PROCESS   ESC_PROCESSO%ROWTYPE := NULL;
   --
   l_change_type VARCHAR2(100);
   l_name        VARCHAR2(100) := G_PACKAGE_NAME||'.PROCESS_BATCH';

   --Check if entry was generated by move employee funcionality
   l_dummy VARCHAR2(1);

   CURSOR c_is_move_employee (i_fk_employee ESC_COLABORADOR.CODIGO%TYPE) IS
       SELECT 'x'
         FROM esc_move_collaborator_map
        WHERE fk_colaborador = i_fk_employee
          AND TRUNC(activation_date) = TRUNC(SYSDATE)
          AND status = N_MOVE_COLLABORATOR_MAP.gv_processed;

   CURSOR c_check_escala_invalid (i_codigo ESC_PROCESSO.CODIGO%TYPE) IS
      SELECT 'x'
        FROM esc_processo p1
       WHERE p1.tipo      = PCK_CORE_PROCESS.C_TYPE_ESCALA
         AND p1.situacao  = PCK_CORE_PROCESS.C_STATE_INVALID
         AND EXISTS  (SELECT 1
                        FROM esc_processo p2
                       WHERE p2.codigo = i_codigo
                         AND p2.fk_secao  = p1.fk_secao
                         AND p2.data_ini  = p1.data_ini
                         AND p2.data_fim  = p1.data_fim
                         AND (p2.fk_colaborador IS NULL OR (p2.fk_colaborador = p1.fk_colaborador))
                         AND (p2.fk_grupo IS NULL OR (p2.fk_grupo = p1.fk_grupo))
                         AND (p2.fk_tipo_posto IS NULL OR (p2.fk_tipo_posto = p1.fk_tipo_posto))
                         AND p2.codigo  = p1.codigo + 1);

BEGIN

   OPEN C_PROCESS;
   FETCH C_PROCESS INTO R_C_PROCESS;

      IF C_PROCESS%NOTFOUND THEN
         --No records to process
         CLOSE C_PROCESS;
         RETURN TRUE;
      END IF;
   CLOSE C_PROCESS;

   --Begin function debug
   PCK_ESCALA_DEBUG.PRC_INS_DEBUG(PCK_ESCALA_DEBUG.G_FUNCTION_DBG,
                                  L_NAME,
                                  PCK_ESCALA_DEBUG.G_BEGIN_DBG);

   --Refresh batch to processing state (P)
   PCK_CORE_PROCESS.UPDATE_SITUACAO(R_C_PROCESS.CODIGO, PCK_CORE_PROCESS.C_STATE_PROCESSING);

   --use for all notifications
   G_NOTIF_DEST_CODE := R_C_PROCESS.FK_SECAO;

   --Get user prefered language
   PCK_MANIPULA_TYPE.V_USER := R_C_PROCESS.USER_CRIACAO;
   PCK_MANIPULA_TYPE.V_IDIOMA := PCK_CORE_USER.GET_USER_LANGUAGE(PCK_MANIPULA_TYPE.V_USER);
   --
   IF PCK_MANIPULA_TYPE.V_IDIOMA IS NULL THEN
      PCK_ESCALA_DEBUG.PRC_INS_DEBUG(PCK_ESCALA_DEBUG.G_FUNCTION_DBG,
                                     L_NAME,
                                     PCK_ESCALA_DEBUG.G_END_DBG,
                                     PCK_ESCALA_DEBUG.G_ERROR_DBG,
                                     'Error getting default language',
                                     PCK_MANIPULA_TYPE.V_USER);
      RETURN FALSE;
   END IF;

   --Get default date format
   G_DEFAULT_DATE_FORMAT := PCK_ESCALA_UTIL.BUSCAFORMATODATA(PCK_MANIPULA_TYPE.V_IDIOMA);
   PCK_ESCALA_DEBUG.PRC_INS_DEBUG(PCK_ESCALA_DEBUG.G_FUNCTION_DBG,
                                  L_NAME,
                                  PCK_ESCALA_DEBUG.G_TRACE_DBG,
                                  'G_DEFAULT_DATE_FORMAT',
                                  G_DEFAULT_DATE_FORMAT);

   --Check if exists dependencie with a schedule with error
   OPEN c_check_escala_invalid(R_C_PROCESS.CODIGO);
   FETCH c_check_escala_invalid INTO l_dummy;
   CLOSE c_check_escala_invalid;

   IF l_dummy IS NOT NULL THEN
      IF NOT n_aviso.create_info_notification (O_ERROR_MESSAGE => L_ERROR_MESSAGE,
                                               I_processo      => GV_PROCESS_NAME,
                                               I_level         => GV_LEVEL,
                                               I_alias         => 'MPF_SCHEDULE_ERROR',
                                               I_subtipo       => GV_SUBTIPO,
                                               I_para          => G_NOTIF_DEST_CODE,
                                               I_param1        => R_C_PROCESS.SEC_NAME,
                                               I_param2        => R_C_PROCESS.DATA_INI,
                                               I_param3        => R_C_PROCESS.DATA_FIM,
                                               I_fk_processo   => R_C_PROCESS.CODIGO) THEN
         RETURN FALSE;
      END IF;
      --
      PCK_CORE_PROCESS.UPDATE_SITUACAO(R_C_PROCESS.CODIGO, PCK_CORE_PROCESS.C_STATE_INVALID);
      --End function debug
      PCK_ESCALA_DEBUG.PRC_INS_DEBUG(PCK_ESCALA_DEBUG.G_FUNCTION_DBG,
                                     L_NAME,
                                     PCK_ESCALA_DEBUG.G_END_DBG);
      RETURN TRUE;
   END IF;

   --master notification
   IF NOT n_aviso.create_info_notification (O_ERROR_MESSAGE => L_ERROR_MESSAGE,
                                            I_processo      => GV_PROCESS_NAME,
                                            I_level         => GV_LEVEL,
                                            I_alias         => 'MPF_PROCESSAMENTO',
                                            I_subtipo       => GV_SUBTIPO,
                                            I_para          => G_NOTIF_DEST_CODE,
                                            I_param1        => R_C_PROCESS.UND_NAME,
                                            I_param2        => R_C_PROCESS.SEC_NAME,
                                            I_fk_processo   => R_C_PROCESS.CODIGO) THEN
      RETURN FALSE;
   END IF;


   ------- MAIN PROCESSING ----
   R_PROCESS.CODIGO         := R_C_PROCESS.CODIGO;
   R_PROCESS.FK_SECAO       := R_C_PROCESS.FK_SECAO;
   R_PROCESS.FK_GRUPO       := R_C_PROCESS.FK_GRUPO;
   R_PROCESS.FK_TIPO_POSTO  := R_C_PROCESS.FK_TIPO_POSTO;
   R_PROCESS.FK_COLABORADOR := R_C_PROCESS.FK_COLABORADOR;
   --
   R_PROCESS.DATA_INI      := R_C_PROCESS.DATA_INI;
   R_PROCESS.DATA_FIM      := R_C_PROCESS.DATA_FIM;

   --Type of Change and update indication
   IF R_PROCESS.DATA_FIM = R_PROCESS.DATA_INI THEN

      l_dummy := NULL;

      OPEN c_is_move_employee(R_PROCESS.FK_COLABORADOR);
     FETCH c_is_move_employee INTO l_dummy;
      CLOSE c_is_move_employee;
      --Move colaborator
      IF R_PROCESS.FK_COLABORADOR IS NOT NULL AND l_dummy IS NOT NULL THEN
         l_change_type := GV_CHANGE_BY_MOVE_COL;
      --Update cicle
      ELSIF R_PROCESS.FK_COLABORADOR IS NOT NULL OR R_PROCESS.FK_GRUPO IS NOT NULL THEN
         l_change_type := GV_CHANGE_BY_CICLE;
      --Night job
      ELSE
         l_update_ind := 'N';
         l_change_type := GV_CHANGE_BY_NI_JOB;
      END IF;
   --schedule update or pressing predicted rest days button
   ELSE
      l_change_type := GV_CHANGE_BY_USER;
   END IF;


   IF NOT PROCESS(L_ERROR_MESSAGE,
                  R_PROCESS,
                  R_C_PROCESS.COD_UNI,
                  l_change_type,
                  l_update_ind) THEN

      --Refresh batch to invalid state (I)
      PCK_CORE_PROCESS.UPDATE_SITUACAO(R_C_PROCESS.CODIGO, PCK_CORE_PROCESS.C_STATE_INVALID);
      --
      PCK_ESCALA_DEBUG.PRC_INS_DEBUG(PCK_ESCALA_DEBUG.G_FUNCTION_DBG,
                                     L_NAME,
                                     PCK_ESCALA_DEBUG.G_END_DBG,
                                     PCK_ESCALA_DEBUG.G_ERROR_DBG,
                                     'Error in PROCESS_BATCH',
                                     'PROCESS='||R_C_PROCESS.CODIGO,
                                     'MSG='||Pck_Escala_Debug.get_message_str(L_ERROR_MESSAGE));
   ELSE
      --Refresh batch to final state (G)
      PCK_CORE_PROCESS.UPDATE_SITUACAO(R_C_PROCESS.CODIGO, PCK_CORE_PROCESS.C_STATE_DONE);
   END IF;

   --End function debug
   PCK_ESCALA_DEBUG.PRC_INS_DEBUG(PCK_ESCALA_DEBUG.G_FUNCTION_DBG,
                                  L_NAME,
                                  PCK_ESCALA_DEBUG.G_END_DBG);

   RETURN TRUE;
EXCEPTION
   WHEN OTHERS THEN

      --Refresh batch to invalid state (I)
      PCK_CORE_PROCESS.UPDATE_SITUACAO(R_C_PROCESS.CODIGO, PCK_CORE_PROCESS.C_STATE_INVALID);

      PCK_ESCALA_DEBUG.PRC_INS_DEBUG(PCK_ESCALA_DEBUG.G_FUNCTION_DBG,
                                     L_NAME,
                                     PCK_ESCALA_DEBUG.G_END_DBG,
                                     PCK_ESCALA_DEBUG.G_EXCEPTION_OTHERS_DBG,
                                     PCK_ESCALA_DEBUG.GET_ERROR_STACK,
                                     PCK_ESCALA_DEBUG.GET_ERROR_BACKTRACE);
      --
      l_erro := PCK_ESCALA_DEBUG.FNC_MONTA_MENSAGEM('PACKAGE_ERROR', SQLERRM, L_NAME, TO_CHAR(SQLCODE));
      l_error_message := N_MENSAGEM.GET(l_error_message, l_erro, NULL);
      n_batch.log(l_error_message);
      --
      RETURN FALSE;
END PROCESS_BATCH;

/*******************************************************
PROCESS_PARALLEL
Function similar with PROCESS_BATCH:
 .Without notifications
 .Process type input <> 'MPF'
 .Not invoke set_aprove_schedule_days
********************************************************/
FUNCTION PROCESS_PARALLEL (O_ERROR_MESSAGE  IN OUT D_ARRAY_MENSAGEM_ERRO_TP,
                           I_PROCESS        IN     ESC_PROCESSO%ROWTYPE) RETURN BOOLEAN IS


   PRAGMA AUTONOMOUS_TRANSACTION;

   l_erro  VARCHAR2(4000);
   l_name  VARCHAR2(100) := G_PACKAGE_NAME||'.PROCESS_PARALLEL';
   --
   L_EMPLOYEE_DTL     ESC_COLABORADOR%ROWTYPE;
   --dummy
   l_exists_default_cicle   NUMBER(1);
   l_employee_was_processed NUMBER(1);
   --
   --Cursor to get Unit id
   CURSOR c_get_unit IS
      SELECT fk_unidade
        FROM esc_secao
       WHERE codigo = I_PROCESS.FK_SECAO;
   l_unit ESC_UNIDADE.CODIGO%TYPE;

   --Cursor to get employee details
   CURSOR C_EMPLOYEE (I_FK_EMPLOYEE ESC_COLABORADOR.CODIGO%TYPE, P_DATA DATE) IS
      SELECT C.*
        FROM ESC_COLABORADOR C
        JOIN TABLE(PCK_CORE_EMPLOYEE_CONTRACT.GETCURRENTCONTRACT(P_DATA, C.CODIGO)) CC
          ON CC.EMPLOYEEID = C.CODIGO --Employee should have an active contract
         AND (C.DATA_DEMISSAO IS NULL OR C.DATA_DEMISSAO > TRUNC(P_DATA))
       WHERE C.CODIGO = I_FK_EMPLOYEE;

   --Cursor to get all employees from a given group and sub-groups
   CURSOR C_GROUP_EMPLOYEE (I_FK_GROUP ESC_GRUPO.CODIGO%TYPE, P_DATA DATE) IS
      SELECT G.NOME GRP_NAME, C.*
        FROM ESC_COLABORADOR C
        JOIN TABLE(PCK_CORE_EMPLOYEE_CONTRACT.GETCURRENTCONTRACT(P_DATA, C.CODIGO)) CC
          ON CC.EMPLOYEEID = C.CODIGO --Employee should have an active contract
        JOIN ESC_GRUPO G ON G.CODIGO = C.FK_GRUPO
       WHERE C.FK_GRUPO IN (SELECT GR.CODIGO
                              FROM ESC_GRUPO GR
                             START WITH GR.CODIGO = I_FK_GROUP
                           CONNECT BY PRIOR GR.CODIGO = GR.FK_GRUPO
                           )
         AND (C.DATA_DEMISSAO IS NULL OR C.DATA_DEMISSAO > TRUNC(P_DATA));

    --Cursor to get all employees from a given section
    CURSOR C_SECTION_EMPLOYEE (I_FK_SECTION ESC_SECAO.CODIGO%TYPE, P_DATA DATE) IS
       SELECT S.NOME SEC_NAME, C.*
         FROM ESC_COLABORADOR C
         JOIN TABLE(PCK_CORE_EMPLOYEE_CONTRACT.GETCURRENTCONTRACT(P_DATA, C.CODIGO)) CC
           ON CC.EMPLOYEEID = C.CODIGO --Employee should have an active contract
         JOIN ESC_GRUPO GR ON GR.CODIGO = C.FK_GRUPO
         JOIN ESC_SECAO S ON S.CODIGO   = GR.FK_SECAO
        WHERE S.CODIGO        = I_FK_SECTION
          AND (C.DATA_DEMISSAO IS NULL OR C.DATA_DEMISSAO > TRUNC(P_DATA));

    --Cursor to get all employees from a given workstation type
    CURSOR C_WORKSTATION_TP_EMPLOYEE (I_FK_WORKSTATION_TP ESC_TIPO_POSTO.CODIGO%TYPE, P_DATA DATE) IS
       SELECT TP.NOME WORKTP_NAME, C.*
         FROM ESC_COLABORADOR C
         JOIN TABLE(PCK_CORE_EMPLOYEE_CONTRACT.GETCURRENTCONTRACT(P_DATA, C.CODIGO)) CC
           ON CC.EMPLOYEEID = C.CODIGO --Employee should have an active contract
         JOIN ESC_GRUPO GR ON GR.CODIGO = C.FK_GRUPO
         JOIN ESC_SECAO S ON S.CODIGO = GR.FK_SECAO
         JOIN ESC_TIPO_POSTO TP ON TP.FK_SECAO        = S.CODIGO
        WHERE TP.CODIGO       = I_FK_WORKSTATION_TP
          AND (C.DATA_DEMISSAO IS NULL OR C.DATA_DEMISSAO    > TRUNC(P_DATA));

    --Cursor rowtypes
    R_EMPLOYEE                C_EMPLOYEE%ROWTYPE;
    R_GROUP_EMPLOYEE          C_GROUP_EMPLOYEE%ROWTYPE;
    R_SECTION_EMPLOYEE        C_SECTION_EMPLOYEE%ROWTYPE;
    R_WORKSTATION_TP_EMPLOYEE C_WORKSTATION_TP_EMPLOYEE%ROWTYPE;


  BEGIN
     --Begin function debug
     PCK_ESCALA_DEBUG.PRC_INS_DEBUG(PCK_ESCALA_DEBUG.G_FUNCTION_DBG,
                                    L_NAME,
                                    PCK_ESCALA_DEBUG.G_BEGIN_DBG,
                                    I_PROCESS.FK_SECAO,
                                    I_PROCESS.DATA_INI,
                                    I_PROCESS.DATA_FIM);

     ---------------------------------------------------------------------
     --Get day and month that will provoke system to switch to next year
     ---------------------------------------------------------------------
     OPEN  c_get_unit;
     FETCH c_get_unit INTO l_unit;
     CLOSE c_get_unit;

     IF NOT GET_SWITCH_YEAR (o_error_message,
                             G_SWITH_DAY_MONTH,
                             PCK_CORE_PARAMETER.G_SCOPE_STORE, --store
                             l_unit) THEN
        RETURN FALSE;
     END IF;

     --------------------------------------------------------
     --Get number of months to define the end period date
     --------------------------------------------------------
     IF NOT GET_REST_DAYS_NR_MONTHS(o_error_message,
                                    G_ADD_NR_MONTHS,
                                    PCK_CORE_PARAMETER.G_SCOPE_STORE, --store
                                    l_unit) THEN
        RETURN FALSE;
     END IF;

    -------------------------------------------
    --Process for a specific employee
    -------------------------------------------
    IF I_PROCESS.FK_COLABORADOR IS NOT NULL THEN

       OPEN C_EMPLOYEE(I_PROCESS.FK_COLABORADOR, SYSDATE);
      FETCH C_EMPLOYEE INTO R_EMPLOYEE;
      CLOSE C_EMPLOYEE;

      L_EMPLOYEE_DTL.CODIGO   := I_PROCESS.FK_COLABORADOR;
      L_EMPLOYEE_DTL.FK_GRUPO := R_EMPLOYEE.FK_GRUPO;

      IF NOT PROCESS_EMPLOYEE(O_ERROR_MESSAGE    => O_ERROR_MESSAGE,
                              O_EXISTS_DEF_CICLE => l_exists_default_cicle,
                              O_WAS_RUNNING      => l_employee_was_processed,
                              I_FK_UNIT          => l_unit,
                              I_FK_SECTION       => I_PROCESS.FK_SECAO,
                              I_EMPLOYEE_DTL     => L_EMPLOYEE_DTL,
                              I_FK_PROCESS       => I_PROCESS.CODIGO,
                              I_START_DATE       => I_PROCESS.DATA_INI,
                              I_END_DATE         => I_PROCESS.DATA_FIM,
                              I_CHANGE_TYPE      => GV_CHANGE_BY_SCHEDULE,
                              I_UPDATE_STATE     => 'Y',
                              I_SCHEDULE_PROCESS => 'Y') THEN

         PCK_ESCALA_DEBUG.PRC_INS_DEBUG(PCK_ESCALA_DEBUG.G_FUNCTION_DBG,
                                        L_NAME,
                                        PCK_ESCALA_DEBUG.G_END_DBG,
                                        PCK_ESCALA_DEBUG.G_ERROR_DBG,
                                        'Error in process_parallel',
                                        'PROCESS='||I_PROCESS.CODIGO,
                                        'EMPLOYEE='||L_EMPLOYEE_DTL.CODIGO,
                                       'MSG='||Pck_Escala_Debug.get_message_str(O_ERROR_MESSAGE));

         RETURN FALSE;
      END IF;
   ------------------------------------
   --Process for a specific group
   ------------------------------------
   ELSIF I_PROCESS.FK_GRUPO IS NOT NULL THEN

      OPEN C_GROUP_EMPLOYEE(I_PROCESS.FK_GRUPO, SYSDATE);
      LOOP
        FETCH C_GROUP_EMPLOYEE INTO R_GROUP_EMPLOYEE;
        EXIT WHEN C_GROUP_EMPLOYEE%NOTFOUND;

        L_EMPLOYEE_DTL.CODIGO    := R_GROUP_EMPLOYEE.CODIGO;
        L_EMPLOYEE_DTL.FK_GRUPO  := R_GROUP_EMPLOYEE.FK_GRUPO;

        IF NOT PROCESS_EMPLOYEE(O_ERROR_MESSAGE    => O_ERROR_MESSAGE,
                                O_EXISTS_DEF_CICLE => l_exists_default_cicle,
                                O_WAS_RUNNING      => l_employee_was_processed,
                                I_FK_UNIT          => l_unit,
                                I_FK_SECTION       => I_PROCESS.FK_SECAO,
                                I_EMPLOYEE_DTL     => L_EMPLOYEE_DTL,
                                I_FK_PROCESS       => I_PROCESS.CODIGO,
                                I_START_DATE       => I_PROCESS.DATA_INI,
                                I_END_DATE         => I_PROCESS.DATA_FIM,
                                I_CHANGE_TYPE      => GV_CHANGE_BY_SCHEDULE,
                                I_UPDATE_STATE     => 'Y',
                                I_SCHEDULE_PROCESS => 'Y') THEN

           PCK_ESCALA_DEBUG.PRC_INS_DEBUG(PCK_ESCALA_DEBUG.G_FUNCTION_DBG,
                                          L_NAME,
                                          PCK_ESCALA_DEBUG.G_END_DBG,
                                          PCK_ESCALA_DEBUG.G_ERROR_DBG,
                                          'Error in process_parallel',
                                          'PROCESS='|| I_PROCESS.CODIGO,
                                          'EMPLOYEE='||L_EMPLOYEE_DTL.CODIGO,
                                          'MSG='||Pck_Escala_Debug.get_message_str(O_ERROR_MESSAGE));

           RETURN FALSE;
        END IF;
        --
      END LOOP;
      CLOSE C_GROUP_EMPLOYEE;
   -------------------------------------------------
   --Process for a specific workstation type
   -------------------------------------------------
   ELSIF I_PROCESS.FK_TIPO_POSTO IS NOT NULL THEN

      OPEN C_WORKSTATION_TP_EMPLOYEE(I_PROCESS.FK_TIPO_POSTO, SYSDATE);
      LOOP
        FETCH C_WORKSTATION_TP_EMPLOYEE INTO R_WORKSTATION_TP_EMPLOYEE;
        EXIT WHEN C_WORKSTATION_TP_EMPLOYEE%NOTFOUND;

        L_EMPLOYEE_DTL.CODIGO    := R_WORKSTATION_TP_EMPLOYEE.CODIGO;
        L_EMPLOYEE_DTL.FK_GRUPO  := R_WORKSTATION_TP_EMPLOYEE.FK_GRUPO;

        IF NOT PROCESS_EMPLOYEE(O_ERROR_MESSAGE    => O_ERROR_MESSAGE,
                                O_EXISTS_DEF_CICLE => l_exists_default_cicle,
                                O_WAS_RUNNING      => l_employee_was_processed,
                                I_FK_UNIT          => l_unit,
                                I_FK_SECTION       => I_PROCESS.FK_SECAO,
                                I_EMPLOYEE_DTL     => L_EMPLOYEE_DTL,
                                I_FK_PROCESS       => I_PROCESS.CODIGO,
                                I_START_DATE       => I_PROCESS.DATA_INI,
                                I_END_DATE         => I_PROCESS.DATA_FIM,
                                I_CHANGE_TYPE      => GV_CHANGE_BY_SCHEDULE,
                                I_UPDATE_STATE     => 'Y',
                                I_SCHEDULE_PROCESS => 'Y') THEN

           PCK_ESCALA_DEBUG.PRC_INS_DEBUG(PCK_ESCALA_DEBUG.G_FUNCTION_DBG,
                                          L_NAME,
                                          PCK_ESCALA_DEBUG.G_END_DBG,
                                          PCK_ESCALA_DEBUG.G_ERROR_DBG,
                                          'Error in process_parallel',
                                          'PROCESS='||I_PROCESS.CODIGO,
                                          'EMPLOYEE='||L_EMPLOYEE_DTL.CODIGO,
                                          'MSG='||Pck_Escala_Debug.get_message_str(O_ERROR_MESSAGE));


           RETURN FALSE;
        END IF;
      END LOOP;
      CLOSE C_WORKSTATION_TP_EMPLOYEE;

   --------------------------------------
   --Process for a specific section
   --------------------------------------
   ELSIF I_PROCESS.FK_SECAO IS NOT NULL THEN
      OPEN C_SECTION_EMPLOYEE(I_PROCESS.FK_SECAO, SYSDATE);
      LOOP
        FETCH C_SECTION_EMPLOYEE INTO R_SECTION_EMPLOYEE;
        EXIT WHEN C_SECTION_EMPLOYEE%NOTFOUND;

        L_EMPLOYEE_DTL.CODIGO    := R_SECTION_EMPLOYEE.CODIGO;
        L_EMPLOYEE_DTL.FK_GRUPO  := R_SECTION_EMPLOYEE.FK_GRUPO;

        IF NOT PROCESS_EMPLOYEE(O_ERROR_MESSAGE    => O_ERROR_MESSAGE,
                                O_EXISTS_DEF_CICLE => l_exists_default_cicle,
                                O_WAS_RUNNING      => l_employee_was_processed,
                                I_FK_UNIT          => l_unit,
                                I_FK_SECTION       => I_PROCESS.FK_SECAO,
                                I_EMPLOYEE_DTL     => L_EMPLOYEE_DTL,
                                I_FK_PROCESS       => I_PROCESS.CODIGO,
                                I_START_DATE       => I_PROCESS.DATA_INI,
                                I_END_DATE         => I_PROCESS.DATA_FIM,
                                I_CHANGE_TYPE      => GV_CHANGE_BY_SCHEDULE,
                                I_UPDATE_STATE     => 'Y',
                                I_SCHEDULE_PROCESS => 'Y') THEN
           --
           PCK_ESCALA_DEBUG.PRC_INS_DEBUG(PCK_ESCALA_DEBUG.G_FUNCTION_DBG,
                                          L_NAME,
                                          PCK_ESCALA_DEBUG.G_END_DBG,
                                          PCK_ESCALA_DEBUG.G_ERROR_DBG,
                                          'Error in process_parallel',
                                          'PROCESS='||I_PROCESS.CODIGO,
                                          'EMPLOYEE='||L_EMPLOYEE_DTL.CODIGO,
                                          'MSG='||Pck_Escala_Debug.get_message_str(O_ERROR_MESSAGE));


           RETURN FALSE;
        END IF;
        --
      END LOOP;
      CLOSE C_SECTION_EMPLOYEE;
   END IF;

   --End function debug
   PCK_ESCALA_DEBUG.PRC_INS_DEBUG(PCK_ESCALA_DEBUG.G_FUNCTION_DBG,
                                  L_NAME,
                                  PCK_ESCALA_DEBUG.G_END_DBG);

   RETURN TRUE;
EXCEPTION
   WHEN OTHERS THEN

      PCK_ESCALA_DEBUG.PRC_INS_DEBUG(PCK_ESCALA_DEBUG.G_FUNCTION_DBG,
                                     L_NAME,
                                     PCK_ESCALA_DEBUG.G_END_DBG,
                                     PCK_ESCALA_DEBUG.G_EXCEPTION_OTHERS_DBG,
                                     PCK_ESCALA_DEBUG.GET_ERROR_STACK,
                                     PCK_ESCALA_DEBUG.GET_ERROR_BACKTRACE);

      l_erro := PCK_ESCALA_DEBUG.FNC_MONTA_MENSAGEM('PACKAGE_ERROR', SQLERRM, L_NAME, TO_CHAR(SQLCODE));
      O_ERROR_MESSAGE := N_MENSAGEM.GET(O_ERROR_MESSAGE, l_erro, NULL);
      --
      --
      RETURN FALSE;
END PROCESS_PARALLEL;

--
--
FUNCTION PROCESS_NIGHT_BATCH (o_Mensagem_Erro   OUT D_ARRAY_MENSAGEM_ERRO_TP,
                              i_user          IN    VARCHAR2) RETURN BOOLEAN IS

   l_erro             VARCHAR2(4000);
   l_name             VARCHAR2(100) := G_PACKAGE_NAME||'.PROCESS_NIGHT_BATCH';
   l_mpf_process      ESC_PROCESSO%ROWTYPE;
   l_sysdate          DATE := SYSDATE;
   --Parameter
   l_parameter        VARCHAR2(50) := 'PREDICTED_REST_DAYS_GENERATE';
   l_exists_parameter VARCHAR2(1);

   CURSOR C_get_all_section IS
      SELECT es.codigo,
             es.nome nome_secao,
             eu.codigo cod_uni,
             eu.nome nome_uni
        FROM esc_unidade eu,
             esc_secao es
       WHERE (eu.data_exclusao IS NULL OR eu.data_exclusao > SYSDATE)
         AND eu.codigo = es.fk_unidade
         AND es.ativo = 'S'
         --Is configured in system to generate predicted rest days using nigth job
         AND PCK_CORE_PARAMETER.GETCHARATTR(l_parameter,'L',eu.codigo) = 'Y'
         ORDER BY 3,1;


BEGIN

  --Begin function debug
  PCK_ESCALA_DEBUG.PRC_INS_DEBUG(PCK_ESCALA_DEBUG.G_FUNCTION_DBG,
                                 L_NAME,
                                 PCK_ESCALA_DEBUG.G_BEGIN_DBG);


  --Get user prefered language
   PCK_MANIPULA_TYPE.V_USER := i_user;
   PCK_MANIPULA_TYPE.V_IDIOMA := PCK_CORE_USER.GET_USER_LANGUAGE(PCK_MANIPULA_TYPE.V_USER);
   --
   IF PCK_MANIPULA_TYPE.V_IDIOMA IS NULL THEN
      PCK_ESCALA_DEBUG.PRC_INS_DEBUG(PCK_ESCALA_DEBUG.G_FUNCTION_DBG,
                                     L_NAME,
                                     PCK_ESCALA_DEBUG.G_END_DBG,
                                     PCK_ESCALA_DEBUG.G_ERROR_DBG,
                                     'Error getting default language',
                                     PCK_MANIPULA_TYPE.V_USER);
      RETURN FALSE;
   END IF;

   --Get default date format
   G_DEFAULT_DATE_FORMAT := PCK_ESCALA_UTIL.BUSCAFORMATODATA(PCK_MANIPULA_TYPE.V_IDIOMA);
   PCK_ESCALA_DEBUG.PRC_INS_DEBUG(PCK_ESCALA_DEBUG.G_FUNCTION_DBG,
                                  L_NAME,
                                  PCK_ESCALA_DEBUG.G_TRACE_DBG,
                                  'G_DEFAULT_DATE_FORMAT',
                                  G_DEFAULT_DATE_FORMAT);

   l_exists_parameter := PCK_CORE_PARAMETER.GETCHARATTR(l_parameter);

   IF l_exists_parameter IS NULL THEN
      o_Mensagem_Erro := n_Mensagem.Get(i_lista_erros => o_Mensagem_Erro,
                                        i_cod_erro    => 'PARAMETER_NOT_EXISTS',
                                        i_idioma      => PCK_CORE_USER.GET_USER_LANGUAGE(i_user),
                                        i_Parametro1  => l_parameter);
      RETURN FALSE;

   ELSE

      FOR c in C_get_all_section LOOP


         --use for all notifications
         G_NOTIF_DEST_CODE := c.codigo;

         l_mpf_process := NULL;
         --
         l_mpf_process.Fk_Secao       := c.codigo;
         l_mpf_process.data           := l_sysdate;
         l_mpf_process.data_ini       := trunc(l_sysdate);
         l_mpf_process.data_fim       := trunc(l_sysdate);
         l_mpf_process.reprocessa     := PCK_CORE_PROCESS.C_ACTION_TYPE_MPF;
         l_mpf_process.tipo           := PCK_CORE_PROCESS.C_TYPE_MPF;
         --
         IF NOT d_Processo.SET(o_Mensagem_Erro, l_mpf_process, i_User) THEN
            RETURN FALSE;
         END IF;
         --Change status to Processing since trigger automatically insert record in 'A'
         l_mpf_process.situacao       := PCK_CORE_PROCESS.C_STATE_PROCESSING;--In processing
         IF NOT d_Processo.SET(o_Mensagem_Erro, l_mpf_process, i_User) THEN
            RETURN FALSE;
         END IF;


         --master notification
         IF NOT n_aviso.create_info_notification (O_ERROR_MESSAGE => o_Mensagem_Erro,
                                                  I_processo      => GV_PROCESS_NAME,
                                                  I_level         => GV_LEVEL,
                                                  I_alias         => 'MPF_PROCESSAMENTO',
                                                  I_subtipo       => GV_SUBTIPO,
                                                  I_para          => G_NOTIF_DEST_CODE,
                                                  I_novo_aviso    => 'Y',
                                                  I_param1        => c.nome_uni,
                                                  I_param2        => c.nome_secao,
                                                  I_fk_processo   => l_mpf_process.codigo) THEN
            RETURN FALSE;
         END IF;
         --
         IF NOT PROCESS(o_Mensagem_Erro,
                        l_mpf_process,
                        c.cod_uni,
                        GV_CHANGE_BY_NI_JOB,
                        'N') THEN

            --Refresh batch to invalid state (I)
            PCK_CORE_PROCESS.UPDATE_SITUACAO(l_mpf_process.CODIGO, PCK_CORE_PROCESS.C_STATE_INVALID);
            --
            PCK_ESCALA_DEBUG.PRC_INS_DEBUG(PCK_ESCALA_DEBUG.G_FUNCTION_DBG,
                                           L_NAME,
                                           PCK_ESCALA_DEBUG.G_END_DBG,
                                           PCK_ESCALA_DEBUG.G_ERROR_DBG,
                                           'Error in PROCESS_NIGHT_BATCH',
                                           'PROCESS='||l_mpf_process.CODIGO,
                                           'MSG='||Pck_Escala_Debug.get_message_str(o_Mensagem_Erro));
         ELSE
            --Refresh batch to final state (G)
            PCK_CORE_PROCESS.UPDATE_SITUACAO(l_mpf_process.CODIGO, PCK_CORE_PROCESS.C_STATE_DONE);
         END IF;
         COMMIT;
      END LOOP;
   END IF;
   --
   --End function debug
   PCK_ESCALA_DEBUG.PRC_INS_DEBUG(PCK_ESCALA_DEBUG.G_FUNCTION_DBG,
                                  L_NAME,
                                  PCK_ESCALA_DEBUG.G_END_DBG);


   RETURN TRUE;
EXCEPTION
   WHEN OTHERS THEN
     --
     --Refresh batch to invalid state (I)
     IF l_mpf_process.CODIGO IS NOT NULL THEN
        PCK_CORE_PROCESS.UPDATE_SITUACAO(l_mpf_process.CODIGO, PCK_CORE_PROCESS.C_STATE_INVALID);
     END IF;
     PCK_ESCALA_DEBUG.PRC_INS_DEBUG(PCK_ESCALA_DEBUG.G_FUNCTION_DBG,
                                    L_NAME,
                                    PCK_ESCALA_DEBUG.G_END_DBG,
                                    PCK_ESCALA_DEBUG.G_EXCEPTION_OTHERS_DBG,
                                    PCK_ESCALA_DEBUG.GET_ERROR_STACK,
                                    PCK_ESCALA_DEBUG.GET_ERROR_BACKTRACE);

     l_erro := PCK_ESCALA_DEBUG.FNC_MONTA_MENSAGEM('PACKAGE_ERROR', SQLERRM, L_NAME, TO_CHAR(SQLCODE));
     o_Mensagem_Erro := N_MENSAGEM.GET(o_Mensagem_Erro, l_erro, NULL);
     n_batch.log(o_Mensagem_Erro);
      --
      RETURN FALSE;
END  PROCESS_NIGHT_BATCH;
--
FUNCTION GET_TOTAL_DAYS (O_MENSAGEM_ERRO     IN OUT D_ARRAY_MENSAGEM_ERRO_TP,
                         O_TOTAL_REST_DAYS      OUT NUMBER,
                         I_FK_EMPLOYEE       IN     ESC_COLABORADOR.CODIGO%TYPE,
                         I_START_DATE        IN     DATE,
                         I_END_DATE          IN     DATE,
                         I_TYPE              IN     VARCHAR2)
  RETURN BOOLEAN IS

  l_name CONSTANT VARCHAR2(100) := G_PACKAGE_NAME||'.GET_TOTAL_DAYS';
  l_erro VARCHAR2(4000);

BEGIN

   SELECT COUNT(*)
     INTO O_TOTAL_REST_DAYS
     FROM (SELECT DISTINCT dtl.rest_start_date
             FROM predicted_rest_days_map_dtl dtl,
                  predicted_rest_days_map     dm
            WHERE dm.fk_employee = I_FK_EMPLOYEE
              AND dm.state IN (C_STATE_APPROVED, C_STATE_PROCESSED)
              AND dm.id = dtl.fk_pred_rest_days_map
              AND dtl.rest_type = I_TYPE
              AND dtl.rest_start_date BETWEEN I_START_DATE AND I_END_DATE);

   RETURN TRUE;
EXCEPTION
   WHEN OTHERS THEN
      l_erro := Pck_Escala_Debug.Fnc_Monta_Mensagem('PACKAGE_ERROR',
                                                     SQLERRM,
                                                     l_name,
                                                     To_Char(SQLCODE));
      o_Mensagem_Erro := n_Mensagem.Get(o_Mensagem_Erro, l_erro, PCK_CORE_USER.GET_USER_LANGUAGE(USER));
      RETURN FALSE;
END GET_TOTAL_DAYS;
--
END PCK_PREDICTED_REST_DAYS;
/