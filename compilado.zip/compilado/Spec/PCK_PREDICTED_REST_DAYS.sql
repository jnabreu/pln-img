CREATE OR REPLACE PACKAGE PCK_PREDICTED_REST_DAYS AS

   --Error
   G_PACKAGE_NAME        CONSTANT VARCHAR2(30) := 'PCK_PREDICTED_REST_DAYS';

   --Notifications
   GV_PROCESS_NAME       CONSTANT VARCHAR2(30) := 'PROCESSO_MAPA_FOLGAS';
   GV_LEVEL              CONSTANT VARCHAR2(20) := 'SECAO';
   GV_SUBTIPO            CONSTANT VARCHAR2(20) := 'PROCESSAMENTO';

   --Rest types
   TYPE_REST_DAY         PREDICTED_REST_DAYS_MAP_DTL.REST_TYPE%TYPE := 'R'; --Rest Day
   TYPE_CLOSE_HOLIDAY    PREDICTED_REST_DAYS_MAP_DTL.REST_TYPE%TYPE := 'H'; --Close Holiday
   TYPE_EMPTY_DAY        PREDICTED_REST_DAYS_MAP_DTL.REST_TYPE%TYPE := 'E'; --Empty Day

   --Process states
   C_STATE_INITIAL       CONSTANT VARCHAR2(1)  := 'I';
   C_STATE_RUNNING       CONSTANT VARCHAR2(1)  := 'R';
   C_STATE_PROCESSED     CONSTANT VARCHAR2(1)  := 'P'; --only after exporting for other sistems
   C_STATE_WAIT_APROVE   CONSTANT VARCHAR2(1)  := 'W'; --only if parameter auto aprove is OFF
   C_STATE_CANCELLED     CONSTANT VARCHAR2(1)  := 'C'; --if not aprove by user
   C_STATE_APPROVED      CONSTANT VARCHAR2(1)  := 'A';
   C_STATE_ERROR         CONSTANT VARCHAR2(1)  := 'E';

   --Rest days map create/update types
   GV_CHANGE_BY_USER     CONSTANT VARCHAR2(30):= 'USER_REQUEST';       --When running schedule updates or pressing predicted button
   GV_CHANGE_BY_SCHEDULE CONSTANT VARCHAR2(30):= 'SCHEDULE_DEPENDENCY';--Runnig before the schedule generation
   GV_CHANGE_BY_NI_JOB   CONSTANT VARCHAR2(30):= 'NIGHT_JOB';          --When running the Predicted Rest Days daily job process
   GV_CHANGE_BY_CICLE    CONSTANT VARCHAR2(30):= 'CICLE_UPDATE';       --When changing schedule cicles
   GV_CHANGE_BY_EXCHANGE CONSTANT VARCHAR2(30):= 'SCHEDULE_EXCHANGE';  --When shedule exchange days or employees
   GV_CHANGE_BY_MOVE_COL CONSTANT VARCHAR2(30):= 'MOVE_EMPLOYEE';      --When moving employee between diferent sections/groups
------------------------------------------------------------------------------
--Get Parameter for switch year
------------------------------------------------------------------------------
FUNCTION GET_SWITCH_YEAR(O_ERROR_MESSAGE  IN OUT D_ARRAY_MENSAGEM_ERRO_TP,
                         O_SWITCH_YEAR       OUT DATE,
                         I_SCOPE          IN     VARCHAR2 DEFAULT NULL,
                         I_SCOPE_ID       IN     VARCHAR2 DEFAULT NULL) RETURN BOOLEAN;
------------------------------------------------------------------------------
--Get Parameter for nr Months after switch year
------------------------------------------------------------------------------
FUNCTION GET_REST_DAYS_NR_MONTHS(O_ERROR_MESSAGE  IN OUT D_ARRAY_MENSAGEM_ERRO_TP,
                                 O_NR_MONTHS         OUT NUMBER,
                                 I_SCOPE          IN     VARCHAR2 DEFAULT NULL,
                                 I_SCOPE_ID       IN     VARCHAR2 DEFAULT NULL) RETURN BOOLEAN;

------------------------------------------------------------------------------
--Get Parameter auto aprove indicator
------------------------------------------------------------------------------
FUNCTION GET_AUTO_APROVE_IND(O_ERROR_MESSAGE  IN OUT D_ARRAY_MENSAGEM_ERRO_TP,
                             O_IS_AUTO_APRV      OUT VARCHAR2,
                             I_SCOPE          IN     VARCHAR2 DEFAULT NULL,
                             I_SCOPE_ID       IN     VARCHAR2 DEFAULT NULL) RETURN BOOLEAN;
----------------------------------------------------------------------------------
--Get default cicle for employees that don't have fixed rest days in their cicles
----------------------------------------------------------------------------------
FUNCTION GET_DEFAULT_REST_DAYS_CICLE(O_ERROR_MESSAGE IN OUT D_ARRAY_MENSAGEM_ERRO_TP,
                                     O_DE_CICLE         OUT ESC_CICLO.CODIGO%TYPE,
                                     I_FK_SECTION    IN  ESC_SECAO.CODIGO%TYPE)
   RETURN BOOLEAN;
----------------------------------------------------------------------------------
--Used after adjusting or Exchange schedule
----------------------------------------------------------------------------------
FUNCTION APPLY_EXCHANGE_SCHEDULE (O_ERROR_MESSAGE IN OUT D_ARRAY_MENSAGEM_ERRO_TP,
                                  I_FK_EMPLOYEE_A IN     ESC_COLABORADOR.CODIGO%TYPE,
                                  I_FK_EMPLOYEE_B IN     ESC_COLABORADOR.CODIGO%TYPE,
                                  I_APPLY_DATE_A  IN     DATE,
                                  I_APPLY_DATE_B  IN     DATE,
                                  I_TYPE_A        IN     VARCHAR2,
                                  I_TYPE_B        IN     VARCHAR2) RETURN BOOLEAN;
------------------------------------------------------------------------------
--Get total rest days
------------------------------------------------------------------------------
FUNCTION GET_TOTAL_REST_DAYS (O_MENSAGEM_ERRO     IN OUT D_ARRAY_MENSAGEM_ERRO_TP,
                              O_TOTAL_REST_DAYS      OUT NUMBER,
                              I_FK_EMPLOYEE       IN     ESC_COLABORADOR.CODIGO%TYPE,
                              I_START_DATE        IN     DATE,
                              I_END_DATE          IN     DATE)
RETURN BOOLEAN;

------------------------------------------------------------------------------
--Get employee rest days map for search year
------------------------------------------------------------------------------
FUNCTION GET_ANUAL_REST_MAP_EMPLOYEE (O_ERROR_MESSAGE     IN OUT D_ARRAY_MENSAGEM_ERRO_TP,
                                      I_FK_UNIT           IN     ESC_UNIDADE.CODIGO%TYPE,
                                      I_FK_EMPLOYEE       IN     ESC_COLABORADOR.CODIGO%TYPE,
                                      I_YEAR              IN     NUMBER DEFAULT TO_NUMBER(TO_CHAR(SYSDATE, 'YYYY')),
                                      I_LANGUAGE          IN     NUMBER,
                                      O_ABS_DAYS          IN OUT SYS_REFCURSOR)
   RETURN NUMBER;
------------------------------------------------------------------------------
--Get employees rest days map for search month
------------------------------------------------------------------------------   
FUNCTION GET_MONTH_REST_MAP_EMPLOYEES (O_ERROR_MESSAGE     IN OUT D_ARRAY_MENSAGEM_ERRO_TP,
                                       I_FK_UNIT           IN     ESC_UNIDADE.CODIGO%TYPE,
                                       I_FK_SECTION        IN     ESC_SECAO.CODIGO%TYPE,
                                       I_FK_WORKSTATION_TP IN     ESC_TIPO_POSTO.CODIGO%TYPE,
                                       I_FIRST_DAY_MONTH   IN     DATE,
                                       I_LANGUAGE          IN     NUMBER,
                                       O_ABS_DAYS          IN OUT SYS_REFCURSOR)
   RETURN NUMBER;  
   
------------------------------------------------------------------------------
--Add close days to predicted rest days map (type H)
------------------------------------------------------------------------------
FUNCTION SET_HOLIDAY_CLOSE_DAYS(O_ERROR_MESSAGE  IN OUT D_ARRAY_MENSAGEM_ERRO_TP,
                                I_FK_UNIT        IN     ESC_UNIDADE.CODIGO%TYPE,
                                I_FK_SECTION     IN     ESC_SECAO.CODIGO%TYPE,
                                I_FK_EMPLOYEE    IN     ESC_COLABORADOR.CODIGO%TYPE,
                                I_BEGIN_DATE     IN     DATE,
                                I_END_DATE       IN     DATE,
                                I_CHANGE_TYPE    IN     VARCHAR2) RETURN BOOLEAN;
------------------------------------------------------------------------------
--Set Aproved schedules to predicted rest days map
------------------------------------------------------------------------------
FUNCTION SET_APPROVE_SCHEDULE_DAYS(O_ERROR_MESSAGE  IN OUT D_ARRAY_MENSAGEM_ERRO_TP,
                                   I_FK_EMPLOYEE    IN     ESC_COLABORADOR.CODIGO%TYPE,
                                   I_BEGIN_DATE     IN     DATE,
                                   I_END_DATE       IN     DATE,
                                   I_CHANGE_TYPE    IN     VARCHAR2) RETURN BOOLEAN;

------------------------------------------------------------------------------
--Set rest days of employee for a given period
------------------------------------------------------------------------------
FUNCTION SET_PREDICTED_REST_DAYS(O_ERROR_MESSAGE     IN OUT D_ARRAY_MENSAGEM_ERRO_TP,
                                 I_FK_SECTION        IN     ESC_SECAO.CODIGO%TYPE,
                                 I_FK_EMPLOYEE       IN     ESC_COLABORADOR%ROWTYPE,
                                 I_PERIOD_START_DATE IN     DATE,
                                 I_PERIOD_END_DATE   IN     DATE,
                                 I_CHANGE_TYPE       IN     VARCHAR2)
   RETURN BOOLEAN;
------------------------------------------------------------------------------
--Get map detail range dates
------------------------------------------------------------------------------
FUNCTION CALCULATE_REST_DAY_MAP_RANGE (O_ERROR_MESSAGE    IN OUT D_ARRAY_MENSAGEM_ERRO_TP,
                                       I_YEAR             IN     NUMBER,
                                       I_SWITCH_DAY_MONTH IN     DATE,
                                       I_ADD_NR_MONTHS    IN     NUMBER,
                                       O_BEGIN_DATE          OUT DATE,
                                       O_END_DATE            OUT DATE)  RETURN BOOLEAN;
------------------------------------------------------------------------------
--Save
------------------------------------------------------------------------------
FUNCTION SAVE(I_FK_EMPLOYEE  IN  ESC_COLABORADOR.CODIGO%TYPE,
              I_FK_PROCESS   IN  ESC_PROCESSO.CODIGO%TYPE,
              I_CURRENT_YEAR IN  NUMBER DEFAULT NULL,
              I_OLD_STATE    IN  VARCHAR2 DEFAULT NULL,
              I_NEW_STATE    IN  VARCHAR2 DEFAULT NULL) RETURN BOOLEAN;
------------------------------------------------------------------------------
--SET_RANGE_DATES
------------------------------------------------------------------------------
FUNCTION SET_RANGE_DATES(O_ERROR_MESSAGE  IN OUT D_ARRAY_MENSAGEM_ERRO_TP,
                         I_START_DATE     IN     DATE,
                         I_EMPLOYEE_DTL   IN     ESC_COLABORADOR%ROWTYPE,
                         I_FK_PROCESS     IN     ESC_PROCESSO.CODIGO%TYPE,
                         I_UPDATE_STATE   IN     VARCHAR2 DEFAULT 'N',
                         O_MAX_END_DATE      OUT DATE)  RETURN BOOLEAN;


------------------------------------------------------------------------------
--Process rest days map
------------------------------------------------------------------------------
FUNCTION PROCESS (O_ERROR_MESSAGE IN OUT D_ARRAY_MENSAGEM_ERRO_TP,
                  I_PROCESS       IN     ESC_PROCESSO%ROWTYPE,
                  I_FK_UNIT       IN     ESC_UNIDADE.CODIGO%TYPE,
                  I_change_type   IN     VARCHAR2,
                  I_update_ind    IN     VARCHAR2) RETURN BOOLEAN;

------------------------------------------------------------------------------
--Process batch to generate predicted rest days map
------------------------------------------------------------------------------
FUNCTION PROCESS_BATCH  RETURN BOOLEAN;
------------------------------------------------------------------------------
--Used before when is trigger the schedule generation process
------------------------------------------------------------------------------
FUNCTION PROCESS_PARALLEL (O_ERROR_MESSAGE  IN OUT D_ARRAY_MENSAGEM_ERRO_TP,
                           I_PROCESS        IN     ESC_PROCESSO%ROWTYPE) RETURN BOOLEAN;
------------------------------------------------------------------------------------------
--Process night batch to automatically generate rest days according with configured units
------------------------------------------------------------------------------------------
FUNCTION PROCESS_NIGHT_BATCH (o_Mensagem_Erro       OUT D_ARRAY_MENSAGEM_ERRO_TP,
                              i_user             IN     VARCHAR2) RETURN BOOLEAN;
------------------------------------------------------------------------------
--Get total days of type I_type
------------------------------------------------------------------------------
FUNCTION GET_TOTAL_DAYS (O_MENSAGEM_ERRO     IN OUT D_ARRAY_MENSAGEM_ERRO_TP,
                         O_TOTAL_REST_DAYS      OUT NUMBER,
                         I_FK_EMPLOYEE       IN     ESC_COLABORADOR.CODIGO%TYPE,
                         I_START_DATE        IN     DATE,
                         I_END_DATE          IN     DATE,
                         I_TYPE              IN     VARCHAR2) RETURN BOOLEAN;
END PCK_PREDICTED_REST_DAYS;
/